-- phpMyAdmin SQL Dump
-- version 3.3.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 28, 2011 at 02:11 PM
-- Server version: 5.1.54
-- PHP Version: 5.3.5-1ubuntu7.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pmb`
--

-- --------------------------------------------------------

--
-- Table structure for table `abo_liste_lecture`
--

CREATE TABLE IF NOT EXISTS `abo_liste_lecture` (
  `num_empr` int(8) unsigned NOT NULL DEFAULT '0',
  `num_liste` int(8) unsigned NOT NULL DEFAULT '0',
  `etat` int(1) unsigned NOT NULL DEFAULT '0',
  `commentaire` text NOT NULL,
  PRIMARY KEY (`num_empr`,`num_liste`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `abo_liste_lecture`
--


-- --------------------------------------------------------

--
-- Table structure for table `abts_abts`
--

CREATE TABLE IF NOT EXISTS `abts_abts` (
  `abt_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `abt_name` varchar(255) NOT NULL DEFAULT '',
  `base_modele_name` varchar(255) NOT NULL DEFAULT '',
  `base_modele_id` int(11) NOT NULL DEFAULT '0',
  `num_notice` int(11) NOT NULL DEFAULT '0',
  `date_debut` date NOT NULL DEFAULT '0000-00-00',
  `date_fin` date NOT NULL DEFAULT '0000-00-00',
  `fournisseur` int(11) NOT NULL DEFAULT '0',
  `destinataire` varchar(255) NOT NULL DEFAULT '',
  `cote` varchar(255) NOT NULL DEFAULT '',
  `typdoc_id` int(11) NOT NULL DEFAULT '0',
  `exemp_auto` int(11) NOT NULL DEFAULT '0',
  `location_id` int(11) NOT NULL DEFAULT '0',
  `section_id` int(11) NOT NULL DEFAULT '0',
  `lender_id` int(11) NOT NULL DEFAULT '0',
  `statut_id` int(11) NOT NULL DEFAULT '0',
  `codestat_id` int(11) NOT NULL DEFAULT '0',
  `type_antivol` int(11) NOT NULL DEFAULT '0',
  `duree_abonnement` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`abt_id`),
  KEY `index_num_notice` (`num_notice`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `abts_abts`
--


-- --------------------------------------------------------

--
-- Table structure for table `abts_abts_modeles`
--

CREATE TABLE IF NOT EXISTS `abts_abts_modeles` (
  `modele_id` int(11) NOT NULL DEFAULT '0',
  `abt_id` int(11) NOT NULL DEFAULT '0',
  `num` int(11) NOT NULL DEFAULT '0',
  `vol` int(11) NOT NULL DEFAULT '0',
  `tome` int(11) NOT NULL DEFAULT '0',
  `delais` int(11) NOT NULL DEFAULT '0',
  `critique` int(11) NOT NULL DEFAULT '0',
  `num_statut_general` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`modele_id`,`abt_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `abts_abts_modeles`
--


-- --------------------------------------------------------

--
-- Table structure for table `abts_grille_abt`
--

CREATE TABLE IF NOT EXISTS `abts_grille_abt` (
  `id_bull` int(11) NOT NULL AUTO_INCREMENT,
  `num_abt` int(10) unsigned NOT NULL DEFAULT '0',
  `date_parution` date NOT NULL DEFAULT '0000-00-00',
  `modele_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `nombre` int(11) NOT NULL DEFAULT '0',
  `numero` int(11) NOT NULL DEFAULT '0',
  `ordre` int(11) NOT NULL DEFAULT '0',
  `state` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_bull`),
  KEY `num_abt` (`num_abt`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `abts_grille_abt`
--


-- --------------------------------------------------------

--
-- Table structure for table `abts_grille_modele`
--

CREATE TABLE IF NOT EXISTS `abts_grille_modele` (
  `num_modele` int(10) unsigned NOT NULL DEFAULT '0',
  `date_parution` date NOT NULL DEFAULT '0000-00-00',
  `type_serie` int(11) NOT NULL DEFAULT '0',
  `numero` varchar(50) NOT NULL DEFAULT '',
  `nombre_recu` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`num_modele`,`date_parution`,`type_serie`),
  KEY `num_modele` (`num_modele`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `abts_grille_modele`
--


-- --------------------------------------------------------

--
-- Table structure for table `abts_modeles`
--

CREATE TABLE IF NOT EXISTS `abts_modeles` (
  `modele_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `modele_name` varchar(255) NOT NULL DEFAULT '',
  `num_notice` int(10) unsigned NOT NULL DEFAULT '0',
  `num_periodicite` int(10) unsigned NOT NULL DEFAULT '0',
  `duree_abonnement` int(11) NOT NULL DEFAULT '0',
  `date_debut` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  `days` varchar(7) NOT NULL DEFAULT '1111111',
  `day_month` varchar(31) NOT NULL DEFAULT '1111111111111111111111111111111',
  `week_month` varchar(6) NOT NULL DEFAULT '111111',
  `week_year` varchar(54) NOT NULL DEFAULT '111111111111111111111111111111111111111111111111111111',
  `month_year` varchar(12) NOT NULL DEFAULT '111111111111',
  `num_cycle` int(11) NOT NULL DEFAULT '0',
  `num_combien` int(11) NOT NULL DEFAULT '0',
  `num_increment` int(11) NOT NULL DEFAULT '0',
  `num_date_unite` int(11) NOT NULL DEFAULT '0',
  `num_increment_date` int(11) NOT NULL DEFAULT '0',
  `num_depart` int(11) NOT NULL DEFAULT '0',
  `vol_actif` int(11) NOT NULL DEFAULT '0',
  `vol_increment` int(11) NOT NULL DEFAULT '0',
  `vol_date_unite` int(11) NOT NULL DEFAULT '0',
  `vol_increment_numero` int(11) NOT NULL DEFAULT '0',
  `vol_increment_date` int(11) NOT NULL DEFAULT '0',
  `vol_cycle` int(11) NOT NULL DEFAULT '0',
  `vol_combien` int(11) NOT NULL DEFAULT '0',
  `vol_depart` int(11) NOT NULL DEFAULT '0',
  `tom_actif` int(11) NOT NULL DEFAULT '0',
  `tom_increment` int(11) NOT NULL DEFAULT '0',
  `tom_date_unite` int(11) NOT NULL DEFAULT '0',
  `tom_increment_numero` int(11) NOT NULL DEFAULT '0',
  `tom_increment_date` int(11) NOT NULL DEFAULT '0',
  `tom_cycle` int(11) NOT NULL DEFAULT '0',
  `tom_combien` int(11) NOT NULL DEFAULT '0',
  `tom_depart` int(11) NOT NULL DEFAULT '0',
  `format_aff` varchar(255) NOT NULL DEFAULT '',
  `format_periode` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`modele_id`),
  KEY `num_notice` (`num_notice`),
  KEY `num_periodicite` (`num_periodicite`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `abts_modeles`
--


-- --------------------------------------------------------

--
-- Table structure for table `abts_periodicites`
--

CREATE TABLE IF NOT EXISTS `abts_periodicites` (
  `periodicite_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL DEFAULT '',
  `duree` int(11) NOT NULL DEFAULT '0',
  `unite` int(11) NOT NULL DEFAULT '0',
  `retard_periodicite` int(4) DEFAULT '0',
  `seuil_periodicite` int(4) DEFAULT '0',
  PRIMARY KEY (`periodicite_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `abts_periodicites`
--


-- --------------------------------------------------------

--
-- Table structure for table `acces_profiles`
--

CREATE TABLE IF NOT EXISTS `acces_profiles` (
  `prf_id` int(2) unsigned NOT NULL AUTO_INCREMENT,
  `prf_type` int(1) unsigned NOT NULL DEFAULT '1',
  `prf_name` varchar(255) NOT NULL,
  `prf_rule` blob NOT NULL,
  `prf_hrule` text NOT NULL,
  `prf_used` int(2) unsigned NOT NULL DEFAULT '0',
  `dom_num` int(2) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`prf_id`),
  KEY `prf_type` (`prf_type`),
  KEY `prf_name` (`prf_name`),
  KEY `dom_num` (`dom_num`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `acces_profiles`
--


-- --------------------------------------------------------

--
-- Table structure for table `acces_rights`
--

CREATE TABLE IF NOT EXISTS `acces_rights` (
  `dom_num` int(2) unsigned NOT NULL DEFAULT '0',
  `usr_prf_num` int(2) unsigned NOT NULL DEFAULT '0',
  `res_prf_num` int(2) unsigned NOT NULL DEFAULT '0',
  `dom_rights` int(2) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`dom_num`,`usr_prf_num`,`res_prf_num`),
  KEY `dom_num` (`dom_num`),
  KEY `usr_prf_num` (`usr_prf_num`),
  KEY `res_prf_num` (`res_prf_num`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acces_rights`
--


-- --------------------------------------------------------

--
-- Table structure for table `actes`
--

CREATE TABLE IF NOT EXISTS `actes` (
  `id_acte` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `date_acte` date NOT NULL DEFAULT '0000-00-00',
  `numero` varchar(25) NOT NULL DEFAULT '',
  `type_acte` int(3) unsigned NOT NULL DEFAULT '0',
  `statut` int(3) unsigned NOT NULL DEFAULT '0',
  `date_paiement` date NOT NULL DEFAULT '0000-00-00',
  `num_paiement` varchar(255) NOT NULL DEFAULT '',
  `num_entite` int(5) unsigned NOT NULL DEFAULT '0',
  `num_fournisseur` int(5) unsigned NOT NULL DEFAULT '0',
  `num_contact_livr` int(8) unsigned NOT NULL DEFAULT '0',
  `num_contact_fact` int(8) unsigned NOT NULL DEFAULT '0',
  `num_exercice` int(8) unsigned NOT NULL DEFAULT '0',
  `commentaires` text NOT NULL,
  `reference` varchar(255) NOT NULL DEFAULT '',
  `index_acte` text NOT NULL,
  `devise` varchar(25) NOT NULL DEFAULT '',
  `commentaires_i` text NOT NULL,
  `date_valid` date NOT NULL DEFAULT '0000-00-00',
  `date_ech` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id_acte`),
  KEY `num_fournisseur` (`num_fournisseur`),
  KEY `date` (`date_acte`),
  KEY `num_entite` (`num_entite`),
  KEY `numero` (`numero`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `actes`
--


-- --------------------------------------------------------

--
-- Table structure for table `admin_session`
--

CREATE TABLE IF NOT EXISTS `admin_session` (
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `session` blob,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_session`
--


-- --------------------------------------------------------

--
-- Table structure for table `analysis`
--

CREATE TABLE IF NOT EXISTS `analysis` (
  `analysis_bulletin` int(8) unsigned NOT NULL DEFAULT '0',
  `analysis_notice` int(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`analysis_bulletin`,`analysis_notice`),
  KEY `analysis_notice` (`analysis_notice`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `analysis`
--


-- --------------------------------------------------------

--
-- Table structure for table `arch_emplacement`
--

CREATE TABLE IF NOT EXISTS `arch_emplacement` (
  `archempla_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `archempla_libelle` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`archempla_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `arch_emplacement`
--


-- --------------------------------------------------------

--
-- Table structure for table `arch_statut`
--

CREATE TABLE IF NOT EXISTS `arch_statut` (
  `archstatut_id` int(8) NOT NULL AUTO_INCREMENT,
  `archstatut_gestion_libelle` varchar(255) NOT NULL DEFAULT '',
  `archstatut_opac_libelle` varchar(255) NOT NULL,
  `archstatut_visible_opac` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `archstatut_visible_opac_abon` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `archstatut_visible_gestion` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `archstatut_class_html` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`archstatut_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `arch_statut`
--


-- --------------------------------------------------------

--
-- Table structure for table `arch_type`
--

CREATE TABLE IF NOT EXISTS `arch_type` (
  `archtype_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `archtype_libelle` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`archtype_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `arch_type`
--


-- --------------------------------------------------------

--
-- Table structure for table `audit`
--

CREATE TABLE IF NOT EXISTS `audit` (
  `type_obj` int(1) NOT NULL DEFAULT '0',
  `object_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(8) unsigned NOT NULL DEFAULT '0',
  `user_name` varchar(20) NOT NULL DEFAULT '',
  `type_modif` int(1) NOT NULL DEFAULT '1',
  `quand` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `type_obj` (`type_obj`),
  KEY `object_id` (`object_id`),
  KEY `user_id` (`user_id`),
  KEY `type_modif` (`type_modif`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `audit`
--


-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE IF NOT EXISTS `authors` (
  `author_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `author_type` enum('70','71','72') NOT NULL DEFAULT '70',
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_rejete` varchar(255) NOT NULL DEFAULT '',
  `author_date` varchar(255) NOT NULL DEFAULT '',
  `author_see` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author_web` varchar(255) NOT NULL DEFAULT '',
  `index_author` text,
  `author_comment` text,
  `author_lieu` varchar(255) NOT NULL DEFAULT '',
  `author_ville` varchar(255) NOT NULL DEFAULT '',
  `author_pays` varchar(255) NOT NULL DEFAULT '',
  `author_subdivision` varchar(255) NOT NULL DEFAULT '',
  `author_numero` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`author_id`),
  KEY `author_see` (`author_see`),
  KEY `author_name` (`author_name`),
  KEY `author_rejete` (`author_rejete`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `authors`
--


-- --------------------------------------------------------

--
-- Table structure for table `aut_link`
--

CREATE TABLE IF NOT EXISTS `aut_link` (
  `aut_link_from` int(2) NOT NULL DEFAULT '0',
  `aut_link_from_num` int(11) NOT NULL DEFAULT '0',
  `aut_link_to` int(2) NOT NULL DEFAULT '0',
  `aut_link_to_num` int(11) NOT NULL DEFAULT '0',
  `aut_link_type` int(2) NOT NULL DEFAULT '0',
  `aut_link_reciproc` int(1) NOT NULL DEFAULT '0',
  `aut_link_comment` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`aut_link_from`,`aut_link_from_num`,`aut_link_to`,`aut_link_to_num`,`aut_link_type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aut_link`
--


-- --------------------------------------------------------

--
-- Table structure for table `avis`
--

CREATE TABLE IF NOT EXISTS `avis` (
  `id_avis` mediumint(8) NOT NULL AUTO_INCREMENT,
  `num_empr` mediumint(8) NOT NULL DEFAULT '0',
  `num_notice` mediumint(8) NOT NULL DEFAULT '0',
  `note` int(3) DEFAULT NULL,
  `sujet` text,
  `commentaire` text,
  `dateajout` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `valide` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_avis`),
  KEY `avis_num_notice` (`num_notice`),
  KEY `avis_num_empr` (`num_empr`),
  KEY `avis_note` (`note`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `avis`
--


-- --------------------------------------------------------

--
-- Table structure for table `bannettes`
--

CREATE TABLE IF NOT EXISTS `bannettes` (
  `id_bannette` int(9) unsigned NOT NULL AUTO_INCREMENT,
  `num_classement` int(8) unsigned NOT NULL DEFAULT '1',
  `nom_bannette` varchar(255) NOT NULL DEFAULT '',
  `comment_gestion` varchar(255) NOT NULL DEFAULT '',
  `comment_public` varchar(255) NOT NULL DEFAULT '',
  `entete_mail` text NOT NULL,
  `date_last_remplissage` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_last_envoi` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `proprio_bannette` int(9) unsigned NOT NULL DEFAULT '0',
  `bannette_auto` int(1) unsigned NOT NULL DEFAULT '0',
  `periodicite` int(3) unsigned NOT NULL DEFAULT '7',
  `diffusion_email` int(1) unsigned NOT NULL DEFAULT '0',
  `categorie_lecteurs` int(8) unsigned NOT NULL DEFAULT '0',
  `nb_notices_diff` int(4) unsigned NOT NULL DEFAULT '0',
  `num_panier` int(8) unsigned NOT NULL DEFAULT '0',
  `limite_type` char(1) NOT NULL DEFAULT '',
  `limite_nombre` int(6) NOT NULL DEFAULT '0',
  `update_type` char(1) NOT NULL DEFAULT 'C',
  `typeexport` varchar(20) NOT NULL DEFAULT '',
  `prefixe_fichier` varchar(50) NOT NULL DEFAULT '',
  `param_export` blob NOT NULL,
  `piedpage_mail` text NOT NULL,
  `notice_tpl` int(10) unsigned NOT NULL DEFAULT '0',
  `group_pperso` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_bannette`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `bannettes`
--


-- --------------------------------------------------------

--
-- Table structure for table `bannette_abon`
--

CREATE TABLE IF NOT EXISTS `bannette_abon` (
  `num_bannette` int(9) unsigned NOT NULL DEFAULT '0',
  `num_empr` int(9) unsigned NOT NULL DEFAULT '0',
  `actif` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`num_bannette`,`num_empr`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bannette_abon`
--


-- --------------------------------------------------------

--
-- Table structure for table `bannette_contenu`
--

CREATE TABLE IF NOT EXISTS `bannette_contenu` (
  `num_bannette` int(9) unsigned NOT NULL DEFAULT '0',
  `num_notice` int(9) unsigned NOT NULL DEFAULT '0',
  `date_ajout` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`num_bannette`,`num_notice`),
  KEY `date_ajout` (`date_ajout`),
  KEY `i_num_notice` (`num_notice`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bannette_contenu`
--


-- --------------------------------------------------------

--
-- Table structure for table `bannette_equation`
--

CREATE TABLE IF NOT EXISTS `bannette_equation` (
  `num_bannette` int(9) unsigned NOT NULL DEFAULT '0',
  `num_equation` int(9) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`num_bannette`,`num_equation`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bannette_equation`
--


-- --------------------------------------------------------

--
-- Table structure for table `bannette_exports`
--

CREATE TABLE IF NOT EXISTS `bannette_exports` (
  `num_bannette` int(11) unsigned NOT NULL DEFAULT '0',
  `export_format` int(3) NOT NULL DEFAULT '0',
  `export_data` longblob NOT NULL,
  `export_nomfichier` varchar(255) DEFAULT '',
  PRIMARY KEY (`num_bannette`,`export_format`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bannette_exports`
--


-- --------------------------------------------------------

--
-- Table structure for table `budgets`
--

CREATE TABLE IF NOT EXISTS `budgets` (
  `id_budget` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `num_entite` int(5) unsigned NOT NULL DEFAULT '0',
  `num_exercice` int(8) unsigned NOT NULL DEFAULT '0',
  `libelle` varchar(255) NOT NULL DEFAULT '',
  `commentaires` text,
  `montant_global` float(8,2) unsigned NOT NULL DEFAULT '0.00',
  `seuil_alerte` int(3) unsigned NOT NULL DEFAULT '100',
  `statut` int(3) unsigned NOT NULL DEFAULT '0',
  `type_budget` int(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_budget`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `budgets`
--


-- --------------------------------------------------------

--
-- Table structure for table `bulletins`
--

CREATE TABLE IF NOT EXISTS `bulletins` (
  `bulletin_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `bulletin_numero` varchar(255) NOT NULL DEFAULT '',
  `bulletin_notice` int(8) NOT NULL DEFAULT '0',
  `mention_date` varchar(50) NOT NULL DEFAULT '',
  `date_date` date NOT NULL DEFAULT '0000-00-00',
  `bulletin_titre` text,
  `index_titre` text,
  `bulletin_cb` varchar(30) DEFAULT NULL,
  `num_notice` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`bulletin_id`),
  KEY `bulletin_numero` (`bulletin_numero`),
  KEY `bulletin_notice` (`bulletin_notice`),
  KEY `date_date` (`date_date`),
  KEY `i_num_notice` (`num_notice`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `bulletins`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_amendes`
--

CREATE TABLE IF NOT EXISTS `cache_amendes` (
  `id_empr` int(10) unsigned NOT NULL DEFAULT '0',
  `cache_date` date NOT NULL DEFAULT '0000-00-00',
  `data_amendes` blob NOT NULL,
  KEY `id_empr` (`id_empr`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cache_amendes`
--

INSERT INTO `cache_amendes` (`id_empr`, `cache_date`, `data_amendes`) VALUES
(2, '2011-07-13', 0x613a303a7b7d);

-- --------------------------------------------------------

--
-- Table structure for table `caddie`
--

CREATE TABLE IF NOT EXISTS `caddie` (
  `idcaddie` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'NOTI',
  `comment` varchar(255) DEFAULT NULL,
  `autorisations` mediumtext,
  PRIMARY KEY (`idcaddie`),
  KEY `caddie_type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `caddie`
--

INSERT INTO `caddie` (`idcaddie`, `name`, `type`, `comment`, `autorisations`) VALUES
(1, 'Lajmerimet', 'NOTI', 'Vendosni ketu lajmerimet', '1 2'),
(2, 'Materialet per lajmerime', 'NOTI', 'Vendosni ne kete shporte materialet per lajmerim', '1 2'),
(3, 'Materiale per tu kthyer', 'EXPL', 'Vendosni ne kete shporte materialet per tu kthyer', '1 2'),
(4, 'Materialet e duplikuara ne titull', 'NOTI', 'Materialet e duplikuara ne titull', '1 2');

-- --------------------------------------------------------

--
-- Table structure for table `caddie_content`
--

CREATE TABLE IF NOT EXISTS `caddie_content` (
  `caddie_id` int(8) unsigned NOT NULL DEFAULT '0',
  `object_id` int(10) unsigned NOT NULL DEFAULT '0',
  `content` varchar(100) NOT NULL DEFAULT '',
  `blob_type` varchar(100) DEFAULT '',
  `flag` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`caddie_id`,`object_id`,`content`),
  KEY `object_id` (`object_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `caddie_content`
--


-- --------------------------------------------------------

--
-- Table structure for table `caddie_procs`
--

CREATE TABLE IF NOT EXISTS `caddie_procs` (
  `idproc` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL DEFAULT 'SELECT',
  `name` varchar(255) NOT NULL DEFAULT '',
  `requete` blob NOT NULL,
  `comment` tinytext NOT NULL,
  `autorisations` mediumtext,
  `parameters` text,
  PRIMARY KEY (`idproc`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `caddie_procs`
--

INSERT INTO `caddie_procs` (`idproc`, `type`, `name`, `requete`, `comment`, `autorisations`, `parameters`) VALUES
(3, 'SELECT', 'EXPL par section / propriétaire', 0x73656c656374206578706c5f6964206173206f626a6563745f69642c20274558504c27206173206f626a6563745f747970652066726f6d206578656d706c6169726573207768657265206578706c5f73656374696f6e20696e2028212173656374696f6e21212920616e64206578706c5f6f776e65723d212170726f7072696f2121, 'Sélection d''exemplaires par section par propriétaire', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="section" MANDATORY="yes">\n  <ALIAS><![CDATA[Section]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY><![CDATA[select idsection, section_libelle from docs_section order by section_libelle]]></QUERY>\r\n <MULTIPLE>yes</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""><![CDATA[]]></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n <FIELD NAME="proprio" MANDATORY="yes">\n  <ALIAS><![CDATA[Propriétaire]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY>select idlender, lender_libelle from lenders order by lender_libelle</QUERY>\r\n <MULTIPLE>no</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n</FIELDS>'),
(4, 'SELECT', 'EXPL où cote commence par', 0x73656c656374206578706c5f6964206173206f626a6563745f69642c20274558504c27206173206f626a6563745f747970652066726f6d206578656d706c6169726573207768657265206578706c5f636f7465206c696b6520272121636f6d6d655f636f746521212527, 'Sélection d''exemplaire à partir du début de cote', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="comme_cote" MANDATORY="no">\n  <ALIAS><![CDATA[Début de la cote]]></ALIAS>\n  <TYPE>text</TYPE>\n<OPTIONS FOR="text">\r\n <SIZE>20</SIZE>\r\n <MAXSIZE>20</MAXSIZE>\r\n</OPTIONS> \n </FIELD>\n</FIELDS>'),
(6, 'ACTION', 'Retour BDP des exemplaires', 0x757064617465206578656d706c616972657320736574206578706c5f7374617475743d21216e6f75766561755f7374617475742121207768657265206578706c5f696420696e2028434144444945284558504c2929, 'Permet de changer le statut des exemplaires d''un panier', '1 2 3', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="nouveau_statut" MANDATORY="yes">\n  <ALIAS><![CDATA[nouveau_statut]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY>SELECT idstatut, statut_libelle FROM docs_statut</QUERY>\r\n <MULTIPLE>no</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n</FIELDS>'),
(1, 'SELECT', 'Notices par auteur', 0x53454c454354206e6f746963655f6964206173206f626a6563745f69642c20274e4f544927206173206f626a6563745f747970652046524f4d206e6f74696365732c20617574686f72732c20726573706f6e736162696c69747920574845524520617574686f725f6e616d65206c696b652027252121637269746572652121252720414e4420617574686f725f69643d726573706f6e736162696c6974795f617574686f7220414e44206e6f746963655f69643d726573706f6e736162696c6974795f6e6f746963650d0a, 'Sélection des notices dont le nom de l''auteur contient certaines lettres', '1 2 3', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="critere" MANDATORY="yes">\n  <ALIAS><![CDATA[Caractères contenus dans le nom]]></ALIAS>\n  <TYPE>text</TYPE>\n<OPTIONS FOR="text">\r\n <SIZE>25</SIZE>\r\n <MAXSIZE>25</MAXSIZE>\r\n</OPTIONS>\n </FIELD>\n</FIELDS>'),
(2, 'SELECT', 'Notices en doublons', 0x6372656174652054454d504f52415259205441424c4520746d702053454c45435420746974312046524f4d206e6f74696365732047524f5550204259207469743120484156494e4720636f756e74282a293e310d0a53454c454354206e6f746963655f6964206173206f626a6563745f69642c20274e4f544927206173206f626a6563745f747970652046524f4d206e6f74696365732c20746d70207748455245206e6f74696365732e746974313d746d702e74697431, 'Sélection des notices en doublons sur le premier titre', '1 2 3', NULL),
(7, 'SELECT', 'Jamais prêtés', 0x53454c454354206578706c5f6964206173206f626a6563745f69642c20274558504c27206173206f626a6563745f747970652c20636f6e63617428224c4956524520222c74697431292061732054697472652046524f4d206e6f7469636573206a6f696e206578656d706c6169726573206f6e206578706c5f6e6f746963653d6e6f746963655f6964204c454654204a4f494e20707265745f61726368697665204f4e206172635f6578706c5f6e6f74696365203d206e6f746963655f6964207768657265206172635f6578706c5f6964204953204e554c4c20414e44206578706c5f6964204953204e4f54204e554c4c20554e494f4e2053454c454354206578706c5f6964206173206f626a6563745f69642c20274558504c27206173206f626a6563745f747970652c20636f6e6361742822504552494f20222c746974312c2022204e756de9726f203a20222c62756c6c6574696e5f6e756d65726f292061732054697472652046524f4d202862756c6c6574696e7320494e4e4552204a4f494e206e6f7469636573204f4e2062756c6c6574696e732e62756c6c6574696e5f6e6f74696365203d206e6f74696365732e6e6f746963655f69642920494e4e4552204a4f494e206578656d706c6169726573206f6e206578706c5f62756c6c6574696e3d62756c6c6574696e5f6964204c454654204a4f494e20707265745f61726368697665204f4e206578706c5f6964203d206172635f6578706c5f696420574845524520707265745f617263686976652e6172635f6964204973204e756c6c, 'Ajoute dans un panier les exemplaires jamais prêtés', '1 2', NULL),
(8, 'SELECT', 'Sélection d''exemplaires par statut', 0x73656c656374206578706c5f6964206173206f626a6563745f69642c20274558504c27206173206f626a6563745f747970652066726f6d206578656d706c6169726573207768657265206578706c5f73746174757420696e20282121737461747574212129, '', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="statut" MANDATORY="yes">\n  <ALIAS><![CDATA[statut]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY><![CDATA[select idstatut, statut_libelle from docs_statut]]></QUERY>\r\n <MULTIPLE>no</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""><![CDATA[]]></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n</FIELDS>'),
(9, 'SELECT', 'Sélection d''exemplaires par localisation, section, statut, propriétaire', 0x73656c656374206578706c5f6964206173206f626a6563745f69642c20274558504c27206173206f626a6563745f747970652066726f6d206578656d706c6169726573207768657265206578706c5f73656374696f6e20696e2028212173656374696f6e21212920616e64206578706c5f6c6f636174696f6e20696e202821216c6f636174696f6e21212920616e64206578706c5f73746174757420696e2028212173746174757421212920616e64206578706c5f6f776e65723d212170726f7072696f21212020, '', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="section" MANDATORY="yes">\n  <ALIAS><![CDATA[Section]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY><![CDATA[select idsection, section_libelle from docs_section order by 2]]></QUERY>\r\n <MULTIPLE>yes</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""><![CDATA[]]></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n <FIELD NAME="location" MANDATORY="yes">\n  <ALIAS><![CDATA[Localisation]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY><![CDATA[select idlocation, location_libelle from docs_location order by 2]]></QUERY>\r\n <MULTIPLE>yes</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""><![CDATA[]]></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n <FIELD NAME="statut" MANDATORY="yes">\n  <ALIAS><![CDATA[Statut]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY><![CDATA[select idstatut, statut_libelle from docs_statut order by 2]]></QUERY>\r\n <MULTIPLE>yes</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""><![CDATA[]]></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n <FIELD NAME="proprio" MANDATORY="yes">\n  <ALIAS><![CDATA[Propriétaire]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY><![CDATA[select idlender, lender_libelle from lenders order by 2]]></QUERY>\r\n <MULTIPLE>no</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""><![CDATA[]]></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n</FIELDS>');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `num_thesaurus` int(3) unsigned NOT NULL DEFAULT '1',
  `num_noeud` int(9) unsigned NOT NULL DEFAULT '0',
  `langue` varchar(5) NOT NULL DEFAULT 'fr_FR',
  `libelle_categorie` text NOT NULL,
  `note_application` text NOT NULL,
  `comment_public` text NOT NULL,
  `comment_voir` text NOT NULL,
  `index_categorie` text NOT NULL,
  `path_word_categ` text NOT NULL,
  `index_path_word_categ` text NOT NULL,
  PRIMARY KEY (`num_noeud`,`langue`),
  KEY `categ_langue` (`langue`),
  KEY `libelle_categorie` (`libelle_categorie`(5))
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`num_thesaurus`, `num_noeud`, `langue`, `libelle_categorie`, `note_application`, `comment_public`, `comment_voir`, `index_categorie`, `path_word_categ`, `index_path_word_categ`) VALUES
(1, 2, 'sq_AL', '~terma te pa klasifikuar', '', '', '', ' terma te pa klasifikuar ', '', ''),
(1, 3, 'sq_AL', '~terma jetim', '', '', '', ' terma jetim ', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `classements`
--

CREATE TABLE IF NOT EXISTS `classements` (
  `id_classement` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `type_classement` char(3) NOT NULL DEFAULT 'BAN',
  `nom_classement` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_classement`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `classements`
--

INSERT INTO `classements` (`id_classement`, `type_classement`, `nom_classement`) VALUES
(1, '', '_PA KLASIFIKUAR_');

-- --------------------------------------------------------

--
-- Table structure for table `collections`
--

CREATE TABLE IF NOT EXISTS `collections` (
  `collection_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `collection_name` varchar(255) NOT NULL DEFAULT '',
  `collection_parent` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `collection_issn` varchar(12) NOT NULL DEFAULT '',
  `index_coll` text,
  `collection_web` text NOT NULL,
  `collection_comment` text NOT NULL,
  PRIMARY KEY (`collection_id`),
  KEY `collection_name` (`collection_name`),
  KEY `collection_parent` (`collection_parent`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `collections`
--


-- --------------------------------------------------------

--
-- Table structure for table `collections_state`
--

CREATE TABLE IF NOT EXISTS `collections_state` (
  `collstate_id` int(8) NOT NULL AUTO_INCREMENT,
  `id_serial` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `location_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `state_collections` text NOT NULL,
  `collstate_emplacement` int(8) unsigned NOT NULL DEFAULT '0',
  `collstate_type` int(8) unsigned NOT NULL DEFAULT '0',
  `collstate_origine` varchar(255) NOT NULL DEFAULT '',
  `collstate_cote` varchar(255) NOT NULL DEFAULT '',
  `collstate_archive` varchar(255) NOT NULL DEFAULT '',
  `collstate_statut` int(8) unsigned NOT NULL DEFAULT '0',
  `collstate_lacune` text NOT NULL,
  `collstate_note` text NOT NULL,
  PRIMARY KEY (`collstate_id`),
  KEY `i_colls_arc` (`collstate_archive`),
  KEY `i_colls_empl` (`collstate_emplacement`),
  KEY `i_colls_type` (`collstate_type`),
  KEY `i_colls_orig` (`collstate_origine`),
  KEY `i_colls_cote` (`collstate_cote`),
  KEY `i_colls_stat` (`collstate_statut`),
  KEY `i_colls_serial` (`id_serial`),
  KEY `i_colls_loc` (`location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `collections_state`
--


-- --------------------------------------------------------

--
-- Table structure for table `collstate_custom`
--

CREATE TABLE IF NOT EXISTS `collstate_custom` (
  `idchamp` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `titre` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(10) NOT NULL DEFAULT 'text',
  `datatype` varchar(10) NOT NULL DEFAULT '',
  `options` text,
  `multiple` int(11) NOT NULL DEFAULT '0',
  `obligatoire` int(11) NOT NULL DEFAULT '0',
  `ordre` int(11) NOT NULL DEFAULT '0',
  `search` int(11) NOT NULL DEFAULT '0',
  `export` int(1) unsigned NOT NULL DEFAULT '0',
  `exclusion_obligatoire` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idchamp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `collstate_custom`
--


-- --------------------------------------------------------

--
-- Table structure for table `collstate_custom_lists`
--

CREATE TABLE IF NOT EXISTS `collstate_custom_lists` (
  `collstate_custom_champ` int(10) unsigned NOT NULL DEFAULT '0',
  `collstate_custom_list_value` varchar(255) NOT NULL DEFAULT '',
  `collstate_custom_list_lib` varchar(255) NOT NULL DEFAULT '',
  `ordre` int(11) NOT NULL DEFAULT '0',
  KEY `collstate_custom_champ` (`collstate_custom_champ`),
  KEY `i_ccl_lv` (`collstate_custom_list_value`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `collstate_custom_lists`
--


-- --------------------------------------------------------

--
-- Table structure for table `collstate_custom_values`
--

CREATE TABLE IF NOT EXISTS `collstate_custom_values` (
  `collstate_custom_champ` int(10) unsigned NOT NULL DEFAULT '0',
  `collstate_custom_origine` int(10) unsigned NOT NULL DEFAULT '0',
  `collstate_custom_small_text` varchar(255) DEFAULT NULL,
  `collstate_custom_text` text,
  `collstate_custom_integer` int(11) DEFAULT NULL,
  `collstate_custom_date` date DEFAULT NULL,
  `collstate_custom_float` float DEFAULT NULL,
  KEY `collstate_custom_champ` (`collstate_custom_champ`),
  KEY `collstate_custom_origine` (`collstate_custom_origine`),
  KEY `i_ccv_st` (`collstate_custom_small_text`),
  KEY `i_ccv_t` (`collstate_custom_text`(255)),
  KEY `i_ccv_i` (`collstate_custom_integer`),
  KEY `i_ccv_d` (`collstate_custom_date`),
  KEY `i_ccv_f` (`collstate_custom_float`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `collstate_custom_values`
--


-- --------------------------------------------------------

--
-- Table structure for table `comptes`
--

CREATE TABLE IF NOT EXISTS `comptes` (
  `id_compte` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL DEFAULT '',
  `type_compte_id` int(10) unsigned NOT NULL DEFAULT '0',
  `solde` decimal(16,2) DEFAULT '0.00',
  `prepay_mnt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `proprio_id` int(10) unsigned NOT NULL DEFAULT '0',
  `droits` text NOT NULL,
  PRIMARY KEY (`id_compte`),
  KEY `i_cpt_proprio_id` (`proprio_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `comptes`
--


-- --------------------------------------------------------

--
-- Table structure for table `connectors`
--

CREATE TABLE IF NOT EXISTS `connectors` (
  `connector_id` varchar(20) NOT NULL DEFAULT '',
  `parameters` text NOT NULL,
  `repository` int(11) NOT NULL DEFAULT '0',
  `timeout` int(11) NOT NULL DEFAULT '5',
  `retry` int(11) NOT NULL DEFAULT '3',
  `ttl` int(11) NOT NULL DEFAULT '1440',
  PRIMARY KEY (`connector_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `connectors`
--


-- --------------------------------------------------------

--
-- Table structure for table `connectors_categ`
--

CREATE TABLE IF NOT EXISTS `connectors_categ` (
  `connectors_categ_id` smallint(5) NOT NULL AUTO_INCREMENT,
  `connectors_categ_name` varchar(64) NOT NULL DEFAULT '',
  `opac_expanded` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`connectors_categ_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `connectors_categ`
--


-- --------------------------------------------------------

--
-- Table structure for table `connectors_categ_sources`
--

CREATE TABLE IF NOT EXISTS `connectors_categ_sources` (
  `num_categ` smallint(6) NOT NULL DEFAULT '0',
  `num_source` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`num_categ`,`num_source`),
  KEY `i_num_source` (`num_source`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `connectors_categ_sources`
--


-- --------------------------------------------------------

--
-- Table structure for table `connectors_out`
--

CREATE TABLE IF NOT EXISTS `connectors_out` (
  `connectors_out_id` int(11) NOT NULL AUTO_INCREMENT,
  `connectors_out_config` longblob NOT NULL,
  PRIMARY KEY (`connectors_out_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `connectors_out`
--


-- --------------------------------------------------------

--
-- Table structure for table `connectors_out_oai_tokens`
--

CREATE TABLE IF NOT EXISTS `connectors_out_oai_tokens` (
  `connectors_out_oai_token_token` varchar(32) NOT NULL,
  `connectors_out_oai_token_environnement` text NOT NULL,
  `connectors_out_oai_token_expirationdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`connectors_out_oai_token_token`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `connectors_out_oai_tokens`
--


-- --------------------------------------------------------

--
-- Table structure for table `connectors_out_setcaches`
--

CREATE TABLE IF NOT EXISTS `connectors_out_setcaches` (
  `connectors_out_setcache_id` int(11) NOT NULL AUTO_INCREMENT,
  `connectors_out_setcache_setnum` int(11) NOT NULL DEFAULT '0',
  `connectors_out_setcache_lifeduration` int(4) NOT NULL DEFAULT '0',
  `connectors_out_setcache_lifeduration_unit` enum('seconds','minutes','hours','days','weeks','months') NOT NULL DEFAULT 'seconds',
  `connectors_out_setcache_lastupdatedate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`connectors_out_setcache_id`),
  UNIQUE KEY `connectors_out_setcache_setnum` (`connectors_out_setcache_setnum`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `connectors_out_setcaches`
--


-- --------------------------------------------------------

--
-- Table structure for table `connectors_out_setcache_values`
--

CREATE TABLE IF NOT EXISTS `connectors_out_setcache_values` (
  `connectors_out_setcache_values_cachenum` int(11) NOT NULL DEFAULT '0',
  `connectors_out_setcache_values_value` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`connectors_out_setcache_values_cachenum`,`connectors_out_setcache_values_value`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `connectors_out_setcache_values`
--


-- --------------------------------------------------------

--
-- Table structure for table `connectors_out_setcategs`
--

CREATE TABLE IF NOT EXISTS `connectors_out_setcategs` (
  `connectors_out_setcateg_id` int(11) NOT NULL AUTO_INCREMENT,
  `connectors_out_setcateg_name` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`connectors_out_setcateg_id`),
  UNIQUE KEY `connectors_out_setcateg_name` (`connectors_out_setcateg_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `connectors_out_setcategs`
--


-- --------------------------------------------------------

--
-- Table structure for table `connectors_out_setcateg_sets`
--

CREATE TABLE IF NOT EXISTS `connectors_out_setcateg_sets` (
  `connectors_out_setcategset_setnum` int(11) NOT NULL,
  `connectors_out_setcategset_categnum` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`connectors_out_setcategset_setnum`,`connectors_out_setcategset_categnum`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `connectors_out_setcateg_sets`
--


-- --------------------------------------------------------

--
-- Table structure for table `connectors_out_sets`
--

CREATE TABLE IF NOT EXISTS `connectors_out_sets` (
  `connector_out_set_id` int(11) NOT NULL AUTO_INCREMENT,
  `connector_out_set_caption` varchar(100) NOT NULL DEFAULT '',
  `connector_out_set_type` int(4) NOT NULL DEFAULT '0',
  `connector_out_set_config` longblob NOT NULL,
  PRIMARY KEY (`connector_out_set_id`),
  UNIQUE KEY `connector_out_set_caption` (`connector_out_set_caption`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `connectors_out_sets`
--


-- --------------------------------------------------------

--
-- Table structure for table `connectors_out_sources`
--

CREATE TABLE IF NOT EXISTS `connectors_out_sources` (
  `connectors_out_source_id` int(11) NOT NULL AUTO_INCREMENT,
  `connectors_out_sources_connectornum` int(11) NOT NULL DEFAULT '0',
  `connectors_out_source_name` varchar(100) NOT NULL DEFAULT '',
  `connectors_out_source_comment` varchar(200) NOT NULL DEFAULT '',
  `connectors_out_source_config` longblob NOT NULL,
  PRIMARY KEY (`connectors_out_source_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `connectors_out_sources`
--


-- --------------------------------------------------------

--
-- Table structure for table `connectors_out_sources_esgroups`
--

CREATE TABLE IF NOT EXISTS `connectors_out_sources_esgroups` (
  `connectors_out_source_esgroup_sourcenum` int(11) NOT NULL DEFAULT '0',
  `connectors_out_source_esgroup_esgroupnum` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`connectors_out_source_esgroup_sourcenum`,`connectors_out_source_esgroup_esgroupnum`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `connectors_out_sources_esgroups`
--


-- --------------------------------------------------------

--
-- Table structure for table `connectors_sources`
--

CREATE TABLE IF NOT EXISTS `connectors_sources` (
  `source_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_connector` varchar(20) NOT NULL DEFAULT '',
  `parameters` mediumtext NOT NULL,
  `comment` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `repository` int(11) NOT NULL DEFAULT '0',
  `timeout` int(11) NOT NULL DEFAULT '5',
  `retry` int(11) NOT NULL DEFAULT '3',
  `ttl` int(11) NOT NULL DEFAULT '1440',
  `opac_allowed` int(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`source_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `connectors_sources`
--


-- --------------------------------------------------------

--
-- Table structure for table `coordonnees`
--

CREATE TABLE IF NOT EXISTS `coordonnees` (
  `id_contact` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `type_coord` int(1) unsigned NOT NULL DEFAULT '0',
  `num_entite` int(5) unsigned NOT NULL DEFAULT '0',
  `libelle` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) NOT NULL DEFAULT '',
  `adr1` varchar(255) NOT NULL DEFAULT '',
  `adr2` varchar(255) NOT NULL DEFAULT '',
  `cp` varchar(15) NOT NULL DEFAULT '',
  `ville` varchar(100) NOT NULL DEFAULT '',
  `etat` varchar(100) NOT NULL DEFAULT '',
  `pays` varchar(100) NOT NULL DEFAULT '',
  `tel1` varchar(100) NOT NULL DEFAULT '',
  `tel2` varchar(100) NOT NULL DEFAULT '',
  `fax` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `commentaires` text,
  PRIMARY KEY (`id_contact`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `coordonnees`
--


-- --------------------------------------------------------

--
-- Table structure for table `demandes`
--

CREATE TABLE IF NOT EXISTS `demandes` (
  `id_demande` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `num_demandeur` mediumint(8) NOT NULL DEFAULT '0',
  `theme_demande` int(3) NOT NULL DEFAULT '0',
  `type_demande` int(3) NOT NULL DEFAULT '0',
  `etat_demande` int(3) NOT NULL DEFAULT '0',
  `date_demande` date NOT NULL DEFAULT '0000-00-00',
  `date_prevue` date NOT NULL DEFAULT '0000-00-00',
  `deadline_demande` date NOT NULL DEFAULT '0000-00-00',
  `titre_demande` varchar(255) NOT NULL DEFAULT '',
  `sujet_demande` text NOT NULL,
  `progression` mediumint(3) NOT NULL DEFAULT '0',
  `num_user_cloture` mediumint(3) NOT NULL DEFAULT '0',
  `num_notice` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_demande`),
  KEY `i_num_demandeur` (`num_demandeur`),
  KEY `i_date_demande` (`date_demande`),
  KEY `i_deadline_demande` (`deadline_demande`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `demandes`
--


-- --------------------------------------------------------

--
-- Table structure for table `demandes_actions`
--

CREATE TABLE IF NOT EXISTS `demandes_actions` (
  `id_action` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_action` int(3) NOT NULL DEFAULT '0',
  `statut_action` int(3) NOT NULL DEFAULT '0',
  `sujet_action` varchar(255) NOT NULL DEFAULT '',
  `detail_action` text NOT NULL,
  `date_action` date NOT NULL DEFAULT '0000-00-00',
  `deadline_action` date NOT NULL DEFAULT '0000-00-00',
  `temps_passe` float DEFAULT NULL,
  `cout` mediumint(3) NOT NULL DEFAULT '0',
  `progression_action` mediumint(3) NOT NULL DEFAULT '0',
  `prive_action` int(1) NOT NULL DEFAULT '0',
  `num_demande` int(10) NOT NULL DEFAULT '0',
  `actions_num_user` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `actions_type_user` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `actions_read` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_action`),
  KEY `i_date_action` (`date_action`),
  KEY `i_deadline_action` (`deadline_action`),
  KEY `i_num_demande` (`num_demande`),
  KEY `i_actions_user` (`actions_num_user`,`actions_type_user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `demandes_actions`
--


-- --------------------------------------------------------

--
-- Table structure for table `demandes_notes`
--

CREATE TABLE IF NOT EXISTS `demandes_notes` (
  `id_note` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `prive` int(1) NOT NULL DEFAULT '0',
  `rapport` int(1) NOT NULL DEFAULT '0',
  `contenu` text NOT NULL,
  `date_note` date NOT NULL DEFAULT '0000-00-00',
  `num_action` int(10) NOT NULL DEFAULT '0',
  `num_note_parent` int(10) NOT NULL DEFAULT '0',
  `notes_num_user` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `notes_type_user` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_note`),
  KEY `i_date_note` (`date_note`),
  KEY `i_num_action` (`num_action`),
  KEY `i_num_note_parent` (`num_note_parent`),
  KEY `i_notes_user` (`notes_num_user`,`notes_type_user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `demandes_notes`
--


-- --------------------------------------------------------

--
-- Table structure for table `demandes_theme`
--

CREATE TABLE IF NOT EXISTS `demandes_theme` (
  `id_theme` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle_theme` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_theme`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `demandes_theme`
--


-- --------------------------------------------------------

--
-- Table structure for table `demandes_type`
--

CREATE TABLE IF NOT EXISTS `demandes_type` (
  `id_type` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `libelle_type` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `demandes_type`
--


-- --------------------------------------------------------

--
-- Table structure for table `demandes_users`
--

CREATE TABLE IF NOT EXISTS `demandes_users` (
  `num_user` int(10) NOT NULL DEFAULT '0',
  `num_demande` int(10) NOT NULL DEFAULT '0',
  `date_creation` date NOT NULL DEFAULT '0000-00-00',
  `users_statut` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`num_user`,`num_demande`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `demandes_users`
--


-- --------------------------------------------------------

--
-- Table structure for table `docsloc_section`
--

CREATE TABLE IF NOT EXISTS `docsloc_section` (
  `num_section` int(5) unsigned NOT NULL DEFAULT '0',
  `num_location` int(5) unsigned NOT NULL DEFAULT '0',
  `num_pclass` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`num_section`,`num_location`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `docsloc_section`
--


-- --------------------------------------------------------

--
-- Table structure for table `docs_codestat`
--

CREATE TABLE IF NOT EXISTS `docs_codestat` (
  `idcode` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `codestat_libelle` varchar(255) DEFAULT NULL,
  `statisdoc_codage_import` char(2) NOT NULL DEFAULT '',
  `statisdoc_owner` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idcode`),
  KEY `statisdoc_owner` (`statisdoc_owner`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `docs_codestat`
--

INSERT INTO `docs_codestat` (`idcode`, `codestat_libelle`, `statisdoc_codage_import`, `statisdoc_owner`) VALUES
(10, 'Pa percaktuar', 'p', 0),
(11, 'Rinj', 'r', 0),
(12, 'Rritur', 'rr', 0);

-- --------------------------------------------------------

--
-- Table structure for table `docs_location`
--

CREATE TABLE IF NOT EXISTS `docs_location` (
  `idlocation` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `location_libelle` varchar(255) DEFAULT NULL,
  `locdoc_codage_import` varchar(255) NOT NULL DEFAULT '',
  `locdoc_owner` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `location_pic` varchar(255) NOT NULL DEFAULT '',
  `location_visible_opac` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL DEFAULT '',
  `adr1` varchar(255) NOT NULL DEFAULT '',
  `adr2` varchar(255) NOT NULL DEFAULT '',
  `cp` varchar(15) NOT NULL DEFAULT '',
  `town` varchar(100) NOT NULL DEFAULT '',
  `state` varchar(100) NOT NULL DEFAULT '',
  `country` varchar(100) NOT NULL DEFAULT '',
  `phone` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `website` varchar(100) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `commentaire` text NOT NULL,
  `transfert_ordre` smallint(2) unsigned NOT NULL DEFAULT '9999',
  `transfert_statut_defaut` smallint(5) unsigned NOT NULL DEFAULT '0',
  `num_infopage` int(6) unsigned NOT NULL DEFAULT '0',
  `css_style` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`idlocation`),
  KEY `locdoc_owner` (`locdoc_owner`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `docs_location`
--

INSERT INTO `docs_location` (`idlocation`, `location_libelle`, `locdoc_codage_import`, `locdoc_owner`, `location_pic`, `location_visible_opac`, `name`, `adr1`, `adr2`, `cp`, `town`, `state`, `country`, `phone`, `email`, `website`, `logo`, `commentaire`, `transfert_ordre`, `transfert_statut_defaut`, `num_infopage`, `css_style`) VALUES
(1, 'Kati Pare', '', 0, '', 1, '', '', '', '', '', '', '', '', '', '', '', '', 9999, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `docs_section`
--

CREATE TABLE IF NOT EXISTS `docs_section` (
  `idsection` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `section_libelle` varchar(255) DEFAULT NULL,
  `sdoc_codage_import` varchar(255) NOT NULL DEFAULT '',
  `sdoc_owner` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `section_pic` varchar(255) NOT NULL DEFAULT '',
  `section_visible_opac` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`idsection`),
  KEY `sdoc_owner` (`sdoc_owner`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `docs_section`
--

INSERT INTO `docs_section` (`idsection`, `section_libelle`, `sdoc_codage_import`, `sdoc_owner`, `section_pic`, `section_visible_opac`) VALUES
(10, 'Dokumentar', '', 2, 'images/site/documentaire.jpg', 1),
(11, 'Dokumentar femije', '', 2, 'images/site/documentaire.jpg', 1),
(12, 'Romane per femije', '', 2, 'images/site/enfants.jpg', 1),
(13, 'Romane per te rinj', '', 2, 'images/site/sec3.jpg', 1),
(16, 'Strip per te rritur', '', 2, 'images/site/sec1.jpg', 1),
(17, 'Strip per femije', '', 2, 'images/site/enfants.jpg', 1),
(18, 'H (Histori Lokale)', '', 2, 'images/site/histoire.jpg', 1),
(19, 'FR (Fonde Rajonale)', '', 2, 'images/site/sec4.jpg', 1),
(20, 'Strip per te rinj', '', 2, 'images/site/sec3.jpg', 1),
(21, 'Romane policor', '', 2, 'images/site/sec1.jpg', 1),
(23, 'Romane me tematike te gjere', '', 2, 'images/site/large_vue.jpg', 1),
(24, 'Romane & Romane te huaj', '', 2, 'images/site/sec1.jpg', 1),
(25, 'Dokumentar per te rinj', '', 2, 'images/site/documentaire.jpg', 1),
(26, 'Album per femije', '', 2, 'images/site/enfants.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `docs_statut`
--

CREATE TABLE IF NOT EXISTS `docs_statut` (
  `idstatut` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `statut_libelle` varchar(255) DEFAULT NULL,
  `pret_flag` tinyint(4) NOT NULL DEFAULT '1',
  `statusdoc_codage_import` char(2) NOT NULL DEFAULT '',
  `statusdoc_owner` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `transfert_flag` tinyint(4) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`idstatut`),
  KEY `statusdoc_owner` (`statusdoc_owner`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `docs_statut`
--

INSERT INTO `docs_statut` (`idstatut`, `statut_libelle`, `pret_flag`, `statusdoc_codage_import`, `statusdoc_owner`, `transfert_flag`) VALUES
(1, 'Ne gjendje te mire', 1, '', 0, 0),
(2, 'Ne importim/katalogim', 0, '', 0, 0),
(11, 'Demtuar', 0, '', 0, 0),
(12, 'Humbur', 0, '', 0, 0),
(13, 'Konsultim ne vend', 0, '', 0, 0),
(14, 'Ne depo', 0, '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `docs_type`
--

CREATE TABLE IF NOT EXISTS `docs_type` (
  `idtyp_doc` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `tdoc_libelle` varchar(255) DEFAULT NULL,
  `duree_pret` smallint(6) NOT NULL DEFAULT '31',
  `duree_resa` int(6) unsigned NOT NULL DEFAULT '15',
  `tdoc_owner` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `tdoc_codage_import` varchar(255) NOT NULL DEFAULT '',
  `tarif_pret` decimal(16,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`idtyp_doc`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `docs_type`
--

INSERT INTO `docs_type` (`idtyp_doc`, `tdoc_libelle`, `duree_pret`, `duree_resa`, `tdoc_owner`, `tdoc_codage_import`, `tarif_pret`) VALUES
(1, 'Liber', 14, 15, 2, '', '0.00'),
(12, 'Kasete Video', 14, 15, 2, '', '0.00'),
(13, 'CD audio', 14, 15, 2, '', '0.00'),
(14, 'DVD', 5, 15, 2, '', '0.00'),
(15, 'Veper arti', 5, 15, 2, '', '0.00'),
(16, 'Harta dhe planimetri', 31, 15, 2, '', '0.00'),
(17, 'CD', 10, 5, 2, '', '0.00'),
(18, 'Periodik', 8, 5, 0, '', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `empr`
--

CREATE TABLE IF NOT EXISTS `empr` (
  `id_empr` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `empr_cb` varchar(255) DEFAULT NULL,
  `empr_nom` varchar(255) NOT NULL DEFAULT '',
  `empr_prenom` varchar(255) NOT NULL DEFAULT '',
  `empr_adr1` varchar(255) NOT NULL DEFAULT '',
  `empr_adr2` varchar(255) NOT NULL DEFAULT '',
  `empr_cp` varchar(10) NOT NULL DEFAULT '',
  `empr_ville` varchar(255) NOT NULL DEFAULT '',
  `empr_pays` varchar(255) NOT NULL DEFAULT '',
  `empr_mail` varchar(255) NOT NULL DEFAULT '',
  `empr_tel1` varchar(255) NOT NULL DEFAULT '',
  `empr_tel2` varchar(255) NOT NULL DEFAULT '',
  `empr_prof` varchar(255) NOT NULL DEFAULT '',
  `empr_year` int(4) unsigned NOT NULL DEFAULT '0',
  `empr_categ` smallint(5) unsigned NOT NULL DEFAULT '0',
  `empr_codestat` smallint(5) unsigned NOT NULL DEFAULT '0',
  `empr_creation` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `empr_modif` date NOT NULL DEFAULT '0000-00-00',
  `empr_sexe` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `empr_login` varchar(255) NOT NULL DEFAULT '',
  `empr_password` varchar(255) NOT NULL DEFAULT '',
  `empr_date_adhesion` date DEFAULT NULL,
  `empr_date_expiration` date DEFAULT NULL,
  `empr_msg` tinytext,
  `empr_lang` varchar(10) NOT NULL DEFAULT 'fr_FR',
  `empr_ldap` tinyint(1) unsigned DEFAULT '0',
  `type_abt` int(1) NOT NULL DEFAULT '0',
  `last_loan_date` date DEFAULT NULL,
  `empr_location` int(6) unsigned NOT NULL DEFAULT '1',
  `date_fin_blocage` date NOT NULL DEFAULT '0000-00-00',
  `total_loans` bigint(20) unsigned NOT NULL DEFAULT '0',
  `empr_statut` bigint(20) unsigned NOT NULL DEFAULT '1',
  `cle_validation` varchar(255) NOT NULL DEFAULT '',
  `empr_sms` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_empr`),
  UNIQUE KEY `empr_cb` (`empr_cb`),
  KEY `empr_nom` (`empr_nom`),
  KEY `empr_date_adhesion` (`empr_date_adhesion`),
  KEY `empr_date_expiration` (`empr_date_expiration`),
  KEY `i_empr_categ` (`empr_categ`),
  KEY `i_empr_codestat` (`empr_codestat`),
  KEY `i_empr_location` (`empr_location`),
  KEY `i_empr_statut` (`empr_statut`),
  KEY `i_empr_typabt` (`type_abt`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `empr`
--


-- --------------------------------------------------------

--
-- Table structure for table `empr_caddie`
--

CREATE TABLE IF NOT EXISTS `empr_caddie` (
  `idemprcaddie` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `autorisations` mediumtext,
  PRIMARY KEY (`idemprcaddie`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `empr_caddie`
--


-- --------------------------------------------------------

--
-- Table structure for table `empr_caddie_content`
--

CREATE TABLE IF NOT EXISTS `empr_caddie_content` (
  `empr_caddie_id` int(8) unsigned NOT NULL DEFAULT '0',
  `object_id` int(10) unsigned NOT NULL DEFAULT '0',
  `flag` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`empr_caddie_id`,`object_id`),
  KEY `object_id` (`object_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `empr_caddie_content`
--


-- --------------------------------------------------------

--
-- Table structure for table `empr_caddie_procs`
--

CREATE TABLE IF NOT EXISTS `empr_caddie_procs` (
  `idproc` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL DEFAULT 'SELECT',
  `name` varchar(255) NOT NULL DEFAULT '',
  `requete` blob NOT NULL,
  `comment` tinytext NOT NULL,
  `autorisations` mediumtext,
  `parameters` text,
  PRIMARY KEY (`idproc`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `empr_caddie_procs`
--


-- --------------------------------------------------------

--
-- Table structure for table `empr_categ`
--

CREATE TABLE IF NOT EXISTS `empr_categ` (
  `id_categ_empr` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL DEFAULT '',
  `duree_adhesion` int(10) unsigned DEFAULT '365',
  `tarif_abt` decimal(16,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id_categ_empr`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `empr_categ`
--

INSERT INTO `empr_categ` (`id_categ_empr`, `libelle`, `duree_adhesion`, `tarif_abt`) VALUES
(1, 'Femije', 365, '0.00'),
(2, 'Pensioniste', 365, '0.00'),
(3, 'Punetore', 365, '0.00'),
(4, 'Pa pune', 365, '0.00'),
(5, 'Studente', 365, '0.00'),
(6, 'Te rinj/shkolle e mesme', 365, '0.00'),
(7, 'Te rritur', 365, '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `empr_codestat`
--

CREATE TABLE IF NOT EXISTS `empr_codestat` (
  `idcode` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(50) NOT NULL DEFAULT 'DEFAULT',
  PRIMARY KEY (`idcode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `empr_codestat`
--

INSERT INTO `empr_codestat` (`idcode`, `libelle`) VALUES
(2, 'Bashkesi Komunash'),
(3, 'Komune'),
(4, 'Qark'),
(5, 'Europe'),
(6, 'Jasht Europes'),
(7, 'Shqiperi');

-- --------------------------------------------------------

--
-- Table structure for table `empr_custom`
--

CREATE TABLE IF NOT EXISTS `empr_custom` (
  `idchamp` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `titre` varchar(255) DEFAULT NULL,
  `type` varchar(10) NOT NULL DEFAULT 'text',
  `datatype` varchar(10) NOT NULL DEFAULT '',
  `options` text,
  `multiple` int(11) NOT NULL DEFAULT '0',
  `obligatoire` int(11) NOT NULL DEFAULT '0',
  `ordre` int(11) DEFAULT NULL,
  `search` int(1) unsigned NOT NULL DEFAULT '0',
  `export` int(1) unsigned NOT NULL DEFAULT '0',
  `exclusion_obligatoire` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idchamp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `empr_custom`
--


-- --------------------------------------------------------

--
-- Table structure for table `empr_custom_lists`
--

CREATE TABLE IF NOT EXISTS `empr_custom_lists` (
  `empr_custom_champ` int(10) unsigned NOT NULL DEFAULT '0',
  `empr_custom_list_value` varchar(255) DEFAULT NULL,
  `empr_custom_list_lib` varchar(255) DEFAULT NULL,
  `ordre` int(11) DEFAULT NULL,
  KEY `empr_custom_champ` (`empr_custom_champ`),
  KEY `i_ecl_lv` (`empr_custom_list_value`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `empr_custom_lists`
--


-- --------------------------------------------------------

--
-- Table structure for table `empr_custom_values`
--

CREATE TABLE IF NOT EXISTS `empr_custom_values` (
  `empr_custom_champ` int(10) unsigned NOT NULL DEFAULT '0',
  `empr_custom_origine` int(10) unsigned NOT NULL DEFAULT '0',
  `empr_custom_small_text` varchar(255) DEFAULT NULL,
  `empr_custom_text` text,
  `empr_custom_integer` int(11) DEFAULT NULL,
  `empr_custom_date` date DEFAULT NULL,
  `empr_custom_float` float DEFAULT NULL,
  KEY `empr_custom_champ` (`empr_custom_champ`),
  KEY `empr_custom_origine` (`empr_custom_origine`),
  KEY `i_ecv_st` (`empr_custom_small_text`),
  KEY `i_ecv_t` (`empr_custom_text`(255)),
  KEY `i_ecv_i` (`empr_custom_integer`),
  KEY `i_ecv_d` (`empr_custom_date`),
  KEY `i_ecv_f` (`empr_custom_float`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `empr_custom_values`
--


-- --------------------------------------------------------

--
-- Table structure for table `empr_groupe`
--

CREATE TABLE IF NOT EXISTS `empr_groupe` (
  `empr_id` int(6) unsigned NOT NULL DEFAULT '0',
  `groupe_id` int(6) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`empr_id`,`groupe_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `empr_groupe`
--


-- --------------------------------------------------------

--
-- Table structure for table `empr_statut`
--

CREATE TABLE IF NOT EXISTS `empr_statut` (
  `idstatut` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `statut_libelle` varchar(255) NOT NULL DEFAULT '',
  `allow_loan` tinyint(4) NOT NULL DEFAULT '1',
  `allow_loan_hist` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `allow_book` tinyint(4) NOT NULL DEFAULT '1',
  `allow_opac` tinyint(4) NOT NULL DEFAULT '1',
  `allow_dsi` tinyint(4) NOT NULL DEFAULT '1',
  `allow_dsi_priv` tinyint(4) NOT NULL DEFAULT '1',
  `allow_sugg` tinyint(4) NOT NULL DEFAULT '1',
  `allow_dema` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `allow_prol` tinyint(4) NOT NULL DEFAULT '1',
  `allow_avis` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `allow_tag` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `allow_pwd` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `allow_liste_lecture` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `allow_self_checkout` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `allow_self_checkin` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idstatut`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `empr_statut`
--

INSERT INTO `empr_statut` (`idstatut`, `statut_libelle`, `allow_loan`, `allow_loan_hist`, `allow_book`, `allow_opac`, `allow_dsi`, `allow_dsi_priv`, `allow_sugg`, `allow_dema`, `allow_prol`, `allow_avis`, `allow_tag`, `allow_pwd`, `allow_liste_lecture`, `allow_self_checkout`, `allow_self_checkin`) VALUES
(1, 'Aktiv', 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0),
(2, 'Bllokuar', 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `empty_words_calculs`
--

CREATE TABLE IF NOT EXISTS `empty_words_calculs` (
  `id_calcul` int(9) unsigned NOT NULL AUTO_INCREMENT,
  `date_calcul` date NOT NULL DEFAULT '0000-00-00',
  `php_empty_words` text NOT NULL,
  `nb_notices_calcul` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `archive_calcul` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_calcul`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `empty_words_calculs`
--


-- --------------------------------------------------------

--
-- Table structure for table `entites`
--

CREATE TABLE IF NOT EXISTS `entites` (
  `id_entite` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `type_entite` int(3) unsigned NOT NULL DEFAULT '0',
  `num_bibli` int(5) unsigned NOT NULL DEFAULT '0',
  `raison_sociale` varchar(255) NOT NULL DEFAULT '',
  `commentaires` text,
  `siret` varchar(255) NOT NULL,
  `naf` varchar(255) NOT NULL,
  `rcs` varchar(255) NOT NULL,
  `tva` varchar(255) NOT NULL,
  `num_cp_client` varchar(255) NOT NULL,
  `num_cp_compta` varchar(255) NOT NULL,
  `site_web` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL DEFAULT '',
  `autorisations` mediumtext NOT NULL,
  `num_frais` int(8) unsigned NOT NULL DEFAULT '0',
  `num_paiement` int(8) unsigned NOT NULL DEFAULT '0',
  `index_entite` text NOT NULL,
  PRIMARY KEY (`id_entite`),
  KEY `raison_sociale` (`raison_sociale`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `entites`
--


-- --------------------------------------------------------

--
-- Table structure for table `entrepots_localisations`
--

CREATE TABLE IF NOT EXISTS `entrepots_localisations` (
  `loc_id` int(11) NOT NULL AUTO_INCREMENT,
  `loc_code` varchar(255) NOT NULL DEFAULT '',
  `loc_libelle` varchar(255) NOT NULL DEFAULT '',
  `loc_visible` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`loc_id`),
  UNIQUE KEY `loc_code` (`loc_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `entrepots_localisations`
--


-- --------------------------------------------------------

--
-- Table structure for table `equations`
--

CREATE TABLE IF NOT EXISTS `equations` (
  `id_equation` int(9) unsigned NOT NULL AUTO_INCREMENT,
  `num_classement` int(8) unsigned NOT NULL DEFAULT '1',
  `nom_equation` varchar(255) NOT NULL DEFAULT '',
  `comment_equation` varchar(255) NOT NULL DEFAULT '',
  `requete` blob NOT NULL,
  `proprio_equation` int(9) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_equation`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `equations`
--


-- --------------------------------------------------------

--
-- Table structure for table `error_log`
--

CREATE TABLE IF NOT EXISTS `error_log` (
  `error_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `error_origin` varchar(255) DEFAULT NULL,
  `error_text` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `error_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `es_cache`
--

CREATE TABLE IF NOT EXISTS `es_cache` (
  `escache_groupname` varchar(100) NOT NULL DEFAULT '',
  `escache_unique_id` varchar(100) NOT NULL DEFAULT '',
  `escache_value` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`escache_groupname`,`escache_unique_id`,`escache_value`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `es_cache`
--


-- --------------------------------------------------------

--
-- Table structure for table `es_cache_blob`
--

CREATE TABLE IF NOT EXISTS `es_cache_blob` (
  `es_cache_objectref` varchar(100) NOT NULL DEFAULT '',
  `es_cache_objecttype` int(11) NOT NULL DEFAULT '0',
  `es_cache_objectformat` varchar(100) NOT NULL DEFAULT '',
  `es_cache_owner` varchar(100) NOT NULL DEFAULT '',
  `es_cache_creationdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `es_cache_expirationdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `es_cache_content` mediumblob NOT NULL,
  PRIMARY KEY (`es_cache_objectref`,`es_cache_objecttype`,`es_cache_objectformat`,`es_cache_owner`),
  KEY `cache_index` (`es_cache_owner`,`es_cache_objectformat`,`es_cache_objecttype`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `es_cache_blob`
--


-- --------------------------------------------------------

--
-- Table structure for table `es_cache_int`
--

CREATE TABLE IF NOT EXISTS `es_cache_int` (
  `es_cache_objectref` varchar(100) NOT NULL DEFAULT '',
  `es_cache_objecttype` int(11) NOT NULL DEFAULT '0',
  `es_cache_objectformat` varchar(100) NOT NULL DEFAULT '',
  `es_cache_owner` varchar(100) NOT NULL DEFAULT '',
  `es_cache_creationdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `es_cache_expirationdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `es_cache_content` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`es_cache_objectref`,`es_cache_objecttype`,`es_cache_objectformat`,`es_cache_owner`),
  KEY `cache_index` (`es_cache_owner`,`es_cache_objectformat`,`es_cache_objecttype`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `es_cache_int`
--


-- --------------------------------------------------------

--
-- Table structure for table `es_converted_cache`
--

CREATE TABLE IF NOT EXISTS `es_converted_cache` (
  `es_converted_cache_objecttype` int(11) NOT NULL DEFAULT '0',
  `es_converted_cache_objectref` int(11) NOT NULL DEFAULT '0',
  `es_converted_cache_format` varchar(50) NOT NULL DEFAULT '',
  `es_converted_cache_value` text NOT NULL,
  `es_converted_cache_bestbefore` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`es_converted_cache_objecttype`,`es_converted_cache_objectref`,`es_converted_cache_format`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `es_converted_cache`
--


-- --------------------------------------------------------

--
-- Table structure for table `es_esgroups`
--

CREATE TABLE IF NOT EXISTS `es_esgroups` (
  `esgroup_id` int(11) NOT NULL AUTO_INCREMENT,
  `esgroup_name` varchar(100) NOT NULL DEFAULT '',
  `esgroup_fullname` varchar(255) NOT NULL DEFAULT '',
  `esgroup_pmbusernum` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`esgroup_id`),
  UNIQUE KEY `esgroup_name` (`esgroup_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `es_esgroups`
--


-- --------------------------------------------------------

--
-- Table structure for table `es_esgroup_esusers`
--

CREATE TABLE IF NOT EXISTS `es_esgroup_esusers` (
  `esgroupuser_groupnum` int(11) NOT NULL DEFAULT '0',
  `esgroupuser_usertype` int(4) NOT NULL DEFAULT '0',
  `esgroupuser_usernum` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`esgroupuser_usernum`,`esgroupuser_groupnum`,`esgroupuser_usertype`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `es_esgroup_esusers`
--


-- --------------------------------------------------------

--
-- Table structure for table `es_esusers`
--

CREATE TABLE IF NOT EXISTS `es_esusers` (
  `esuser_id` int(11) NOT NULL AUTO_INCREMENT,
  `esuser_username` varchar(100) NOT NULL DEFAULT '',
  `esuser_password` varchar(100) NOT NULL DEFAULT '',
  `esuser_fullname` varchar(255) NOT NULL DEFAULT '',
  `esuser_groupnum` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`esuser_id`),
  UNIQUE KEY `esuser_username` (`esuser_username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `es_esusers`
--


-- --------------------------------------------------------

--
-- Table structure for table `es_methods`
--

CREATE TABLE IF NOT EXISTS `es_methods` (
  `id_method` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `groupe` varchar(255) NOT NULL DEFAULT '',
  `method` varchar(255) NOT NULL DEFAULT '',
  `available` smallint(5) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_method`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `es_methods`
--


-- --------------------------------------------------------

--
-- Table structure for table `es_methods_users`
--

CREATE TABLE IF NOT EXISTS `es_methods_users` (
  `num_method` int(10) unsigned NOT NULL DEFAULT '0',
  `num_user` int(10) unsigned NOT NULL DEFAULT '0',
  `anonymous` smallint(6) DEFAULT '0',
  PRIMARY KEY (`num_method`,`num_user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `es_methods_users`
--


-- --------------------------------------------------------

--
-- Table structure for table `es_searchcache`
--

CREATE TABLE IF NOT EXISTS `es_searchcache` (
  `es_searchcache_searchid` varchar(100) NOT NULL DEFAULT '',
  `es_searchcache_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `es_searchcache_serializedsearch` text NOT NULL,
  PRIMARY KEY (`es_searchcache_searchid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `es_searchcache`
--


-- --------------------------------------------------------

--
-- Table structure for table `es_searchsessions`
--

CREATE TABLE IF NOT EXISTS `es_searchsessions` (
  `es_searchsession_id` varchar(100) NOT NULL DEFAULT '',
  `es_searchsession_searchnum` varchar(100) NOT NULL DEFAULT '',
  `es_searchsession_searchrealm` varchar(100) NOT NULL DEFAULT '',
  `es_searchsession_pmbuserid` int(11) NOT NULL DEFAULT '-1',
  `es_searchsession_opacemprid` int(11) NOT NULL DEFAULT '-1',
  `es_searchsession_lastseendate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`es_searchsession_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `es_searchsessions`
--


-- --------------------------------------------------------

--
-- Table structure for table `etagere`
--

CREATE TABLE IF NOT EXISTS `etagere` (
  `idetagere` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `comment` blob NOT NULL,
  `validite` int(1) unsigned NOT NULL DEFAULT '0',
  `validite_date_deb` date NOT NULL DEFAULT '0000-00-00',
  `validite_date_fin` date NOT NULL DEFAULT '0000-00-00',
  `visible_accueil` int(1) unsigned NOT NULL DEFAULT '1',
  `autorisations` mediumtext,
  PRIMARY KEY (`idetagere`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `etagere`
--

INSERT INTO `etagere` (`idetagere`, `name`, `comment`, `validite`, `validite_date_deb`, `validite_date_fin`, `visible_accueil`, `autorisations`) VALUES
(1, 'A1', '', 1, '0000-00-00', '0000-00-00', 0, '1'),
(2, 'A2', '', 1, '0000-00-00', '0000-00-00', 1, '1 2');

-- --------------------------------------------------------

--
-- Table structure for table `etagere_caddie`
--

CREATE TABLE IF NOT EXISTS `etagere_caddie` (
  `etagere_id` int(8) unsigned NOT NULL DEFAULT '0',
  `caddie_id` int(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`etagere_id`,`caddie_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `etagere_caddie`
--


-- --------------------------------------------------------

--
-- Table structure for table `exemplaires`
--

CREATE TABLE IF NOT EXISTS `exemplaires` (
  `expl_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `expl_cb` varchar(50) NOT NULL DEFAULT '',
  `expl_notice` int(10) unsigned NOT NULL DEFAULT '0',
  `expl_bulletin` int(10) unsigned NOT NULL DEFAULT '0',
  `expl_typdoc` int(5) unsigned NOT NULL DEFAULT '0',
  `expl_cote` varchar(50) NOT NULL DEFAULT '',
  `expl_section` smallint(5) unsigned NOT NULL DEFAULT '0',
  `expl_statut` smallint(5) unsigned NOT NULL DEFAULT '0',
  `expl_location` smallint(5) unsigned NOT NULL DEFAULT '0',
  `expl_codestat` smallint(5) unsigned NOT NULL DEFAULT '0',
  `expl_date_depot` date NOT NULL DEFAULT '0000-00-00',
  `expl_date_retour` date NOT NULL DEFAULT '0000-00-00',
  `expl_note` tinytext NOT NULL,
  `expl_prix` varchar(255) NOT NULL DEFAULT '',
  `expl_owner` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `expl_lastempr` int(10) unsigned NOT NULL DEFAULT '0',
  `last_loan_date` date DEFAULT NULL,
  `create_date` datetime NOT NULL DEFAULT '2005-01-01 00:00:00',
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `type_antivol` int(1) unsigned NOT NULL DEFAULT '0',
  `transfert_location_origine` smallint(5) unsigned NOT NULL DEFAULT '0',
  `transfert_statut_origine` smallint(5) unsigned NOT NULL DEFAULT '0',
  `expl_comment` varchar(255) NOT NULL DEFAULT '',
  `expl_nbparts` int(8) unsigned NOT NULL DEFAULT '1',
  `expl_retloc` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`expl_id`),
  UNIQUE KEY `expl_cb` (`expl_cb`),
  KEY `expl_typdoc` (`expl_typdoc`),
  KEY `expl_cote` (`expl_cote`),
  KEY `expl_notice` (`expl_notice`),
  KEY `expl_codestat` (`expl_codestat`),
  KEY `expl_owner` (`expl_owner`),
  KEY `expl_bulletin` (`expl_bulletin`),
  KEY `i_expl_location` (`expl_location`),
  KEY `i_expl_section` (`expl_section`),
  KEY `i_expl_statut` (`expl_statut`),
  KEY `i_expl_lastempr` (`expl_lastempr`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `exemplaires`
--


-- --------------------------------------------------------

--
-- Table structure for table `exemplaires_temp`
--

CREATE TABLE IF NOT EXISTS `exemplaires_temp` (
  `cb` varchar(50) NOT NULL DEFAULT '',
  `sess` varchar(12) NOT NULL DEFAULT '',
  UNIQUE KEY `cb` (`cb`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exemplaires_temp`
--


-- --------------------------------------------------------

--
-- Table structure for table `exercices`
--

CREATE TABLE IF NOT EXISTS `exercices` (
  `id_exercice` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `num_entite` int(5) unsigned NOT NULL DEFAULT '0',
  `libelle` varchar(255) NOT NULL DEFAULT '',
  `date_debut` date NOT NULL DEFAULT '2006-01-01',
  `date_fin` date NOT NULL DEFAULT '2006-01-01',
  `statut` int(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_exercice`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exercices`
--


-- --------------------------------------------------------

--
-- Table structure for table `explnum`
--

CREATE TABLE IF NOT EXISTS `explnum` (
  `explnum_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `explnum_notice` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `explnum_bulletin` int(8) unsigned NOT NULL DEFAULT '0',
  `explnum_nom` varchar(255) NOT NULL DEFAULT '',
  `explnum_mimetype` varchar(255) NOT NULL DEFAULT '',
  `explnum_url` text NOT NULL,
  `explnum_data` mediumblob,
  `explnum_vignette` mediumblob,
  `explnum_extfichier` varchar(20) DEFAULT '',
  `explnum_nomfichier` text,
  `explnum_statut` int(5) unsigned NOT NULL DEFAULT '0',
  `explnum_index_sew` mediumtext NOT NULL,
  `explnum_index_wew` mediumtext NOT NULL,
  `explnum_repertoire` int(8) NOT NULL DEFAULT '0',
  `explnum_path` text NOT NULL,
  PRIMARY KEY (`explnum_id`),
  KEY `explnum_notice` (`explnum_notice`),
  KEY `explnum_bulletin` (`explnum_bulletin`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `explnum`
--


-- --------------------------------------------------------

--
-- Table structure for table `explnum_doc`
--

CREATE TABLE IF NOT EXISTS `explnum_doc` (
  `id_explnum_doc` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `explnum_doc_nomfichier` text NOT NULL,
  `explnum_doc_mimetype` varchar(255) NOT NULL DEFAULT '',
  `explnum_doc_data` mediumblob NOT NULL,
  `explnum_doc_extfichier` varchar(20) NOT NULL DEFAULT '',
  `explnum_doc_url` text NOT NULL,
  PRIMARY KEY (`id_explnum_doc`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `explnum_doc`
--


-- --------------------------------------------------------

--
-- Table structure for table `explnum_doc_actions`
--

CREATE TABLE IF NOT EXISTS `explnum_doc_actions` (
  `num_explnum_doc` int(10) NOT NULL DEFAULT '0',
  `num_action` int(10) NOT NULL DEFAULT '0',
  `prive` int(1) NOT NULL DEFAULT '0',
  `rapport` int(1) NOT NULL DEFAULT '0',
  `num_explnum` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`num_explnum_doc`,`num_action`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `explnum_doc_actions`
--


-- --------------------------------------------------------

--
-- Table structure for table `explnum_doc_sugg`
--

CREATE TABLE IF NOT EXISTS `explnum_doc_sugg` (
  `num_explnum_doc` int(10) NOT NULL DEFAULT '0',
  `num_suggestion` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`num_explnum_doc`,`num_suggestion`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `explnum_doc_sugg`
--


-- --------------------------------------------------------

--
-- Table structure for table `explnum_location`
--

CREATE TABLE IF NOT EXISTS `explnum_location` (
  `num_explnum` int(10) NOT NULL DEFAULT '0',
  `num_location` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`num_explnum`,`num_location`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `explnum_location`
--


-- --------------------------------------------------------

--
-- Table structure for table `expl_custom`
--

CREATE TABLE IF NOT EXISTS `expl_custom` (
  `idchamp` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `titre` varchar(255) DEFAULT NULL,
  `type` varchar(10) NOT NULL DEFAULT 'text',
  `datatype` varchar(10) NOT NULL DEFAULT '',
  `options` text,
  `multiple` int(11) NOT NULL DEFAULT '0',
  `obligatoire` int(11) NOT NULL DEFAULT '0',
  `ordre` int(11) DEFAULT NULL,
  `search` int(1) unsigned NOT NULL DEFAULT '0',
  `export` int(1) unsigned NOT NULL DEFAULT '0',
  `exclusion_obligatoire` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idchamp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `expl_custom`
--


-- --------------------------------------------------------

--
-- Table structure for table `expl_custom_lists`
--

CREATE TABLE IF NOT EXISTS `expl_custom_lists` (
  `expl_custom_champ` int(10) unsigned NOT NULL DEFAULT '0',
  `expl_custom_list_value` varchar(255) DEFAULT NULL,
  `expl_custom_list_lib` varchar(255) DEFAULT NULL,
  `ordre` int(11) DEFAULT NULL,
  KEY `expl_custom_champ` (`expl_custom_champ`),
  KEY `i_excl_lv` (`expl_custom_list_value`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expl_custom_lists`
--


-- --------------------------------------------------------

--
-- Table structure for table `expl_custom_values`
--

CREATE TABLE IF NOT EXISTS `expl_custom_values` (
  `expl_custom_champ` int(10) unsigned NOT NULL DEFAULT '0',
  `expl_custom_origine` int(10) unsigned NOT NULL DEFAULT '0',
  `expl_custom_small_text` varchar(255) DEFAULT NULL,
  `expl_custom_text` text,
  `expl_custom_integer` int(11) DEFAULT NULL,
  `expl_custom_date` date DEFAULT NULL,
  `expl_custom_float` float DEFAULT NULL,
  KEY `expl_custom_champ` (`expl_custom_champ`),
  KEY `expl_custom_origine` (`expl_custom_origine`),
  KEY `i_excv_st` (`expl_custom_small_text`),
  KEY `i_excv_t` (`expl_custom_text`(255)),
  KEY `i_excv_i` (`expl_custom_integer`),
  KEY `i_excv_d` (`expl_custom_date`),
  KEY `i_excv_f` (`expl_custom_float`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expl_custom_values`
--


-- --------------------------------------------------------

--
-- Table structure for table `external_count`
--

CREATE TABLE IF NOT EXISTS `external_count` (
  `rid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recid` varchar(255) NOT NULL DEFAULT '',
  `source_id` int(11) NOT NULL,
  PRIMARY KEY (`rid`),
  KEY `recid` (`recid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `external_count`
--


-- --------------------------------------------------------

--
-- Table structure for table `fiche`
--

CREATE TABLE IF NOT EXISTS `fiche` (
  `id_fiche` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `infos_global` text NOT NULL,
  `index_infos_global` text NOT NULL,
  PRIMARY KEY (`id_fiche`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `fiche`
--


-- --------------------------------------------------------

--
-- Table structure for table `frais`
--

CREATE TABLE IF NOT EXISTS `frais` (
  `id_frais` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL DEFAULT '',
  `condition_frais` text NOT NULL,
  `montant` float(8,2) unsigned NOT NULL DEFAULT '0.00',
  `num_cp_compta` varchar(255) NOT NULL,
  `num_tva_achat` varchar(25) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_frais`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `frais`
--


-- --------------------------------------------------------

--
-- Table structure for table `gestfic0_custom`
--

CREATE TABLE IF NOT EXISTS `gestfic0_custom` (
  `idchamp` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `titre` varchar(255) DEFAULT NULL,
  `type` varchar(10) NOT NULL DEFAULT 'text',
  `datatype` varchar(10) NOT NULL DEFAULT '',
  `options` text,
  `multiple` int(11) NOT NULL DEFAULT '0',
  `obligatoire` int(11) NOT NULL DEFAULT '0',
  `ordre` int(11) DEFAULT NULL,
  `search` int(1) unsigned NOT NULL DEFAULT '0',
  `export` int(1) unsigned NOT NULL DEFAULT '0',
  `exclusion_obligatoire` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idchamp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `gestfic0_custom`
--


-- --------------------------------------------------------

--
-- Table structure for table `gestfic0_custom_lists`
--

CREATE TABLE IF NOT EXISTS `gestfic0_custom_lists` (
  `gestfic0_custom_champ` int(10) unsigned NOT NULL DEFAULT '0',
  `gestfic0_custom_list_value` varchar(255) DEFAULT NULL,
  `gestfic0_custom_list_lib` varchar(255) DEFAULT NULL,
  `ordre` int(11) DEFAULT NULL,
  KEY `gestfic0_custom_champ` (`gestfic0_custom_champ`),
  KEY `gestfic0_champ_list_value` (`gestfic0_custom_champ`,`gestfic0_custom_list_value`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gestfic0_custom_lists`
--


-- --------------------------------------------------------

--
-- Table structure for table `gestfic0_custom_values`
--

CREATE TABLE IF NOT EXISTS `gestfic0_custom_values` (
  `gestfic0_custom_champ` int(10) unsigned NOT NULL DEFAULT '0',
  `gestfic0_custom_origine` int(10) unsigned NOT NULL DEFAULT '0',
  `gestfic0_custom_small_text` varchar(255) DEFAULT NULL,
  `gestfic0_custom_text` text,
  `gestfic0_custom_integer` int(11) DEFAULT NULL,
  `gestfic0_custom_date` date DEFAULT NULL,
  `gestfic0_custom_float` float DEFAULT NULL,
  KEY `gestfic0_custom_champ` (`gestfic0_custom_champ`),
  KEY `gestfic0_custom_origine` (`gestfic0_custom_origine`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gestfic0_custom_values`
--


-- --------------------------------------------------------

--
-- Table structure for table `grilles`
--

CREATE TABLE IF NOT EXISTS `grilles` (
  `grille_typdoc` char(2) NOT NULL DEFAULT 'a',
  `grille_niveau_biblio` char(1) NOT NULL DEFAULT 'm',
  `grille_localisation` mediumint(8) NOT NULL DEFAULT '0',
  `descr_format` longtext,
  PRIMARY KEY (`grille_typdoc`,`grille_niveau_biblio`,`grille_localisation`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grilles`
--


-- --------------------------------------------------------

--
-- Table structure for table `groupe`
--

CREATE TABLE IF NOT EXISTS `groupe` (
  `id_groupe` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `libelle_groupe` varchar(50) NOT NULL DEFAULT '',
  `resp_groupe` int(6) unsigned DEFAULT '0',
  `lettre_rappel` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_groupe`),
  UNIQUE KEY `libelle_groupe` (`libelle_groupe`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `groupe`
--


-- --------------------------------------------------------

--
-- Table structure for table `import_marc`
--

CREATE TABLE IF NOT EXISTS `import_marc` (
  `id_import` bigint(5) unsigned NOT NULL AUTO_INCREMENT,
  `notice` longblob NOT NULL,
  `origine` varchar(50) DEFAULT '',
  `no_notice` int(10) unsigned DEFAULT '0',
  `encoding` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_import`),
  KEY `i_nonot_orig` (`no_notice`,`origine`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33743 ;

--
-- Dumping data for table `import_marc`
--


-- --------------------------------------------------------

--
-- Table structure for table `indexint`
--

CREATE TABLE IF NOT EXISTS `indexint` (
  `indexint_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `indexint_name` varchar(255) NOT NULL DEFAULT '',
  `indexint_comment` text NOT NULL,
  `index_indexint` text,
  `num_pclass` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`indexint_id`),
  UNIQUE KEY `indexint_name` (`indexint_name`,`num_pclass`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=101 ;

--
-- Dumping data for table `indexint`
--

INSERT INTO `indexint` (`indexint_id`, `indexint_name`, `indexint_comment`, `index_indexint`, `num_pclass`) VALUES
(1, '000', 'Generalities', ' 000 generalities ', 1),
(2, '010', 'Bibliography ', ' 010 bibliography ', 1),
(3, '020', 'Library Science ', ' 020 library science ', 1),
(4, '030', 'Encyclopedias ', ' 030 encyclopedias ', 1),
(5, '040', 'Unassigned ', ' 040 unassigned ', 1),
(6, '050', 'Magazines ', ' 050 magazines ', 1),
(7, '060', 'Organizations, museums ', ' 060 organizations museums ', 1),
(8, '070', 'Journalism ', ' 070 journalism ', 1),
(9, '080', 'General collections ', ' 080 general collections ', 1),
(10, '090', 'Manuscripts, rare books ', ' 090 manuscripts rare books ', 1),
(11, '100', 'Philosophy ', ' 100 philosophy ', 1),
(12, '110', 'Metaphysics ', ' 110 metaphysics ', 1),
(13, '120', 'Epistemology ', ' 120 epistemology ', 1),
(14, '130', 'Paranormal Phenomena ', ' 130 paranormal phenomena ', 1),
(15, '140', 'Specific philosophies ', ' 140 specific philosophies ', 1),
(16, '150', 'Psychology ', ' 150 psychology ', 1),
(17, '160', 'Logic ', ' 160 logic ', 1),
(18, '170', 'Ethics ', ' 170 ethics ', 1),
(19, '180', 'Ancient philosophy ', ' 180 ancient philosophy ', 1),
(20, '190', 'Modern philosophy ', ' 190 modern philosophy ', 1),
(21, '200', 'Religion ', ' 200 religion ', 1),
(22, '210', 'Natural theology ', ' 210 natural theology ', 1),
(23, '220', 'Bible ', ' 220 bible ', 1),
(24, '230', 'Christian theology ', ' 230 christian theology ', 1),
(25, '240', 'Christian moral theology ', ' 240 christian moral theology ', 1),
(26, '250', 'Christian orders ', ' 250 christian orders ', 1),
(27, '260', 'Christian social theology ', ' 260 christian social theology ', 1),
(28, '270', 'Christian Church History ', ' 270 christian church history ', 1),
(29, '280', 'Christian denominations ', ' 280 christian denominations ', 1),
(30, '290', 'Other religions ', ' 290 other religions ', 1),
(31, '300', 'Social Science ', ' 300 social science ', 1),
(32, '310', 'General statistics ', ' 310 general statistics ', 1),
(33, '320', 'Political science ', ' 320 political science ', 1),
(34, '330', 'Economics ', ' 330 economics ', 1),
(35, '340', 'Law ', ' 340 law ', 1),
(36, '350', 'Public administration ', ' 350 public administration ', 1),
(37, '360', 'Social services ', ' 360 social services ', 1),
(38, '370', 'Education ', ' 370 education ', 1),
(39, '380', 'Commerce, transport ', ' 380 commerce transport ', 1),
(40, '390', 'Customs, folklore ', ' 390 customs folklore ', 1),
(41, '400', 'Language ', ' 400 language ', 1),
(42, '410', 'Linguistics ', ' 410 linguistics ', 1),
(43, '420', 'English ', ' 420 english ', 1),
(44, '430', 'German ', ' 430 german ', 1),
(45, '440', 'French ', ' 440 french ', 1),
(46, '450', 'Italian, Romanian ', ' 450 italian romanian ', 1),
(47, '460', 'Spanish, Portuguese ', ' 460 spanish portuguese ', 1),
(48, '470', 'Latin ', ' 470 latin ', 1),
(49, '480', 'Classical Greek ', ' 480 classical greek ', 1),
(50, '490', 'Other languages ', ' 490 other languages ', 1),
(51, '500', 'Science ', ' 500 science ', 1),
(52, '510', 'Mathematics ', ' 510 mathematics ', 1),
(53, '520', 'Astronomy ', ' 520 astronomy ', 1),
(54, '530', 'Physics ', ' 530 physics ', 1),
(55, '540', 'Chemistry ', ' 540 chemistry ', 1),
(56, '550', 'Earth sciences ', ' 550 earth sciences ', 1),
(57, '560', 'Paleontology ', ' 560 paleontology ', 1),
(58, '570', 'Life sciences ', ' 570 life sciences ', 1),
(59, '580', 'Botany ', ' 580 botany ', 1),
(60, '590', 'Zoology ', ' 590 zoology ', 1),
(61, '600', 'Technology ', ' 600 technology ', 1),
(62, '610', 'Medicine ', ' 610 medicine ', 1),
(63, '620', 'Engineering ', ' 620 engineering ', 1),
(64, '630', 'Agriculture ', ' 630 agriculture ', 1),
(65, '640', 'Home economics ', ' 640 home economics ', 1),
(66, '650', 'Management ', ' 650 management ', 1),
(67, '660', 'Chemical engineering ', ' 660 chemical engineering ', 1),
(68, '670', 'Manufacturing ', ' 670 manufacturing ', 1),
(69, '680', 'Specific industries ', ' 680 specific industries ', 1),
(70, '690', 'Buildings ', ' 690 buildings ', 1),
(71, '700', 'Arts, Entertainment ', ' 700 arts entertainment ', 1),
(72, '710', 'Civic & landscape art ', ' 710 civic landscape art ', 1),
(73, '720', 'Architecture ', ' 720 architecture ', 1),
(74, '730', 'Plastic arts, Sculpture ', ' 730 plastic arts sculpture ', 1),
(75, '740', 'Drawing, decorative arts ', ' 740 drawing decorative arts ', 1),
(76, '750', 'Painting ', ' 750 painting ', 1),
(77, '760', 'Graphic arts, Printmaking ', ' 760 graphic arts printmaking ', 1),
(78, '770', 'Photography ', ' 770 photography ', 1),
(79, '780', 'Music ', ' 780 music ', 1),
(80, '790', 'Recreation, performing arts ', ' 790 recreation performing arts ', 1),
(81, '800', 'Literature ', ' 800 literature ', 1),
(82, '810', 'American ', ' 810 american ', 1),
(83, '820', 'English ', ' 820 english ', 1),
(84, '830', 'German ', ' 830 german ', 1),
(85, '840', 'French ', ' 840 french ', 1),
(86, '850', 'Italian, Romanian ', ' 850 italian romanian ', 1),
(87, '860', 'Spanish, Portuguese ', ' 860 spanish portuguese ', 1),
(88, '870', 'Latin ', ' 870 latin ', 1),
(89, '880', 'Classical Greek ', ' 880 classical greek ', 1),
(90, '890', 'Other literatures ', ' 890 other literatures ', 1),
(91, '900', 'Geography & History ', ' 900 geography history ', 1),
(92, '910', 'Geography & travel ', ' 910 geography travel ', 1),
(93, '920', 'Biography, genealogy ', ' 920 biography genealogy ', 1),
(94, '930', 'History of ancient world ', ' 930 history of ancient world ', 1),
(95, '940', 'History of Europe ', ' 940 history of europe ', 1),
(96, '950', 'History of Asia ', ' 950 history of asia ', 1),
(97, '960', 'History of Africa ', ' 960 history of africa ', 1),
(98, '970', 'History of North America ', ' 970 history of north america ', 1),
(99, '980', 'History of South America ', ' 980 history of south america ', 1),
(100, '990', 'History of other areas ', ' 990 history of other areas ', 1);

-- --------------------------------------------------------

--
-- Table structure for table `infopages`
--

CREATE TABLE IF NOT EXISTS `infopages` (
  `id_infopage` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content_infopage` blob NOT NULL,
  `title_infopage` varchar(255) NOT NULL DEFAULT '',
  `valid_infopage` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_infopage`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `infopages`
--


-- --------------------------------------------------------

--
-- Table structure for table `lenders`
--

CREATE TABLE IF NOT EXISTS `lenders` (
  `idlender` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `lender_libelle` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`idlender`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `lenders`
--

INSERT INTO `lenders` (`idlender`, `lender_libelle`) VALUES
(1, 'Fond i brendshem');

-- --------------------------------------------------------

--
-- Table structure for table `liens_actes`
--

CREATE TABLE IF NOT EXISTS `liens_actes` (
  `num_acte` int(8) unsigned NOT NULL DEFAULT '0',
  `num_acte_lie` int(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`num_acte`,`num_acte_lie`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `liens_actes`
--


-- --------------------------------------------------------

--
-- Table structure for table `lignes_actes`
--

CREATE TABLE IF NOT EXISTS `lignes_actes` (
  `id_ligne` int(15) unsigned NOT NULL AUTO_INCREMENT,
  `type_ligne` int(3) unsigned NOT NULL DEFAULT '0',
  `num_acte` int(8) unsigned NOT NULL DEFAULT '0',
  `lig_ref` int(15) unsigned NOT NULL DEFAULT '0',
  `num_acquisition` int(12) unsigned NOT NULL DEFAULT '0',
  `num_rubrique` int(8) unsigned NOT NULL DEFAULT '0',
  `num_produit` int(8) unsigned NOT NULL DEFAULT '0',
  `num_type` int(8) unsigned NOT NULL DEFAULT '0',
  `libelle` text NOT NULL,
  `code` varchar(255) NOT NULL DEFAULT '',
  `prix` float(8,2) NOT NULL DEFAULT '0.00',
  `tva` float(8,2) unsigned NOT NULL DEFAULT '0.00',
  `nb` int(5) unsigned NOT NULL DEFAULT '1',
  `date_ech` date NOT NULL DEFAULT '0000-00-00',
  `date_cre` date NOT NULL DEFAULT '0000-00-00',
  `statut` int(3) unsigned NOT NULL DEFAULT '0',
  `remise` float(8,2) NOT NULL DEFAULT '0.00',
  `index_ligne` text NOT NULL,
  `ligne_ordre` smallint(2) unsigned NOT NULL DEFAULT '0',
  `debit_tva` smallint(2) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_ligne`),
  KEY `num_acte` (`num_acte`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `lignes_actes`
--


-- --------------------------------------------------------

--
-- Table structure for table `linked_mots`
--

CREATE TABLE IF NOT EXISTS `linked_mots` (
  `num_mot` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `num_linked_mot` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `type_lien` tinyint(1) NOT NULL DEFAULT '1',
  `ponderation` float NOT NULL DEFAULT '1',
  PRIMARY KEY (`num_mot`,`num_linked_mot`,`type_lien`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `linked_mots`
--


-- --------------------------------------------------------

--
-- Table structure for table `logopac`
--

CREATE TABLE IF NOT EXISTS `logopac` (
  `id_log` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `date_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `url_demandee` varchar(255) NOT NULL DEFAULT '',
  `url_referente` varchar(255) NOT NULL DEFAULT '',
  `get_log` blob NOT NULL,
  `post_log` blob NOT NULL,
  `num_session` varchar(255) NOT NULL DEFAULT '',
  `server_log` blob NOT NULL,
  `empr_carac` blob NOT NULL,
  `empr_doc` blob NOT NULL,
  `empr_expl` blob NOT NULL,
  `nb_result` blob NOT NULL,
  `gen_stat` blob NOT NULL,
  PRIMARY KEY (`id_log`),
  KEY `lopac_date_log` (`date_log`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `logopac`
--


-- --------------------------------------------------------

--
-- Table structure for table `log_expl_retard`
--

CREATE TABLE IF NOT EXISTS `log_expl_retard` (
  `id_log` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `date_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `titre` varchar(255) NOT NULL DEFAULT '',
  `expl_id` int(11) NOT NULL DEFAULT '0',
  `expl_cb` varchar(255) NOT NULL DEFAULT '',
  `date_pret` date NOT NULL DEFAULT '0000-00-00',
  `date_retour` date NOT NULL DEFAULT '0000-00-00',
  `amende` decimal(16,2) NOT NULL DEFAULT '0.00',
  `num_log_retard` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_log`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `log_expl_retard`
--


-- --------------------------------------------------------

--
-- Table structure for table `log_retard`
--

CREATE TABLE IF NOT EXISTS `log_retard` (
  `id_log` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `date_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `niveau_reel` int(1) NOT NULL DEFAULT '0',
  `niveau_suppose` int(1) NOT NULL DEFAULT '0',
  `amende_totale` decimal(16,2) NOT NULL DEFAULT '0.00',
  `frais` decimal(16,2) NOT NULL DEFAULT '0.00',
  `idempr` int(11) NOT NULL DEFAULT '0',
  `log_printed` int(1) unsigned NOT NULL DEFAULT '0',
  `log_mail` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_log`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `log_retard`
--


-- --------------------------------------------------------

--
-- Table structure for table `mots`
--

CREATE TABLE IF NOT EXISTS `mots` (
  `id_mot` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `mot` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_mot`),
  UNIQUE KEY `mot` (`mot`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mots`
--


-- --------------------------------------------------------

--
-- Table structure for table `noeuds`
--

CREATE TABLE IF NOT EXISTS `noeuds` (
  `id_noeud` int(9) unsigned NOT NULL AUTO_INCREMENT,
  `autorite` varchar(255) NOT NULL DEFAULT '',
  `num_parent` int(9) unsigned NOT NULL DEFAULT '0',
  `num_renvoi_voir` int(9) unsigned NOT NULL DEFAULT '0',
  `visible` char(1) NOT NULL DEFAULT '1',
  `num_thesaurus` int(3) unsigned NOT NULL DEFAULT '0',
  `path` text NOT NULL,
  PRIMARY KEY (`id_noeud`),
  KEY `num_parent` (`num_parent`),
  KEY `num_thesaurus` (`num_thesaurus`),
  KEY `autorite` (`autorite`),
  KEY `key_path` (`path`(1000))
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `noeuds`
--

INSERT INTO `noeuds` (`id_noeud`, `autorite`, `num_parent`, `num_renvoi_voir`, `visible`, `num_thesaurus`, `path`) VALUES
(1, 'TOP', 0, 0, '0', 1, ''),
(2, 'NONCLASSES', 1, 0, '0', 1, ''),
(3, 'ORPHELINS', 1, 0, '0', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `notices`
--

CREATE TABLE IF NOT EXISTS `notices` (
  `notice_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `typdoc` char(2) NOT NULL DEFAULT 'a',
  `tit1` text,
  `tit2` text,
  `tit3` text,
  `tit4` text,
  `tparent_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `tnvol` varchar(100) NOT NULL DEFAULT '',
  `ed1_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ed2_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `coll_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `subcoll_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `year` varchar(50) DEFAULT NULL,
  `nocoll` varchar(255) DEFAULT NULL,
  `mention_edition` varchar(255) NOT NULL DEFAULT '',
  `code` varchar(50) NOT NULL DEFAULT '',
  `npages` varchar(255) DEFAULT NULL,
  `ill` varchar(255) DEFAULT NULL,
  `size` varchar(255) DEFAULT NULL,
  `accomp` varchar(255) DEFAULT NULL,
  `n_gen` text NOT NULL,
  `n_contenu` text NOT NULL,
  `n_resume` text NOT NULL,
  `lien` text NOT NULL,
  `eformat` varchar(255) NOT NULL DEFAULT '',
  `index_l` text NOT NULL,
  `indexint` int(8) unsigned NOT NULL DEFAULT '0',
  `index_serie` tinytext,
  `index_matieres` text NOT NULL,
  `niveau_biblio` char(1) NOT NULL DEFAULT 'm',
  `niveau_hierar` char(1) NOT NULL DEFAULT '0',
  `origine_catalogage` int(8) unsigned NOT NULL DEFAULT '1',
  `prix` varchar(255) NOT NULL DEFAULT '',
  `index_n_gen` text,
  `index_n_contenu` text,
  `index_n_resume` text,
  `index_sew` text,
  `index_wew` text,
  `statut` int(5) NOT NULL DEFAULT '1',
  `commentaire_gestion` text NOT NULL,
  `create_date` datetime NOT NULL DEFAULT '2005-01-01 00:00:00',
  `update_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `signature` varchar(255) NOT NULL DEFAULT '',
  `thumbnail_url` mediumblob NOT NULL,
  `date_parution` date NOT NULL DEFAULT '0000-00-00',
  `opac_visible_bulletinage` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`notice_id`),
  KEY `typdoc` (`typdoc`),
  KEY `tparent_id` (`tparent_id`),
  KEY `ed1_id` (`ed1_id`),
  KEY `ed2_id` (`ed2_id`),
  KEY `coll_id` (`coll_id`),
  KEY `subcoll_id` (`subcoll_id`),
  KEY `cb` (`code`),
  KEY `indexint` (`indexint`),
  KEY `sig_index` (`signature`),
  KEY `i_notice_n_biblio` (`niveau_biblio`),
  KEY `i_notice_n_hierar` (`niveau_hierar`),
  KEY `notice_eformat` (`eformat`),
  KEY `i_date_parution` (`date_parution`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `notices`
--


-- --------------------------------------------------------

--
-- Table structure for table `notices_categories`
--

CREATE TABLE IF NOT EXISTS `notices_categories` (
  `notcateg_notice` int(9) unsigned NOT NULL DEFAULT '0',
  `num_noeud` int(9) unsigned NOT NULL DEFAULT '0',
  `num_vedette` int(3) unsigned NOT NULL DEFAULT '0',
  `ordre_vedette` int(3) unsigned NOT NULL DEFAULT '1',
  `ordre_categorie` smallint(2) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`notcateg_notice`,`num_noeud`,`num_vedette`),
  KEY `num_noeud` (`num_noeud`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notices_categories`
--


-- --------------------------------------------------------

--
-- Table structure for table `notices_custom`
--

CREATE TABLE IF NOT EXISTS `notices_custom` (
  `idchamp` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `titre` varchar(255) DEFAULT NULL,
  `type` varchar(10) NOT NULL DEFAULT 'text',
  `datatype` varchar(10) NOT NULL DEFAULT '',
  `options` text,
  `multiple` int(11) NOT NULL DEFAULT '0',
  `obligatoire` int(11) NOT NULL DEFAULT '0',
  `ordre` int(11) DEFAULT NULL,
  `search` int(1) unsigned NOT NULL DEFAULT '0',
  `export` int(1) unsigned NOT NULL DEFAULT '0',
  `exclusion_obligatoire` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idchamp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `notices_custom`
--


-- --------------------------------------------------------

--
-- Table structure for table `notices_custom_lists`
--

CREATE TABLE IF NOT EXISTS `notices_custom_lists` (
  `notices_custom_champ` int(10) unsigned NOT NULL DEFAULT '0',
  `notices_custom_list_value` varchar(255) DEFAULT NULL,
  `notices_custom_list_lib` varchar(255) DEFAULT NULL,
  `ordre` int(11) DEFAULT NULL,
  KEY `notices_custom_champ` (`notices_custom_champ`),
  KEY `i_ncl_lv` (`notices_custom_list_value`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notices_custom_lists`
--


-- --------------------------------------------------------

--
-- Table structure for table `notices_custom_values`
--

CREATE TABLE IF NOT EXISTS `notices_custom_values` (
  `notices_custom_champ` int(10) unsigned NOT NULL DEFAULT '0',
  `notices_custom_origine` int(10) unsigned NOT NULL DEFAULT '0',
  `notices_custom_small_text` varchar(255) DEFAULT NULL,
  `notices_custom_text` text,
  `notices_custom_integer` int(11) DEFAULT NULL,
  `notices_custom_date` date DEFAULT NULL,
  `notices_custom_float` float DEFAULT NULL,
  KEY `notices_custom_champ` (`notices_custom_champ`),
  KEY `notices_custom_origine` (`notices_custom_origine`),
  KEY `i_ncv_st` (`notices_custom_small_text`),
  KEY `i_ncv_t` (`notices_custom_text`(255)),
  KEY `i_ncv_i` (`notices_custom_integer`),
  KEY `i_ncv_d` (`notices_custom_date`),
  KEY `i_ncv_f` (`notices_custom_float`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notices_custom_values`
--


-- --------------------------------------------------------

--
-- Table structure for table `notices_global_index`
--

CREATE TABLE IF NOT EXISTS `notices_global_index` (
  `num_notice` mediumint(8) NOT NULL DEFAULT '0',
  `no_index` mediumint(8) NOT NULL DEFAULT '0',
  `infos_global` text NOT NULL,
  `index_infos_global` text NOT NULL,
  PRIMARY KEY (`num_notice`,`no_index`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notices_global_index`
--


-- --------------------------------------------------------

--
-- Table structure for table `notices_langues`
--

CREATE TABLE IF NOT EXISTS `notices_langues` (
  `num_notice` int(8) unsigned NOT NULL DEFAULT '0',
  `type_langue` int(1) unsigned NOT NULL DEFAULT '0',
  `code_langue` char(3) NOT NULL DEFAULT '',
  PRIMARY KEY (`num_notice`,`type_langue`,`code_langue`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notices_langues`
--


-- --------------------------------------------------------

--
-- Table structure for table `notices_mots_global_index`
--

CREATE TABLE IF NOT EXISTS `notices_mots_global_index` (
  `id_notice` mediumint(8) NOT NULL DEFAULT '0',
  `code_champ` int(2) NOT NULL DEFAULT '0',
  `mot` varchar(100) NOT NULL DEFAULT '',
  `nbr_mot` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_notice`,`code_champ`,`mot`),
  KEY `code_champ` (`code_champ`),
  KEY `mot` (`mot`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notices_mots_global_index`
--


-- --------------------------------------------------------

--
-- Table structure for table `notices_relations`
--

CREATE TABLE IF NOT EXISTS `notices_relations` (
  `num_notice` bigint(20) unsigned NOT NULL DEFAULT '0',
  `linked_notice` bigint(20) unsigned NOT NULL DEFAULT '0',
  `relation_type` char(1) NOT NULL DEFAULT '',
  `rank` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`num_notice`,`linked_notice`),
  KEY `linked_notice` (`linked_notice`),
  KEY `relation_type` (`relation_type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notices_relations`
--


-- --------------------------------------------------------

--
-- Table structure for table `notices_titres_uniformes`
--

CREATE TABLE IF NOT EXISTS `notices_titres_uniformes` (
  `ntu_num_notice` int(9) unsigned NOT NULL DEFAULT '0',
  `ntu_num_tu` int(9) unsigned NOT NULL DEFAULT '0',
  `ntu_titre` varchar(255) NOT NULL DEFAULT '',
  `ntu_date` varchar(255) NOT NULL DEFAULT '',
  `ntu_sous_vedette` varchar(255) NOT NULL DEFAULT '',
  `ntu_langue` varchar(255) NOT NULL DEFAULT '',
  `ntu_version` varchar(255) NOT NULL DEFAULT '',
  `ntu_mention` varchar(255) NOT NULL DEFAULT '',
  `ntu_ordre` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ntu_num_notice`,`ntu_num_tu`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notices_titres_uniformes`
--


-- --------------------------------------------------------

--
-- Table structure for table `notice_statut`
--

CREATE TABLE IF NOT EXISTS `notice_statut` (
  `id_notice_statut` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `gestion_libelle` varchar(255) DEFAULT NULL,
  `opac_libelle` varchar(255) DEFAULT NULL,
  `notice_visible_opac` tinyint(1) NOT NULL DEFAULT '1',
  `notice_visible_gestion` tinyint(1) NOT NULL DEFAULT '1',
  `expl_visible_opac` tinyint(1) NOT NULL DEFAULT '1',
  `class_html` varchar(255) NOT NULL DEFAULT '',
  `notice_visible_opac_abon` tinyint(1) NOT NULL DEFAULT '0',
  `expl_visible_opac_abon` int(10) unsigned NOT NULL DEFAULT '0',
  `explnum_visible_opac` int(1) unsigned NOT NULL DEFAULT '1',
  `explnum_visible_opac_abon` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_notice_statut`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `notice_statut`
--

INSERT INTO `notice_statut` (`id_notice_statut`, `gestion_libelle`, `opac_libelle`, `notice_visible_opac`, `notice_visible_gestion`, `expl_visible_opac`, `class_html`, `notice_visible_opac_abon`, `expl_visible_opac_abon`, `explnum_visible_opac`, `explnum_visible_opac_abon`) VALUES
(1, 'Pa gjendje te vecante', '', 1, 1, 1, 'statutnot1', 0, 0, 1, 0),
(2, 'I gatshem per huazim', '', 0, 1, 1, 'statutnot2', 1, 0, 1, 0),
(3, 'Ne huazim', 'huazim', 1, 1, 1, 'statutnot4', 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `notice_tpl`
--

CREATE TABLE IF NOT EXISTS `notice_tpl` (
  `notpl_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `notpl_name` varchar(256) NOT NULL DEFAULT '',
  `notpl_code` text NOT NULL,
  `notpl_comment` varchar(256) NOT NULL DEFAULT '',
  `notpl_id_test` int(10) unsigned NOT NULL DEFAULT '0',
  `notpl_show_opac` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`notpl_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `notice_tpl`
--


-- --------------------------------------------------------

--
-- Table structure for table `notice_tplcode`
--

CREATE TABLE IF NOT EXISTS `notice_tplcode` (
  `num_notpl` int(10) unsigned NOT NULL DEFAULT '0',
  `notplcode_localisation` mediumint(8) NOT NULL DEFAULT '0',
  `notplcode_typdoc` char(2) NOT NULL DEFAULT 'a',
  `notplcode_niveau_biblio` char(1) NOT NULL DEFAULT 'm',
  `notplcode_niveau_hierar` char(1) NOT NULL DEFAULT '0',
  `nottplcode_code` text NOT NULL,
  PRIMARY KEY (`num_notpl`,`notplcode_localisation`,`notplcode_typdoc`,`notplcode_niveau_biblio`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice_tplcode`
--


-- --------------------------------------------------------

--
-- Table structure for table `offres_remises`
--

CREATE TABLE IF NOT EXISTS `offres_remises` (
  `num_fournisseur` int(5) unsigned NOT NULL DEFAULT '0',
  `num_produit` int(8) unsigned NOT NULL DEFAULT '0',
  `remise` float(4,2) unsigned NOT NULL DEFAULT '0.00',
  `condition_remise` text,
  PRIMARY KEY (`num_fournisseur`,`num_produit`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `offres_remises`
--


-- --------------------------------------------------------

--
-- Table structure for table `opac_liste_lecture`
--

CREATE TABLE IF NOT EXISTS `opac_liste_lecture` (
  `id_liste` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `nom_liste` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `notices_associees` blob NOT NULL,
  `public` int(1) NOT NULL DEFAULT '0',
  `num_empr` int(8) unsigned NOT NULL DEFAULT '0',
  `read_only` int(1) NOT NULL DEFAULT '0',
  `confidential` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_liste`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `opac_liste_lecture`
--


-- --------------------------------------------------------

--
-- Table structure for table `opac_sessions`
--

CREATE TABLE IF NOT EXISTS `opac_sessions` (
  `empr_id` int(10) unsigned NOT NULL DEFAULT '0',
  `session` blob,
  `date_rec` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`empr_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `opac_sessions`
--


-- --------------------------------------------------------

--
-- Table structure for table `origine_notice`
--

CREATE TABLE IF NOT EXISTS `origine_notice` (
  `orinot_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `orinot_nom` varchar(255) NOT NULL DEFAULT '',
  `orinot_pays` varchar(255) NOT NULL DEFAULT 'FR',
  `orinot_diffusion` int(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`orinot_id`),
  KEY `orinot_nom` (`orinot_nom`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `origine_notice`
--

INSERT INTO `origine_notice` (`orinot_id`, `orinot_nom`, `orinot_pays`, `orinot_diffusion`) VALUES
(1, 'Katalog i brendshem', 'AL', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ouvertures`
--

CREATE TABLE IF NOT EXISTS `ouvertures` (
  `date_ouverture` date NOT NULL DEFAULT '0000-00-00',
  `ouvert` int(1) NOT NULL DEFAULT '1',
  `commentaire` varchar(255) NOT NULL DEFAULT '',
  `num_location` int(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`date_ouverture`,`num_location`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ouvertures`
--


-- --------------------------------------------------------

--
-- Table structure for table `paiements`
--

CREATE TABLE IF NOT EXISTS `paiements` (
  `id_paiement` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL DEFAULT '',
  `commentaire` text NOT NULL,
  PRIMARY KEY (`id_paiement`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `paiements`
--


-- --------------------------------------------------------

--
-- Table structure for table `parametres`
--

CREATE TABLE IF NOT EXISTS `parametres` (
  `id_param` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `type_param` varchar(20) DEFAULT NULL,
  `sstype_param` varchar(255) DEFAULT NULL,
  `valeur_param` text,
  `comment_param` longtext,
  `section_param` varchar(255) NOT NULL DEFAULT '',
  `gestion` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_param`),
  UNIQUE KEY `typ_sstyp` (`type_param`,`sstype_param`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=683 ;

--
-- Dumping data for table `parametres`
--

INSERT INTO `parametres` (`id_param`, `type_param`, `sstype_param`, `valeur_param`, `comment_param`, `section_param`, `gestion`) VALUES
(1, 'pmb', 'bdd_version', 'v4.92', 'Version de noyau de la base de données, à ne changer qu''en version inférieure si un paramètre était mal passé et relancer la mise à jour. En général, contactez plutôt la mailing liste pmb.user@sigb.net', '', 0),
(2, 'z3950', 'accessible', '1', 'Z3950 accessible ?\r\n 0 : non, menu inaccessible\r\n 1 : Oui, la librairie PHP_YAZ est activée, la recherche z3950 est possible', '', 0),
(3, 'pmb', 'nb_lastautorities', '10', 'Nombre de dernières autoritées affichées en gestion d''autorités', '', 0),
(4, 'pdflettreretard', '1before_list', 'Sipas sitemit tone Ju keni materialin/et e meposhtme ne huazim dhe data e dorezimit te tyre ka kaluar. :', 'Texte apparaissant avant la liste des ouvrages en retard dans le courrier de relance de retard', '', 0),
(5, 'pdflettreretard', '1after_list', 'Ju lutemi te na kontaktoni sa me shpejte tek numri $biblio_phone ose me mail tek $biblio_email per te zgjatur kete huazim ose per te kthyer materialin/et e huazuar.', 'Texte apparaissant après la liste des ouvrages en retard dans le courrier', '', 0),
(6, 'pdflettreretard', '1fdp', 'Pergjegjesi.', 'Signataire de la lettre.', '', 0),
(7, 'pdflettreretard', '1madame_monsieur', 'Znj/Z.,', 'Entête de la lettre', '', 0),
(8, 'pdflettreretard', '1nb_par_page', '7', 'Nombre d''ouvrages en retard imprimé sur les pages suivantes.', '', 0),
(9, 'pdflettreretard', '1nb_1ere_page', '4', 'Nombre d''ouvrages en retard imprimé sur la première page', '', 0),
(10, 'pdflettreretard', '1taille_bloc_expl', '16', 'Taille d''un bloc (2 lignes) d''ouvrage en retard. Le début de chaque ouvrage en retard sera espacé de cette valeur sur la page', '', 0),
(11, 'pdflettreretard', '1debut_expl_1er_page', '160', 'Début de la liste des exemplaires sur la première page, en mm depuis le bord supérieur de la page. Doit être règlé en fonction du texte qui précède la liste des ouvrages, lequel peut être plus ou moins long.', '', 0),
(12, 'pdflettreretard', '1debut_expl_page', '15', 'Début de la liste des exemplaires sur les pages suivantes, en mm depuis le bord supérieur de la page.', '', 0),
(13, 'pdflettreretard', '1limite_after_list', '270', 'Position limite en bas de page. Si un élément imprimé tente de dépasser cette limite, il sera imprimé sur la page suivante.', '', 0),
(14, 'pdflettreretard', '1marge_page_gauche', '10', 'Marge de gauche en mm', '', 0),
(15, 'pdflettreretard', '1marge_page_droite', '10', 'Marge de droite en mm', '', 0),
(16, 'pdflettreretard', '1largeur_page', '210', 'Largeur de la page en mm', '', 0),
(17, 'pdflettreretard', '1hauteur_page', '297', 'Hauteur de la page en mm', '', 0),
(18, 'pdflettreretard', '1format_page', 'P', 'Format de la page : \r\n P : Portrait\r\n L : Landscape = paysage', '', 0),
(19, 'pdfcartelecteur', 'pos_h', '20', 'Position horizontale en mm à partir du bord gauche de la page', '', 0),
(20, 'pdfcartelecteur', 'pos_v', '20', 'Position verticale en mm à partir du bord supérieur de la page', '', 0),
(21, 'pdfcartelecteur', 'biblio_name', '$biblio_name', 'Nom de la bibliothèque ou du centre de ressources imprimé sur la carte de lecteur. Mettre $biblio_name pour reprendre le nom spécifié en localisation d''exemplaire ou bien mettre autre chose.', '', 0),
(22, 'pdfcartelecteur', 'largeur_nom', '80', 'Largeur accordée à l''impression du nom du lecteur en mm', '', 0),
(23, 'pdfcartelecteur', 'valabledu', 'Vlefshem deri me', '''Valable du'' dans "VALABLE DU ##/##/#### au ##/##/####"', '', 0),
(24, 'pdfcartelecteur', 'valableau', 'au', '''au'' dans "valable du ##/##/#### AU ##/##/####"', '', 0),
(25, 'pdfcartelecteur', 'carteno', 'Nr Karte :', 'Mention précédant le numéro de la carte', '', 0),
(26, 'sauvegarde', 'cle_crypt1', '9b4a840d790eadc71b9064c9a843719b', '', '', 0),
(27, 'sauvegarde', 'cle_crypt2', '51580d4fd5f1ad2d981c91ddb04095ec', '', '', 0),
(28, 'pmb', 'resa_dispo', '1', 'Réservation de documents disponibles possible ?\r\n 0 : Non\r\n 1 : Oui', '', 0),
(29, 'mailretard', '1objet', '$biblio_name : materiali i vonuar', 'Objet du mail de relance de retard', '', 0),
(30, 'mailretard', '1before_list', 'Sauf erreur de notre part, vous avez toujours en votre possession le ou les ouvrage(s) suivant(s) dont la durée de prêt est aujourd''hui dépassée :', 'Texte apparaissant avant la liste des ouvrages en retard dans le mail de relance de retard', '', 0),
(31, 'mailretard', '1after_list', 'Nous vous remercions de prendre rapidement contact par téléphone au $biblio_phone ou par mail à $biblio_email pour étudier la possibilité de prolonger ces prêts ou de ramener les ouvrages concernés.', 'Texte apparaissant après la liste des ouvrages en retard dans le mail', '', 0),
(32, 'mailretard', '1madame_monsieur', 'Madame, Monsieur', 'Entête du mail', '', 0),
(33, 'mailretard', '1fdp', 'Le responsable.', 'Signataire du mail de relance de retard', '', 0),
(34, 'pmb', 'serial_link_article', '0', 'Préremplissage du lien des dépouillements avec le lien de la notice mère en catalogage des périodiques ?\r\n 0 : Non\r\n 1 : Oui', '', 0),
(35, 'pmb', 'num_carte_auto', '1', 'Numéro de carte de lecteur automatique ?\n 0: Non (si utilisation de cartes pré-imprimées)\n 1: Oui, entièrement numérique\n 2,a,b,c: Oui avec préfixe: a=longueur du préfixe, b=nombre de chiffres de la partie numérique, c=préfixe fixé (facultatif)', '', 0),
(36, 'opac', 'modules_search_title', '2', 'Recherche simple dans les titres :\n 0 : interdite\n 1 : autorisée\n 2 : autorisée et validée par défaut\n -1 : également interdite en recherche multi-critères', 'c_recherche', 0),
(37, 'opac', 'modules_search_author', '2', 'Recherche simple dans les auteurs :\n 0 : interdite\n 1 : autorisée\n 2 : autorisée et validée par défaut\n -1 : également interdite en recherche multi-critères', 'c_recherche', 0),
(38, 'opac', 'modules_search_publisher', '1', 'Recherche simple dans les éditeurs :\n 0 : interdite\n 1 : autorisée\n 2 : autorisée et validée par défaut\n -1 : également interdite en recherche multi-critères', 'c_recherche', 0),
(39, 'opac', 'modules_search_collection', '1', 'Recherche simple dans les collections :\n 0 : interdite\n 1 : autorisée\n 2 : autorisée et validée par défaut\n -1 : également interdite en recherche multi-critères', 'c_recherche', 0),
(40, 'opac', 'modules_search_subcollection', '1', 'Recherche simple dans les sous-collections :\n 0 : interdite\n 1 : autorisée\n 2 : autorisée et validée par défaut\n -1 : également interdite en recherche multi-critères', 'c_recherche', 0),
(41, 'opac', 'modules_search_category', '1', 'Recherche simple dans les catégories :\n 0 : interdite\n 1 : autorisée\n 2 : autorisée et validée par défaut\n -1 : également interdite en recherche multi-critères', 'c_recherche', 0),
(42, 'opac', 'modules_search_keywords', '1', 'Recherche simple dans les indexations libres (mots-clés) :\n 0 : interdite\n 1 : autorisée\n 2 : autorisée et validée par défaut\n -1 : également interdite en recherche multi-critères', 'c_recherche', 0),
(43, 'opac', 'modules_search_abstract', '1', 'Recherche simple dans le champ résumé :\n 0 : interdite\n 1 : autorisée\n 2 : autorisée et validée par défaut\n -1 : également interdite en recherche multi-critères', 'c_recherche', 0),
(44, 'opac', 'modules_search_content', '0', 'Recherche simple dans les notes de contenu:\r\n 0 : interdite\r\n 1 : autorisée\r\n 2 : autorisée et validée par défaut\r\nINUTILISE POUR L''INSTANT', 'c_recherche', 0),
(45, 'opac', 'categories_categ_path_sep', '>', 'Séparateur pour les catégories', 'i_categories', 0),
(46, 'opac', 'categories_columns', '3', 'Nombre de colonnes du sommaire général des catégories', 'i_categories', 0),
(47, 'opac', 'categories_categ_rec_per_page', '6', 'Nombre de notices à afficher par page dans l''exploration des catégories', 'i_categories', 0),
(48, 'opac', 'categories_categ_sort_records', 'index_serie, tnvol, index_sew', 'Explorateur de catégories : mode de tri des notices :\r\n index_serie, tnvol, index_sew > par titre de série, numéro dans la série et index des titres\r\n rand() : aléatoire', 'i_categories', 0),
(49, 'opac', 'search_results_first_level', '4', 'Nombre de résultats affichés sur la première page', 'z_unused', 0),
(50, 'opac', 'search_results_per_page', '10', 'Nombre de résultats affichés sur les pages suivantes', 'd_aff_recherche', 0),
(51, 'opac', 'authors_aut_rec_per_page', '1', 'Nombre d''auteurs affichés par page', 'd_aff_recherche', 0),
(52, 'opac', 'categories_sub_display', '3', 'Nombre de sous-categories sur la première page', 'i_categories', 0),
(53, 'opac', 'categories_sub_mode', 'libelle_categorie', 'Mode affichage des sous-categories : \r\n rand() > aléatoire\r\n libelle_categorie > ordre alpha', 'i_categories', 0),
(55, 'opac', 'default_lang', 'sq_AL', 'Langue de l''opac : fr_FR ou en_US ou es_ES ou ar', 'a_general', 0),
(56, 'opac', 'show_categ_browser', '1', 'Affichage des catégories en page d''accueil OPAC 1: oui  ou 0: non', 'f_modules', 0),
(57, 'opac', 'show_book_pics', '1', 'Afficher les vignettes de livres dans les fiches ouvrages :\r\n 0 : Non\r\n 1 : Oui', 'e_aff_notice', 0),
(58, 'opac', 'resa', '1', 'Réservations possibles par l''OPAC 1: oui  ou 0: non', 'a_general', 0),
(59, 'opac', 'resa_dispo', '1', 'Réservations possibles de documents disponibles par l''OPAC \r\n 1: oui \r\n 0: non', 'a_general', 0),
(60, 'opac', 'show_meteo', '0', 'Affichage de la météo dans l''OPAC 1: oui  ou 0: non', 'f_modules', 0),
(61, 'opac', 'duration_session_auth', '1200', 'Durée de la session lecteur dans l''OPAC en secondes', 'a_general', 0),
(62, 'pmb', 'relance_adhesion', '31', 'Nombre de jours avant expiration adhésion pour relance', '', 0),
(63, 'pmb', 'pret_adhesion_depassee', '1', 'Prêts si adhésion dépassée : 0 INTERDIT incontournable, 1 POSSIBLE', '', 0),
(64, 'pdflettreadhesion', 'fdp', 'Le responsable.', 'Formule de politesse en bas de page', '', 0),
(65, 'pdflettreadhesion', 'madame_monsieur', 'Madame, Monsieur,', 'Civilité du destinataire', '', 0),
(66, 'pdflettreadhesion', 'texte', 'Votre abonnement arrive à échéance le !!date_fin_adhesion!!. Nous vous remercions de penser à le renouveller lors de votre prochaine visite.\r\n\r\nNous vous prions de recevoir, Madame, Monsieur, l''expression de nos meilleures salutations.\r\n\r\n\r\n', 'Phrase d''introduction de l''échéance de l''abonnement', '', 0),
(67, 'pdflettreadhesion', 'marge_page_gauche', '10', 'Marge gauche de la page en mm', '', 0),
(68, 'pdflettreadhesion', 'marge_page_droite', '10', 'Marge droite de la page en mm', '', 0),
(69, 'pdflettreadhesion', 'largeur_page', '210', 'Largeur de la page en mm', '', 0),
(70, 'pdflettreadhesion', 'hauteur_page', '297', 'Hauteur de la page en mm', '', 0),
(71, 'pdflettreadhesion', 'format_page', 'P', 'P pour Portrait, L pour paysage (Landscape)', '', 0),
(72, 'mailrelanceadhesion', 'objet', '$biblio_name : votre abonnement', 'Objet du courrier de relance d''adhésion. Utilisez biblio_name pour reprendre le nom précisé dans la localisation des exemplaires.', '', 0),
(73, 'mailrelanceadhesion', 'texte', 'Votre abonnement arrive à échéance le !!date_fin_adhesion!!. Nous vous remercions de penser à le renouveller lors de votre prochaine visite.\r\n\r\nCordialement,\r\n\r\n', 'Texte de la relance, !!date_fin_adhesion!! sera remplacé à l''édition par la date de fin d''adhésion du lecteur', '', 0),
(74, 'mailrelanceadhesion', 'madame_monsieur', 'Madame, Monsieur,', 'Entête du courrier de relance d''adhésion', '', 0),
(75, 'mailrelanceadhesion', 'fdp', 'Le responsable.', 'Formule de politesse en bas de page', '', 0),
(76, 'opac', 'show_marguerite_browser', '0', '0 ou 1 : marguerite des catégories', 'f_modules', 0),
(77, 'opac', 'show_100cases_browser', '0', '0 ou 1 : affichage de 100 catégories', 'f_modules', 0),
(78, 'pmb', 'indexint_decimal', '1', '0 ou 1 : l''indexation interne est-elle une cotation décimale type Dewey', '', 0),
(79, 'opac', 'modules_search_indexint', '1', 'Recherche simple dans les indexations décimales :\n 0 : interdite\n 1 : autorisée\n 2 : autorisée et validée par défaut\n -1 : également interdite en recherche multi-critères', 'c_recherche', 0),
(80, 'empr', 'birthdate_optional', '1', 'Année de naissance facultative : \r\n 0 > non:elle est obligatoire \r\n 1 Oui', '', 0),
(81, 'thesaurus', 'categories_show_empty_categ', '1', 'Affichage des catégories ne contenant aucune notice :\r\n0=non, 1=oui', 'categories', 0),
(82, 'thesaurus', 'categories_term_search_n_per_page', '50', 'Nombre de termes affichés par page lors d''une recherche par terme dans les catégories', 'categories', 0),
(83, 'opac', 'show_loginform', '1', 'Affichage du login lecteur dans l''OPAC \r\n 0 > non\r\n 1 Oui', 'f_modules', 0),
(84, 'opac', 'default_style', 'bueil', 'Style graphique de l''OPAC, 1 style par défaut, nomargin : sans affichage du bandeau de gauche', 'a_general', 0),
(85, 'opac', 'show_exemplaires', '1', 'Afficher les exemplaires dans l''OPAC\n 1 Oui,\n 0 : Non', 'e_aff_notice', 0),
(86, 'pmb', 'import_modele', 'func_bdp.inc.php', 'Quel script de fonctions d''import utiliser pour personnaliser l''import ?', '', 0),
(87, 'pmb', 'quotas_avances', '0', 'Quotas de prêts avancés ?\n 0 : Non\n 1 : Oui', '', 0),
(88, 'opac', 'logo', 'logo_default.jpg', 'Nom du fichier de l''image logo', 'z_unused', 0),
(89, 'opac', 'logosmall', 'images/site/livre.png', 'Nom du fichier de l''image petit logo', 'b_aff_general', 0),
(90, 'opac', 'show_bandeaugauche', '1', 'Affichage du bandeau de gauche ? \n 0 : Non\n 1 : Oui', 'f_modules', 0),
(91, 'opac', 'show_liensbas', '1', 'Affichage des liens(pmb, google, bibli) en bas de page ? \n 0 : Non\n 1 : Oui', 'f_modules', 0),
(92, 'opac', 'show_homeontop', '0', 'Affichage du lien HOME (retour accueil) sous le nom de la bibliothèque ou du centre de ressources (nécessaire si masquage bandeau gauche) ? \r\n 0 : Non\r\n 1 : Oui', 'f_modules', 0),
(93, 'pmb', 'resa_quota_pret_depasse', '1', 'Réservation possible même si quota de prêt dépassé ? \n 0 : Non\n 1 : Oui', '', 0),
(94, 'pmb', 'import_limit_read_file', '100', 'Limite de taille de lecture du fichier en import, en général 100 ou 200 doit fonctionner, si problème de time out : fixer plus bas, 50 par exemple.', '', 0),
(95, 'pmb', 'import_limit_record_load', '100', 'Limite de taille de traitement de notices en import, en général 100 ou 200 doit fonctionner, si problème de time out : fixer plus bas, 50 par exemple.', '', 0),
(96, 'opac', 'biblio_preamble_p1', 'Mire se erdhet ne OPAC te BUSH', 'Paragrafi i pershkrimit, fondet, etj', 'b_aff_general', 0),
(97, 'opac', 'biblio_preamble_p2', 'OPAC eshte ne dispozicionin tuaj per te kerkuar ne fonder e BUSH', 'Paragraphe 2 d''informations : accueil du public.', 'b_aff_general', 0),
(98, 'opac', 'biblio_quicksummary_p1', '', 'Paragraphe 1 de résumé, est masqué par défaut dans la feuille de style, voir id quickSummary.p1', 'z_unused', 0),
(99, 'opac', 'biblio_quicksummary_p2', '', 'Paragraphe 2 de résumé, est masqué par défaut dans la feuille de style, voir id quickSummary.p2', 'z_unused', 0),
(100, 'opac', 'show_dernieresnotices', '0', 'Affichage des dernières notices créées en bas de page ? \n 0 : Non\n 1 : Oui', 'f_modules', 0),
(101, 'opac', 'show_etageresaccueil', '1', 'Affichage des étagères dans la page d''accueil en bas de page ? \n 0 : Non\n 1 : Oui', 'f_modules', 0),
(102, 'opac', 'biblio_important_p1', '', 'Infos importantes 1, est masqué par défaut dans la feuille de style, voir id important.p1', 'b_aff_general', 0),
(103, 'opac', 'biblio_important_p2', '', 'Infos importantes, est masqué par défaut dans la feuille de style, voir id important.p2', 'b_aff_general', 0),
(104, 'opac', 'biblio_name', 'Biblioteka Universitare Shkencore - Universiteti Shkoder', 'Emri i bibliotekes', 'b_aff_general', 0),
(105, 'opac', 'biblio_website', 'bush.unishk.edu.al', 'Biblioteka Universitare Shkencore', 'b_aff_general', 0),
(106, 'opac', 'biblio_adr1', 'Rruga "Jeronim De Rada"', 'Adresa e Bibliotekes', 'b_aff_general', 0),
(107, 'opac', 'biblio_town', 'Shkoder', 'Qyteti', 'b_aff_general', 0),
(108, 'opac', 'biblio_cp', '4001', 'Kodi postar', 'b_aff_general', 0),
(109, 'opac', 'biblio_country', 'Shqiperi', 'Shteti', 'b_aff_general', 0),
(110, 'opac', 'biblio_phone', '02 47 24 89 29', 'Telefoni', 'b_aff_general', 0),
(111, 'opac', 'biblio_dep', '', 'Departamenti per parashikimin e motit', 'b_aff_general', 0),
(112, 'opac', 'biblio_email', 'info@unishk.edu.al', 'Email de contact dans l''opac', 'b_aff_general', 0),
(113, 'opac', 'etagere_notices_order', 'index_serie, tnvol, index_sew', 'Ordre d''affichage des notices dans les étagères dans l''opac \n  index_serie, tit1 : tri par titre de série et titre \n rand()  : aléatoire', 'j_etagere', 0),
(114, 'opac', 'etagere_notices_format', '4', 'Format d''affichage des notices dans les étagères de l''écran d''accueil \r\n 1 : ISBD seul \r\n 2 : Public seul \r\n 4 : ISBD et Public \r\n 8 : Réduit (titre+auteurs) seul', 'j_etagere', 0),
(115, 'opac', 'etagere_notices_depliables', '1', 'Affichage dépliable des notices dans les étagères de l''écran d''accueil \r\n 0 : Non \r\n 1 : Oui', 'j_etagere', 0),
(116, 'opac', 'etagere_nbnotices_accueil', '5', 'Nombre de notices affichées dans les étagères de l''écran d''accueil \r\n 0 : Toutes \r\n -1 : Aucune \r\n x : x notices affichées au maximum', 'j_etagere', 0),
(117, 'opac', 'nb_aut_rec_per_page', '15', 'Nombre de notices affichées pour une autorité donnée', 'd_aff_recherche', 0),
(118, 'opac', 'notices_format', '4', 'Format d''affichage des notices dans les étagères de l''écran d''accueil \n 1 : ISBD seul \n 2 : Public seul \n 4 : ISBD et Public \n 5 : ISBD et Public avec ISBD en premier \n 8 : Réduit (titre+auteurs) seul', 'e_aff_notice', 0),
(119, 'opac', 'notices_depliable', '1', 'Affichage dépliable des notices en résultat de recherche  0 : Non  1 : Oui', 'e_aff_notice', 0),
(120, 'opac', 'term_search_n_per_page', '50', 'Nombre de termes affichés par page en recherche par terme', 'c_recherche', 0),
(121, 'opac', 'show_empty_categ', '1', 'En recherche par terme, affichage des catégories ne contenant aucun ouvrage :\r\n 0 : Non \r\n 1 : Oui', 'i_categories', 0),
(122, 'opac', 'allow_extended_search', '1', 'Autorisation ou non de la recherche avancée dans l''OPAC \n 0 : Non \n 1 : Oui', 'c_recherche', 0),
(123, 'opac', 'allow_term_search', '1', 'Autorisation ou non de la recherche par termes dans l''OPAC \n 0 : Non \n 1 : Oui', 'c_recherche', 0),
(124, 'opac', 'term_search_height', '350', 'Hauteur en pixels de la frame de recherche par termes (si pas précisé ou zéro : par défaut 200 pixels)', 'c_recherche', 0),
(125, 'opac', 'categories_nb_col_subcat', '3', 'Nombre de colonnes de sous-catégories en navigation dans les catégories \n 3 par défaut', 'i_categories', 0),
(126, 'opac', 'max_resa', '5', 'Nombre maximum de réservation sur un document \r\n 5 par défaut \r\n 0 pour illimité', 'a_general', 0),
(127, 'pmb', 'show_help', '1', 'Affichage de l''aide contextuelle dans PMB en partie gestion \r\n 1 Oui \r\n 0 Non', '', 0),
(128, 'opac', 'show_help', '1', 'Affichage de l''aide en ligne dans l''OPAC de PMB  \n 1 Oui \n 0 Non', 'f_modules', 0),
(129, 'opac', 'cart_allow', '1', 'Paniers possibles dans l''OPAC de PMB  \n 1 Oui \n 0 Non', 'f_modules', 0),
(130, 'opac', 'max_cart_items', '200', 'Nombre maximum de notices dans un panier utilisateur.', 'h_cart', 0),
(131, 'opac', 'show_section_browser', '1', 'Afficher le butineur de localisation et de sections ?\n 0 : Non\n 1 : Oui', 'f_modules', 0),
(132, 'opac', 'nb_localisations_per_line', '6', 'Nombre de localisations affichées par ligne en page d''accueil (si show_section_browser=1)', 'k_section', 0),
(133, 'opac', 'nb_sections_per_line', '6', 'Nombre de sections affichées par ligne en visualisation de localisation (si show_section_browser=1)', 'k_section', 0),
(134, 'opac', 'cart_only_for_subscriber', '1', 'Paniers de notices réservés aux adhérents de la bibliothèque ou du centre de ressources ?\r\n 1: Oui\r\n 0: Non, autorisé pour tout internaute', 'h_cart', 0),
(135, 'opac', 'notice_reduit_format', '0', 'Format d''affichage des réduits des notices :\r\n 0 normal = titre+auteurs principaux\r\n P 1,2,3: Perso. : tit+aut+champs persos id 1 2 3\r\n E 1,2,3: Perso. : tit+aut+édit+champs persos id 1 2 3 \r\n T : tit1+tit4', 'e_aff_notice', 0),
(136, 'pdflettreresa', 'before_list', 'Suite à votre demande de réservation, nous vous informons que le ou les ouvrages ci-dessous sont à votre disposition à la bibliothèque.', 'Texte apparaissant avant la liste des ouvrages en résa dans le courrier de confirmation de résa', '', 0),
(137, 'pdflettreresa', 'after_list', 'Passé le délai de réservation, ces ouvrages seront remis en circulation, vous priant de les retirer dans les meilleurs délais.', 'Texte apparaissant après la liste des ouvrages', '', 0),
(138, 'pdflettreresa', 'fdp', 'Le responsable.', 'Signataire de la lettre, utiliser $biblio_name pour reprendre le paramètre "biblio name" ou bien mettre autre chose.', '', 0),
(139, 'pdflettreresa', 'madame_monsieur', 'Madame, Monsieur,', 'Entête de la lettre', '', 0),
(140, 'pdflettreresa', 'nb_par_page', '7', 'Nombre d''ouvrages en retard imprimé sur les pages suivantes.', '', 0),
(141, 'pdflettreresa', 'nb_1ere_page', '4', 'Nombre d''ouvrages en retard imprimé sur la première page', '', 0),
(142, 'pdflettreresa', 'taille_bloc_expl', '20', 'Taille d''un bloc (2 lignes) d''ouvrage en réservation. Le début de chaque ouvrage en résa sera espacé de cette valeur sur la page', '', 0),
(143, 'pdflettreresa', 'debut_expl_1er_page', '160', 'Début de la liste des ouvrages sur la première page, en mm depuis le bord supérieur de la page. Doit être règlé en fonction du texte qui précède la liste des ouvrages, lequel peut être plus ou moins long.', '', 0),
(144, 'pdflettreresa', 'debut_expl_page', '15', 'Début de la liste des ouvrages sur les pages suivantes, en mm depuis le bord supérieur de la page.', '', 0),
(145, 'pdflettreresa', 'limite_after_list', '270', 'Position limite en bas de page. Si un élément imprimé tente de dépasser cette limite, il sera imprimé sur la page suivante.', '', 0),
(146, 'pdflettreresa', 'marge_page_gauche', '10', 'Marge de gauche en mm', '', 0),
(147, 'pdflettreresa', 'marge_page_droite', '10', 'Marge de droite en mm', '', 0),
(148, 'pdflettreresa', 'largeur_page', '210', 'Largeur de la page en mm', '', 0),
(149, 'pdflettreresa', 'hauteur_page', '297', 'Hauteur de la page en mm', '', 0),
(150, 'pdflettreresa', 'format_page', 'P', 'Format de la page : \r\n P : Portrait\r\n L : Landscape = paysage', '', 0),
(151, 'opac', 'categories_max_display', '200', 'Pour la page d''accueil, nombre maximum de catégories principales affichées', 'i_categories', 0),
(152, 'opac', 'search_other_function', '', 'Fonction complémentaire pour les recherches en page d''accueil', 'c_recherche', 0),
(153, 'opac', 'lien_bas_supplementaire', '<a href=''http://bush.unishk.edu.al'' target=_blank>BUSH</a>', 'Link per faqe te tjera: a href= link /a', 'b_aff_general', 0),
(154, 'z3950', 'import_modele', 'func_other.inc.php', 'Quel script de fonctions d''import utiliser pour personnaliser l''import en intégration z3950 ?', '', 0),
(155, 'ldap', 'server', 'chinon', 'Serveur LDAP, IP ou host', '', 0),
(156, 'ldap', 'basedn', '', 'Racine du nom de domaine LDAP', '', 0),
(157, 'ldap', 'port', '389', 'Port du serveur LDAP', '', 0),
(158, 'ldap', 'filter', '(&(objectclass=person)(gidnumber=GID))', 'Serveur LDAP, IP ou host', '', 0),
(159, 'ldap', 'fields', 'uid,gecos,departmentnumber', 'Champs du serveur LDAP', '', 0),
(160, 'ldap', 'lang', 'fr_FR', 'Langue du serveur LDAP', '', 0),
(161, 'ldap', 'groups', '', 'Groupes du serveur LDAP', '', 0),
(162, 'ldap', 'accessible', '0', 'LDAP accessible ?', '', 0),
(163, 'opac', 'categories_show_only_last', '0', 'Dans la fiche d''une notice : \n 0 tout afficher \n 1 : afficher uniquement la dernière feuille de l''arbre de la catégorie', 'i_categories', 0),
(164, 'thesaurus', 'categories_show_only_last', '0', 'Dans la fiche d''une notice : \n 0 tout afficher \n 1 : afficher uniquement la dernière feuille de l''arbre de la catégorie', 'categories', 0),
(165, 'pmb', 'prefill_cote', 'custom_cote_02.inc.php', 'Script personnalisé de construction de la cote de l''exemplaire', '', 0),
(166, 'ldap', 'proto', '3', 'Version du protocole LDAP : 3 ou 2', '', 0),
(167, 'ldap', 'binddn', 'uid=UID,ou=People', 'Description de la liaison : construction de la chaine binddn pour lier l''authentification au serveur LDAP dans l''OPAC', '', 0),
(168, 'empr', 'corresp_import', '', 'Table de correspondances colonnes/champs en import de lecteurs à partir d''un fichier ASCII', '', 1),
(169, 'pmb', 'type_audit', '0', 'Gestion/affichage des dates de création/modification \n 0: Rien\n 1: Création et dernière modification\n 2: Création et toutes les dates de modification', '', 0),
(170, 'pmb', 'gestion_abonnement', '0', 'Utiliser la gestion des abonnements des lecteurs ? \n 0 : Non\n 1 : Oui, gestion simple, \n 2 : Oui, gestion avancée', '', 0),
(171, 'pmb', 'utiliser_calendrier', '0', 'Utiliser le calendrier des jours d''ouverture ? \n 0 : Non\n 1 : Oui', '', 0),
(172, 'pmb', 'gestion_financiere', '0', 'Utiliser le module gestion financière ? \n 0 : Non\n 1 : Oui', '', 0),
(173, 'pmb', 'gestion_tarif_prets', '0', 'Utiliser la gestion des tarifs de prêts ? \n 0 : Non\n 1 : Oui, gestion simple, \n 2 : Oui, gestion avancée', '', 0),
(174, 'pmb', 'gestion_amende', '0', 'Utiliser la gestion des amendes:\n 0 = Non\n 1 = Gestion simple\n 2 = Gestion avancée', '', 0),
(175, 'finance', 'amende_jour', '0.15', 'Amende par jour de retard pour tout type de document. Attention, le séparateur décimal est le point, pas la virgule', '', 1),
(176, 'finance', 'delai_avant_amende', '15', 'Délai avant déclenchement de l''amende, en jour', '', 1),
(177, 'finance', 'delai_recouvrement', '7', 'Délai entre 3eme relance et mise en recouvrement officiel de l''amende, en jour', '', 1),
(178, 'finance', 'amende_maximum', '0', 'Amende maximum, quel que soit le retard l''amende est plafonnée à ce montant. 0 pour désactiver ce plafonnement.', '', 1),
(179, 'pdflettreresa', 'priorite_email', '1', 'Priorité des lettres de confirmation de réservation par mail lors de la validation d''une réservation:\n 0 : Lettre seule \n 1 : Mail, à défaut lettre\n 2 : Mail ET lettre\n 3 : Aucune alerte', '', 0),
(180, 'pdflettreresa', 'priorite_email_manuel', '1', 'Priorité des lettres de confirmation de réservation par mail lors de l''impression à partir du bouton :\n 0 : Lettre seule \n 1 : Mail, à défaut lettre\n 2 : Mail ET lettre\n 3 : Aucune alerte', '', 0),
(181, 'finance', 'blocage_abt', '1', 'Blocage du prêt si le compte abonnement est débiteur\n 0 : pas de blocage \n 1 : blocage avec forçage possible  : blocage incontournable.', '', 1),
(182, 'finance', 'blocage_pret', '1', 'Blocage du prêt si le compte prêt est débiteur\n 0 : pas de blocage \n 1 : blocage avec forçage possible  : blocage incontournable.', '', 1),
(183, 'finance', 'blocage_amende', '1', 'Blocage du prêt si le compte amende est débiteur\n 0 : pas de blocage \n 1 : blocage avec forçage possible  : blocage incontournable.', '', 1),
(184, 'pmb', 'gestion_devise', 'Lek', 'Devise de la gestion financière, ce qui va être affiché en code HTML', '', 0),
(185, 'opac', 'book_pics_url', '', 'URL des vignettes des notices, dans le chemin fourni, !!isbn!! sera remplacé par le code ISBN ou EAN de la notice purgé de tous les tirets ou points. \n exemple : http://www.monsite/opac/images/vignettes/!!isbn!!.jpg', 'e_aff_notice', 0),
(186, 'opac', 'lien_moteur_recherche', '<a href=http://www.google.com target=_blank>Kerkoni me Google</a>', 'Lien supplémentaire en bas de page d''accueil, à renseigner complètement : a href= lien /a', 'b_aff_general', 0),
(187, 'pmb', 'pret_express_statut', '2', 'Statut de notice à utiliser en création d''exemplaires en prêts express', '', 0),
(188, 'opac', 'notice_affichage_class', '', 'Nom de la classe d''affichage pour personnalisation de l''affichage des notices', 'e_aff_notice', 0),
(189, 'pmb', 'confirm_retour', '0', 'En retour de documents, le retour doit-il être confirmé ? \n 0 : Non, on peut passer les codes-barres les uns après les autres \n 1 : Oui, il faut valider le retour après chaque code-barre', '', 0),
(190, 'opac', 'show_meteo_url', '<img src="http://perso0.free.fr/cgi-bin/meteo.pl?dep=37" alt="" border="0" hspace=0>', 'URL de la météo affichée', 'f_modules', 0),
(191, 'pmb', 'limitation_dewey', '0', 'Nombre maximum de caractères dans la Dewey (676) en import : \n 0 aucune limitation \n 3 : limitation de 000 à 999 \n 5 (exemple) limitation 000.0 \n -1 : aucune importation', '', 0),
(192, 'finance', 'delai_1_2', '15', 'Délai entre 1ere et 2eme relance', '', 1),
(193, 'finance', 'delai_2_3', '15', 'Délai entre 2eme et 3eme relance', '', 1),
(194, 'pmb', 'lecteurs_localises', '0', 'Lecteurs localisés ? \n 0: Non \n 1: Oui', '', 0),
(195, 'dsi', 'active', '1', 'D.S.I activée ? \n 0: Non \n 1: Oui', '', 0),
(196, 'dsi', 'auto', '0', 'D.S.I automatique activée ? \n 0: Non \n 1: Oui', '', 0),
(197, 'dsi', 'insc_categ', '0', 'Inscription automatique dans les bannettes de la catégorie du lecteur en création ? \n 0: Non \n 1: Oui', '', 0),
(198, 'opac', 'allow_bannette_priv', '0', 'Possibilité pour les lecteurs de créer ou modifier leurs bannettes privées \n 0: Non \n 1: Oui', 'l_dsi', 0),
(199, 'opac', 'allow_resiliation', '0', 'Possibilité pour les lecteurs de résilier leur abonnement aux bannettes pro \n 0: Non \n 1: Oui', 'l_dsi', 0),
(200, 'opac', 'show_categ_bannette', '0', 'Affichage des bannettes de la catégorie du lecteur et possibilité de s''y abonner \n 0: Non \n 1: Oui', 'l_dsi', 0),
(201, 'opac', 'url_base', './opac_css/', 'URL de base de l''opac : typiquement mettre l''url publique web http://monsite/opac/ ne pas oublier le / final', 'a_general', 0),
(202, 'finance', 'relance_1', '0.53', 'Frais de la première lettre de relance', '', 1),
(203, 'finance', 'relance_2', '0.53', 'Frais de la deuxième lettre de relance', '', 1),
(204, 'finance', 'relance_3', '2.50', 'Frais de la troisième lettre de relance', '', 1),
(205, 'finance', 'statut_perdu', '', 'Statut (d''exemplaire) perdu pour des ouvrages non rendus', '', 1),
(206, 'pdflettreretard', '2after_list', 'Nous vous remercions de prendre rapidement contact par téléphone au $biblio_phone ou par mail à $biblio_email pour étudier la possibilité de prolonger ces prêts ou de ramener les ouvrages concernés.', 'Texte apparaissant après la liste des ouvrages en retard dans le courrier', '', 0),
(207, 'pdflettreretard', '2before_list', 'Sauf erreur de notre part, vous avez toujours en votre possession le ou les ouvrage(s) suivant(s) dont la durée de prêt est aujourd''hui dépassée :', 'Texte apparaissant avant la liste des ouvrages en retard dans le courrier de relance de retard', '', 0),
(208, 'pdflettreretard', '2debut_expl_1er_page', '160', 'Début de la liste des exemplaires sur la première page, en mm depuis le bord supérieur de la page. Doit être règlé en fonction du texte qui précède la liste des ouvrages, lequel peut être plus ou moins long.', '', 0),
(209, 'pdflettreretard', '2debut_expl_page', '15', 'Début de la liste des exemplaires sur les pages suivantes, en mm depuis le bord supérieur de la page.', '', 0),
(210, 'pdflettreretard', '2fdp', 'Le responsable.', 'Signataire de la lettre.', '', 0),
(211, 'pdflettreretard', '2format_page', 'P', 'Format de la page : \r\n P : Portrait\r\n L : Landscape = paysage', '', 0),
(212, 'pdflettreretard', '2hauteur_page', '297', 'Hauteur de la page en mm', '', 0),
(213, 'pdflettreretard', '2largeur_page', '210', 'Largeur de la page en mm', '', 0),
(214, 'pdflettreretard', '2limite_after_list', '270', 'Position limite en bas de page. Si un élément imprimé tente de dépasser cette limite, il sera imprimé sur la page suivante.', '', 0),
(215, 'pdflettreretard', '2madame_monsieur', 'Madame, Monsieur,', 'Entête de la lettre', '', 0),
(216, 'pdflettreretard', '2marge_page_droite', '10', 'Marge de droite en mm', '', 0),
(217, 'pdflettreretard', '2marge_page_gauche', '10', 'Marge de gauche en mm', '', 0),
(218, 'pdflettreretard', '2nb_1ere_page', '4', 'Nombre d''ouvrages en retard imprimé sur la première page', '', 0),
(219, 'pdflettreretard', '2nb_par_page', '7', 'Nombre d''ouvrages en retard imprimé sur les pages suivantes.', '', 0),
(220, 'pdflettreretard', '2taille_bloc_expl', '16', 'Taille d''un bloc (2 lignes) d''ouvrage en retard. Le début de chaque ouvrage en retard sera espacé de cette valeur sur la page', '', 0),
(221, 'pdflettreretard', '3after_list', 'Nous vous remercions de prendre rapidement contact par téléphone au $biblio_phone ou par mail à $biblio_email pour étudier la possibilité de prolonger ces prêts ou de ramener les ouvrages concernés.', 'Texte apparaissant après la liste des ouvrages en retard dans le courrier', '', 0),
(222, 'pdflettreretard', '3before_list', 'Sauf erreur de notre part, vous avez toujours en votre possession le ou les ouvrage(s) suivant(s) dont la durée de prêt est aujourd''hui dépassée :', 'Texte apparaissant avant la liste des ouvrages en retard dans le courrier de relance de retard', '', 0),
(223, 'pdflettreretard', '3debut_expl_1er_page', '160', 'Début de la liste des exemplaires sur la première page, en mm depuis le bord supérieur de la page. Doit être règlé en fonction du texte qui précède la liste des ouvrages, lequel peut être plus ou moins long.', '', 0),
(224, 'pdflettreretard', '3debut_expl_page', '15', 'Début de la liste des exemplaires sur les pages suivantes, en mm depuis le bord supérieur de la page.', '', 0),
(225, 'pdflettreretard', '3fdp', 'Le responsable.', 'Signataire de la lettre.', '', 0),
(226, 'pdflettreretard', '3format_page', 'P', 'Format de la page : \r\n P : Portrait\r\n L : Landscape = paysage', '', 0),
(227, 'pdflettreretard', '3hauteur_page', '297', 'Hauteur de la page en mm', '', 0),
(228, 'pdflettreretard', '3largeur_page', '210', 'Largeur de la page en mm', '', 0),
(229, 'pdflettreretard', '3limite_after_list', '270', 'Position limite en bas de page. Si un élément imprimé tente de dépasser cette limite, il sera imprimé sur la page suivante.', '', 0),
(230, 'pdflettreretard', '3madame_monsieur', 'Madame, Monsieur,', 'Entête de la lettre', '', 0),
(231, 'pdflettreretard', '3marge_page_droite', '10', 'Marge de droite en mm', '', 0),
(232, 'pdflettreretard', '3marge_page_gauche', '10', 'Marge de gauche en mm', '', 0),
(233, 'pdflettreretard', '3nb_1ere_page', '4', 'Nombre d''ouvrages en retard imprimé sur la première page', '', 0),
(234, 'pdflettreretard', '3nb_par_page', '7', 'Nombre d''ouvrages en retard imprimé sur les pages suivantes.', '', 0),
(235, 'pdflettreretard', '3taille_bloc_expl', '16', 'Taille d''un bloc (2 lignes) d''ouvrage en retard. Le début de chaque ouvrage en retard sera espacé de cette valeur sur la page', '', 0),
(236, 'pdflettreretard', '3before_recouvrement', 'Sans nouvelles de votre part dans les sept jours, nous nous verrons contraints de déléguer au trésor public le recouvrement des ouvrages suivants :', 'Texte avant la liste des ouvrages en recouvrement', '', 0),
(237, 'opac', 'bannette_notices_order', ' index_serie, tnvol, index_sew ', 'Ordre d''affichage des notices dans les bannettes dans l''opac \n  index_serie, tnvol, index_sew : tri par titre de série et titre \n rand()  : aléatoire', 'l_dsi', 0),
(238, 'opac', 'bannette_notices_format', '8', 'Format d''affichage des notices dans les bannettes \n 1 : ISBD seul \n 2 : Public seul \n 4 : ISBD et Public \n 8 : Réduit (titre+auteurs) seul', 'l_dsi', 0),
(239, 'opac', 'bannette_notices_depliables', '1', 'Affichage dépliable des notices dans les bannettes \n 0 : Non \n 1 : Oui', 'l_dsi', 0),
(240, 'opac', 'bannette_nb_liste', '0', 'Nbre de notices par bannettes en affichage de la liste des bannettes \n 0 Toutes \n N : maxi N\n -1 : aucune', 'l_dsi', 0),
(241, 'opac', 'dsi_active', '0', 'DSI, bannettes accessibles par l''OPAC ? \n 0 : Non \n 1 : Oui', 'l_dsi', 0),
(242, 'mailretard', '2after_list', 'Nous vous remercions de prendre rapidement contact par téléphone au $biblio_phone ou par mail à $biblio_email pour étudier la possibilité de prolonger ces prêts ou de ramener les ouvrages concernés.', 'Texte apparaissant après la liste des ouvrages en retard dans le mail', '', 0),
(243, 'mailretard', '2before_list', 'Sauf erreur de notre part, vous avez toujours en votre possession le ou les ouvrage(s) suivant(s) dont la durée de prêt est aujourd''hui dépassée :', 'Texte apparaissant avant la liste des ouvrages en retard dans le mail de relance de retard', '', 0),
(244, 'mailretard', '2fdp', 'Le responsable.', 'Signataire du mail de relance de retard', '', 0),
(245, 'mailretard', '2madame_monsieur', 'Madame, Monsieur', 'Entête du mail', '', 0),
(246, 'mailretard', '2objet', '$biblio_name : documents en retard', 'Objet du mail de relance de retard', '', 0),
(247, 'mailretard', '3after_list', 'Nous vous remercions de prendre rapidement contact par téléphone au $biblio_phone ou par mail à $biblio_email pour étudier la possibilité de prolonger ces prêts ou de ramener les ouvrages concernés.', 'Texte apparaissant après la liste des ouvrages en retard dans le mail', '', 0),
(248, 'mailretard', '3before_list', 'Sauf erreur de notre part, vous avez toujours en votre possession le ou les ouvrage(s) suivant(s) dont la durée de prêt est aujourd''hui dépassée :', 'Texte apparaissant avant la liste des ouvrages en retard dans le mail de relance de retard', '', 0),
(249, 'mailretard', '3fdp', 'Le responsable.', 'Signataire du mail de relance de retard', '', 0),
(250, 'mailretard', '3madame_monsieur', 'Madame, Monsieur', 'Entête du mail', '', 0),
(251, 'mailretard', '3objet', '$biblio_name : documents en retard', 'Objet du mail de relance de retard', '', 0),
(252, 'mailretard', '3before_recouvrement', 'Sans nouvelles de votre part dans les sept jours, nous nous verrons contraints de déléguer au trésor public le recouvrement des ouvrages suivants :', 'Texte avant la liste des ouvrages en recouvrement', '', 0),
(253, 'mailretard', 'priorite_email', '1', 'Priorité des lettres de retard lors des relances :\n 0 : Lettre seule \n 1 : Mail, à défaut lettre\n 2 : Mail ET lettre', '', 0),
(254, 'pmb', 'import_modele_lecteur', '', 'Modèle d''import des lecteurs', '', 0),
(255, 'pmb', 'blocage_retard', '0', 'Bloquer le prêt d''une durée équivalente au retard ? 0=non, 1=oui', '', 0),
(256, 'pmb', 'blocage_delai', '7', 'Délai à partir duquel le retard est pris en compte', '', 0),
(257, 'pmb', 'blocage_max', '60', 'Nombre maximum de jours bloqués (0 = pas de limite)', '', 0),
(258, 'pmb', 'blocage_coef', '1', 'Coefficient de proportionnalité des jours de retard pour le blocage', '', 0),
(259, 'pmb', 'blocage_retard_force', '1', '1 = Le prêt peut-être forcé lors d''un blocage du compte, 2 = Pas de forçage possible', '', 0),
(260, 'opac', 'etagere_order', ' name ', 'Tri des étagères dans l''écran d''accueil, \n name = par nom\n name DESC = par nom décroissant', 'j_etagere', 0),
(261, 'pmb', 'book_pics_show', '0', 'Affichage des couvertures de livres en gestion\n 1: oui  \n 0: non', '', 0),
(262, 'pmb', 'book_pics_url', '', 'URL des vignettes des notices, dans le chemin fourni, !!isbn!! sera remplacé par le code ISBN ou EAN de la notice purgé de tous les tirets ou points. \r\n exemple : http://www.monsite/opac/images/vignettes/!!isbn!!.jpg', '', 0),
(263, 'pmb', 'opac_url', './opac_css/', 'URL de l''OPAC vu depuis la partie gestion, par défaut ./opac_css/', '', 0),
(264, 'opac', 'resa_popup', '1', 'Demande de connexion sous forme de popup ? :\n 0 : Non\n 1 : Oui', 'a_general', 0),
(265, 'pmb', 'vignette_x', '100', 'Largeur de la vignette créée pour un exemplaire numérique image', '', 0),
(266, 'pmb', 'vignette_y', '100', 'Hauteur de la vignette créée pour un exemplaire numérique image', '', 0),
(267, 'pmb', 'vignette_imagemagick', '', 'Chemin de l''exécutable ImageMagick (/usr/bin/imagemagick par exemple)', '', 0),
(268, 'opac', 'show_rss_browser', '0', 'Affichage des flux RSS du catalogue en page d''accueil OPAC 1: oui  ou 0: non', 'f_modules', 0),
(269, 'pmb', 'mail_methode', 'php', 'Méthode d''envoi des mails : \n php : fonction mail() de php\n smtp,hote:port,auth,user,pass : en smtp, mettre O ou 1 pour l''authentification...', '', 0),
(270, 'opac', 'mail_methode', 'php', 'Méthode d''envoi des mails dans l''opac : \n php : fonction mail() de php\n smtp,hote:port,auth,user,pass : en smtp, mettre O ou 1 pour l''authentification...', 'a_general', 0),
(271, 'opac', 'search_show_typdoc', '1', 'Affichage de la restriction par type de document pour les recherches en page d''accueil', 'c_recherche', 0),
(272, 'pmb', 'verif_on_line', '0', 'Dans le menu Administration > Outils > Maj Base : vérification d''une version plus récente de PMB en ligne ? \r\n0 : non : si vous n''êtes pas connecté à internet \r\n 1 : Oui : si vous avez une connexion à internet', '', 0),
(273, 'opac', 'show_languages', '1 sq_AL,fr_FR,it_IT,en_UK,nl_NL,oc_FR', 'Afficher la liste déroulante de sélection de la langue ? \r\n 0 : Non \r\n 1 : Oui \r\nFaire suivre d''un espace et des codes des langues possibles séparées par des virgules : fr_FR,it_IT,en_UK,nl_NL,oc_FR', 'a_general', 0),
(274, 'pmb', 'pdf_font', 'Helvetica', 'Police de caractères à chasse variable pour les éditions en pdf - Police Arial', '', 0),
(275, 'pmb', 'pdf_fontfixed', 'Courier', 'Police de caractères à chasse fixe pour les éditions en pdf - Police Courier', '', 0),
(276, 'z3950', 'debug', '0', 'Debugage (export fichier) des notices lues en Z3950 \r\n 0: Non \r\n 1: 0ui', '', 0),
(277, 'pmb', 'nb_lastnotices', '10', 'Nombre de dernières notices affichées en Catalogue - Dernières notices', '', 0),
(278, 'opac', 'show_dernieresnotices_nb', '10', 'Nombre de dernières notices affichées en Catalogue - Dernières notices', 'f_modules', 0),
(279, 'pmb', 'recouvrement_auto', '0', 'Par défaut passage en recouvrement proposé en gestion des relances si niveau=3 et devrait être en 4: \r\n 1: Oui, recouvrement proposé par défaut \r\n 0: Ne rien faire par défaut', '', 0),
(280, 'pmb', 'keyword_sep', ' ', 'Séparateur des mots clés dans la partie indexation libre, espace ou ; ou , ou ...', '', 0),
(281, 'thesaurus', 'mode_pmb', '0', 'Niveau d''utilisation des thésaurus.\n 0 : Un seul thésaurus par défaut.\n 1 : Choix du thésaurus possible.', 'thesaurus', 0),
(282, 'thesaurus', 'defaut', '1', 'Identifiant du thésaurus par défaut.', 'thesaurus', 0),
(283, 'thesaurus', 'liste_trad', 'fr_FR', 'Liste des langues affichées dans les thésaurus.\n(ex : fr_FR,en_UK,...,ar)', 'thesaurus', 0),
(284, 'opac', 'thesaurus', '0', 'Niveau d''utilisation des thésaurus.\n 0 : Un seul thésaurus par défaut.\n 1 : Choix du thésaurus possible.', 'a_general', 0),
(285, 'acquisition', 'active', '1', 'Module acquisitions activé.\r\n 0 : Non.\r\n 1 : Oui.', '', 0),
(286, 'acquisition', 'gestion_tva', '0', 'Gestion de la TVA.\n 0 : Non.\n 1 : Oui, avec saisie des prix HT.\n 2 : Oui, avec saisie des prix TTC.', '', 0),
(287, 'acquisition', 'poids_sugg', 'U=1.00,E=0.70,V=0.00', 'Pondération des suggestions par défaut en pourcentage.\n U=Utilisateurs, E=Emprunteurs, V=Visiteurs.\n ex : U=1.00,E=0.70,V=0.00 \n', '', 0),
(288, 'acquisition', 'format', '8,CA,DD,BL,FA', 'Taille du Numéro et Préfixes des actes d''achats.\nex : 8,CA,DD,BL,FA \n8 = Préfixe + 8 Chiffres\nCA=Commande Achat, DD=Demande de Devis,BL=Bon de Livraison, FA=Facture Achat \n', '', 0),
(289, 'thesaurus', 'categories_categ_in_line', '0', 'Affichage des catégories en ligne.\n 0 : Non.\n 1 : Oui.', 'categories', 0),
(290, 'opac', 'categories_categ_in_line', '0', 'Affichage des catégories en ligne.\r\n 0 : Non.\r\n 1 : Oui.', 'i_categories', 0),
(291, 'acquisition', 'budget', '1', 'Utilisation d''un budget pour les commandes.\r\n 0:optionnel\r\n 1:obligatoire', '', 0),
(292, 'acquisition', 'pdfcde_format_page', '210x297', 'Largeur x Hauteur de la page en mm', 'pdfcde', 0),
(293, 'acquisition', 'pdfcde_orient_page', 'P', 'Orientation de la page: P=Portrait, L=Paysage', 'pdfcde', 0),
(294, 'acquisition', 'pdfcde_marges_page', '10,20,10,10', 'Marges de page en mm : Haut,Bas,Droite,Gauche', 'pdfcde', 0),
(295, 'acquisition', 'pdfcde_pos_logo', '10,10,20,20', 'Position du logo: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur', 'pdfcde', 0),
(296, 'acquisition', 'pdfcde_pos_raison', '35,10,100,10,16', 'Position Raison sociale: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfcde', 0),
(297, 'acquisition', 'pdfcde_pos_date', '150,10,0,6,8', 'Position Date: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfcde', 0),
(298, 'acquisition', 'pdfcde_pos_adr_fac', '10,35,60,5,10', 'Position Adresse de facturation: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfcde', 0),
(299, 'acquisition', 'pdfcde_pos_adr_liv', '10,75,60,5,10', 'Position Adresse de livraison: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfcde', 0),
(300, 'acquisition', 'pdfcde_pos_adr_fou', '100,55,100,6,14', 'Position Adresse fournisseur: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfcde', 0),
(301, 'acquisition', 'pdfcde_pos_num', '10,110,0,10,16', 'Position numéro de commande: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfcde', 0),
(302, 'acquisition', 'pdfcde_text_size', '10', 'Taille de la police texte', 'pdfcde', 0),
(303, 'acquisition', 'pdfcde_text_before', '', 'Texte avant le tableau de commande', 'pdfcde', 0),
(304, 'acquisition', 'pdfcde_text_after', '', 'Texte après le tableau de commande', 'pdfcde', 0),
(305, 'acquisition', 'pdfcde_tab_cde', '5,10', 'Table de commandes: Hauteur ligne,Taille police', 'pdfcde', 0),
(306, 'acquisition', 'pdfcde_pos_tot', '10,40,5,10', 'Position total de commande: Distance par rapport au bord gauche de la page, Largeur, Hauteur ligne,Taille police', 'pdfcde', 0),
(307, 'acquisition', 'pdfcde_pos_footer', '15,8', 'Position bas de page: Distance par rapport au bas de page, Taille police', 'pdfcde', 0),
(308, 'acquisition', 'pdfcde_pos_sign', '10,60,5,10', 'Position signature: Distance par rapport au bord gauche de la page, Largeur, Hauteur ligne,Taille police', 'pdfcde', 0),
(309, 'acquisition', 'pdfcde_text_sign', 'Le responsable de la bibliothèque.', 'Texte signature', 'pdfcde', 0),
(310, 'acquisition', 'pdfdev_format_page', '210x297', 'Largeur x Hauteur de la page en mm', 'pdfdev', 0),
(311, 'acquisition', 'pdfdev_orient_page', 'P', 'Orientation de la page: P=Portrait, L=Paysage', 'pdfdev', 0),
(312, 'acquisition', 'pdfdev_marges_page', '10,20,10,10', 'Marges de page en mm : Haut,Bas,Droite,Gauche', 'pdfdev', 0),
(313, 'acquisition', 'pdfdev_pos_logo', '10,10,20,20', 'Position du logo: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur', 'pdfdev', 0),
(314, 'acquisition', 'pdfdev_pos_raison', '35,10,100,10,16', 'Position Raison sociale: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfdev', 0),
(315, 'acquisition', 'pdfdev_pos_date', '150,10,0,6,8', 'Position Date: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfdev', 0),
(316, 'acquisition', 'pdfdev_pos_adr_fac', '10,35,60,5,10', 'Position Adresse de facturation: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfdev', 0),
(317, 'acquisition', 'pdfdev_pos_adr_liv', '10,75,60,5,10', 'Position Adresse de livraison: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfdev', 0),
(318, 'acquisition', 'pdfdev_pos_adr_fou', '100,55,100,6,14', 'Position Adresse fournisseur: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfdev', 0),
(319, 'acquisition', 'pdfdev_pos_num', '10,110,0,10,16', 'Position numéro de commande: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfdev', 0),
(320, 'acquisition', 'pdfdev_text_size', '10', 'Taille de la police texte', 'pdfdev', 0),
(321, 'acquisition', 'pdfdev_text_before', '', 'Texte avant le tableau de commande', 'pdfdev', 0),
(323, 'acquisition', 'pdfdev_text_after', '', 'Texte après le tableau de commande', 'pdfdev', 0),
(324, 'acquisition', 'pdfdev_tab_dev', '5,10', 'Table de commandes: Hauteur ligne,Taille police', 'pdfdev', 0),
(325, 'acquisition', 'pdfdev_pos_footer', '15,8', 'Position bas de page: Distance par rapport au bas de page, Taille police', 'pdfdev', 0),
(326, 'acquisition', 'pdfdev_pos_sign', '10,60,5,10', 'Position signature: Distance par rapport au bord gauche de la page, Largeur, Hauteur ligne,Taille police', 'pdfdev', 0),
(327, 'acquisition', 'pdfdev_text_sign', 'Le responsable de la bibliothèque.', 'Texte signature', 'pdfdev', 0),
(569, 'pmb', 'latest_order', 'notice_id desc', 'Tri des dernières notices ? \n notice_id desc : par id de notice décroissant: idéal mais peut être problématique après une migration ou un import \n create_date desc: par la colonne date de création.', '', 0),
(328, 'opac', 'export_allow', '1', 'Export de notices à partir de l''opac : \n 0 : interdit \n 1 : pour tous \n 2 : pour les abonnés uniquement', 'a_general', 0);
INSERT INTO `parametres` (`id_param`, `type_param`, `sstype_param`, `valeur_param`, `comment_param`, `section_param`, `gestion`) VALUES
(329, 'opac', 'resa_planning', '0', 'Utiliser un planning de réservation ? \n 0: Non \n 1: Oui', 'a_general', 0),
(330, 'opac', 'resa_contact', '<a href=''mailto:info@unishk.edu.al''>info@unishk.edu.al</a>', 'Code HTML d''information sur la personne à contacter par exemple en cas de problème de réservation.', 'a_general', 0),
(331, 'opac', 'default_operator', '0', 'Opérateur par défaut. 0 : OR, 1 : AND.', 'c_recherche', 0),
(332, 'opac', 'modules_search_all', '2', 'Recherche simple dans l''ensemble des champs :\n 0 : interdite\n 1 : autorisée\n 2 : autorisée et validée par défaut\n -1 : également interdite en recherche multi-critères', 'c_recherche', 0),
(333, 'acquisition', 'pdfliv_format_page', '210x297', 'Largeur x Hauteur de la page en mm', 'pdfliv', 0),
(334, 'acquisition', 'pdfliv_orient_page', 'P', 'Orientation de la page: P=Portrait, L=Paysage', 'pdfliv', 0),
(335, 'acquisition', 'pdfliv_marges_page', '10,20,10,10', 'Marges de page en mm : Haut,Bas,Droite,Gauche', 'pdfliv', 0),
(336, 'acquisition', 'pdfliv_pos_raison', '10,10,100,10,16', 'Position Raison sociale: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfliv', 0),
(337, 'acquisition', 'pdfliv_pos_adr_liv', '10,20,60,5,10', 'Position Adresse de livraison: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfliv', 0),
(338, 'acquisition', 'pdfliv_pos_adr_fou', '110,20,100,5,10', 'Position éléments fournisseur: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfliv', 0),
(339, 'acquisition', 'pdfliv_pos_num', '10,60,0,6,14', 'Position numéro Commande/Livraison: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfliv', 0),
(340, 'acquisition', 'pdfliv_tab_liv', '5,10', 'Table de livraisons: Hauteur ligne,Taille police', 'pdfliv', 0),
(341, 'acquisition', 'pdfliv_pos_footer', '15,8', 'Position bas de page: Distance par rapport au bas de page, Taille police', 'pdfliv', 0),
(342, 'pmb', 'default_operator', '0', 'Opérateur par défaut. \n 0 : OR, \n 1 : AND.', '', 0),
(343, 'mailretard', 'priorite_email_3', '0', 'Faire le troisième niveau de relance par mail :\n 0 : Non, lettre \n 1 : Oui, par mail', '', 0),
(344, 'opac', 'show_suggest', '0', 'Proposer de faire des suggestions dans l''OPAC.\n 0 : Non.\n 1 : Oui, avec authentification.\n 2 : Oui, sans authentification.', 'f_modules', 0),
(345, 'acquisition', 'email_sugg', '0', 'Information par email de l''évolution des suggestions.\n 0 : Non\n 1 : Oui', '', 0),
(346, 'acquisition', 'pdfliv_text_size', '10', 'Taille de la police texte', 'pdfliv', 0),
(347, 'acquisition', 'pdfliv_pos_date', '170,10,0,6,8', 'Position Date: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfliv', 0),
(348, 'acquisition', 'pdffac_text_size', '10', 'Taille de la police texte', 'pdffac', 0),
(349, 'acquisition', 'pdffac_format_page', '210x297', 'Largeur x Hauteur de la page en mm', 'pdffac', 0),
(350, 'acquisition', 'pdffac_orient_page', 'P', 'Orientation de la page: P=Portrait, L=Paysage', 'pdffac', 0),
(351, 'acquisition', 'pdffac_marges_page', '10,20,10,10', 'Marges de page en mm : Haut,Bas,Droite,Gauche', 'pdffac', 0),
(352, 'acquisition', 'pdffac_pos_raison', '10,10,100,10,16', 'Position Raison sociale: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdffac', 0),
(353, 'acquisition', 'pdffac_pos_date', '170,10,0,6,8', 'Position Date: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdffac', 0),
(354, 'acquisition', 'pdffac_pos_adr_fac', '10,20,60,5,10', 'Position Adresse de facturation: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdffac', 0),
(355, 'acquisition', 'pdffac_pos_adr_fou', '110,20,100,5,10', 'Position éléments fournisseur: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdffac', 0),
(356, 'acquisition', 'pdffac_pos_num', '10,60,0,6,14', 'Position numéro Commande/Facture: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdffac', 0),
(357, 'acquisition', 'pdffac_tab_fac', '5,10', 'Table de facturation: Hauteur ligne,Taille police', 'pdffac', 0),
(358, 'acquisition', 'pdffac_pos_tot', '10,40,5,10', 'Position total de commande: Distance par rapport au bord gauche de la page, Largeur, Hauteur ligne,Taille police', 'pdffac', 0),
(359, 'acquisition', 'pdffac_pos_footer', '15,8', 'Position bas de page: Distance par rapport au bas de page, Taille police', 'pdffac', 0),
(360, 'acquisition', 'pdfsug_text_size', '8', 'Taille de la police texte', 'pdfsug', 0),
(361, 'acquisition', 'pdfsug_format_page', '210x297', 'Largeur x Hauteur de la page en mm', 'pdfsug', 0),
(362, 'acquisition', 'pdfsug_orient_page', 'P', 'Orientation de la page: P=Portrait, L=Paysage', 'pdfsug', 0),
(363, 'acquisition', 'pdfsug_marges_page', '10,20,10,10', 'Marges de page en mm : Haut,Bas,Droite,Gauche', 'pdfsug', 0),
(364, 'acquisition', 'pdfsug_pos_titre', '10,10,100,10,16', 'Position titre: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfsug', 0),
(365, 'acquisition', 'pdfsug_pos_date', '170,10,0,6,8', 'Position Date: Distance par rapport au bord gauche de la page,Distance par rapport au haut de la page,Largeur,Hauteur,Taille police', 'pdfsug', 0),
(366, 'acquisition', 'pdfsug_tab_sug', '5,10', 'Table de suggestions: Hauteur ligne,Taille police', 'pdfsug', 0),
(367, 'acquisition', 'pdfsug_pos_footer', '15,8', 'Position bas de page: Distance par rapport au bas de page, Taille police', 'pdfsug', 0),
(368, 'acquisition', 'mel_rej_obj', 'Rejet suggestion', 'Objet du mail de rejet de suggestion', 'mel', 0),
(369, 'acquisition', 'mel_rej_cor', 'Votre suggestion du !!date!! est rejetée.\n\n', 'Corps du mail de rejet de suggestion', 'mel', 0),
(370, 'acquisition', 'mel_con_obj', 'Confirmation suggestion', 'Objet du mail de confirmation de suggestion', 'mel', 0),
(371, 'acquisition', 'mel_con_cor', 'Votre suggestion du !!date!! est retenue pour un prochain achat.\n\n', 'Corps du mail de confirmation de suggestion', 'mel', 0),
(372, 'acquisition', 'mel_aba_obj', 'Abandon suggestion', 'Objet du mail d''abandon de suggestion', 'mel', 0),
(373, 'acquisition', 'mel_aba_cor', 'Votre suggestion du !!date!! n''est pas retenue ou n''est pas disponible à la vente.\n\n', 'Corps du mail d''abandon de suggestion', 'mel', 0),
(374, 'acquisition', 'mel_cde_obj', 'Commande suggestion', 'Objet du mail de commande de suggestion', 'mel', 0),
(375, 'acquisition', 'mel_cde_cor', 'Votre suggestion du !!date!! est en commande.\n\n', 'Corps du mail de commande de suggestion', 'mel', 0),
(376, 'acquisition', 'mel_rec_obj', 'Réception suggestion', 'Objet du mail de réception de suggestion', 'mel', 0),
(377, 'acquisition', 'mel_rec_cor', 'Votre suggestion du !!date!! a été reçue et sera bientôt disponible en réservation.\n\n', 'Corps du mail de réception de suggestion', 'mel', 0),
(378, 'opac', 'allow_tags_search', '0', 'Recherche par tag (mots clés utilisateurs) \n 1 = oui \n 0 = non', 'c_recherche', 0),
(379, 'opac', 'allow_add_tag', '0', 'Permettre aux utilisateurs d''ajouter un tag à une notice.\n 0 : non\n 1 : oui\n 2 : identification obligatoire pour ajouter ', 'a_general', 0),
(380, 'opac', 'avis_allow', '0', 'Permet de consulter/ajouter un avis pour les notices \n 0 : non \n 1 : sans être identifié : consultation possible, ajout impossible \n 2 : identification obligatoire pour consulter et ajouter  \n 3 : consultation et ajout anonymes possibles', 'a_general', 0),
(381, 'opac', 'avis_nb_max', '30', 'Nombre maximal de commentaires conservés par notice. Les plus vieux sont effacés au profit des plus récents quand ce nombre est atteint.', 'a_general', 0),
(382, 'pmb', 'show_rtl', '0', 'Affichage possible de droite a gauche \n 0 non \n 1 oui', '', 0),
(383, 'opac', 'avis_show_writer', '0', 'Afficher le rédacteur de l''avis \n 0 : non \n 1 : Prénom NOM \n 2 : login OPAC uniquement ', 'a_general', 0),
(384, 'pmb', 'form_editables', '0', 'Grilles de notices éditables \n 0 non \n 1 oui', '', 0),
(385, 'acquisition', 'sugg_to_cde', '0', 'Transfert des suggestions en commande.\n 0 : Non.\n 1 : Oui.', '', 0),
(386, 'pmb', 'label_construct_script', '', 'Script de construction d''étiquette de cote', '', 0),
(387, 'dsi', 'func_after_diff', '', 'Script à exécuter après diffusion d''une bannette', '', 0),
(388, 'opac', 'notice_groupe_fonction', '', 'Quel fichier/fonction inclure pour la présentation des resultats si toutes les notices d''une recherche sont parmi les types mentionnés \n exemple : a,b text;c,d music;k photo fera include(text.inc.php) et appel à la fonction text()', 'd_aff_recherche', 0),
(389, 'opac', 'photo_mean_size_x', '', 'Taille X de la photo format ''moyen'', si vide, pas de redimensionnement ', 'm_photo', 0),
(390, 'opac', 'photo_mean_size_y', '', 'Taille Y de la photo format ''moyen'', si vide, pas de redimensionnement ', 'm_photo', 0),
(391, 'opac', 'photo_watermark', '', 'Watermark à ajouter sur les photos, si vide, pas de watermark', 'm_photo', 0),
(392, 'opac', 'photo_show_form', '', 'Afficher le formulaire de commande de photo ? \n 0: Non \n 1:Oui', 'm_photo', 0),
(393, 'opac', 'photo_email_form', '', 'Emails des destinataires des commandes de photo à séparer par des espaces si multiples.', 'm_photo', 0),
(394, 'opac', 'photo_watermark_transparency', '50', 'Transparence du watermark de 0 à 100 en % ', 'm_photo', 0),
(395, 'opac', 'show_onglet_empr', '0', 'Afficher l''onglet de compte emprunteur avec les onglets de recherche ? \n 0: Non \n 1: Oui  \n 2: n''afficher l''onglet empr que lorsque l''utilisateur est authentifié (et dans ce cas le clic sur l''onglet mène vers empr.php)', 'f_modules', 0),
(396, 'pmb', 'url_base', 'http://SERVER/DIRECTORY/', 'URL de base de la gestion : typiquement mettre l''url http://monserveur/pmb/ ne pas oublier le / final', '', 0),
(397, 'opac', 'show_empr', '0', 'Afficher l''emprunteur actuel dans la liste des exemplaires ?\n 0 : non\n 1 : pour les abonnés\n 2 : pour tout le monde ', 'a_general', 0),
(398, 'opac', 'show_login_form_next', '', 'Après connexion de l''emprunteur se diriger vers quel module ? \n Vide = Compte emprunteur \n index.php = Retour en accueil', 'f_modules', 0),
(399, 'opac', 'allow_term_troncat_search', '0', 'Troncature automatique à droite \n 1 = oui \n 0 = non', 'c_recherche', 0),
(400, 'opac', 'show_results_first_page', '0', 'Affichage de résultats sur la première page lors d''une recherche pour tous les champs \n 0=non \n 1=oui.', 'd_aff_recherche', 0),
(401, 'opac', 'nb_results_first_page', '10', 'Nombres de notices à afficher lors d''une recherche pour le critère Tous les champs.', 'd_aff_recherche', 0),
(402, 'opac', 'show_infobulles_categ', '0', 'Affichage des infobulles sur les libellés des catégories. \n 0=non \n 1=oui', 'i_categories', 0),
(403, 'acquisition', 'sugg_display', '', 'Nom de la fonction personnalisée d''affichage des suggestions', '', 0),
(404, 'acquisition', 'sugg_categ', '0', 'Affectation des suggestions à une catégorie de suggestions.\n 0 : Non\n 1 : Oui', '', 0),
(405, 'acquisition', 'sugg_categ_default', '1', 'Identifiant de la catégorie de suggestions par défaut.', '', 0),
(406, 'opac', 'sugg_categ', '0', 'Affectation des suggestions à une catégorie de suggestions.\n 0 : Non.\n 1 : Oui.', 'a_general', 0),
(407, 'opac', 'sugg_categ_default', '1', 'Identifiant de la catégorie de suggestions par défaut.', 'a_general', 0),
(408, 'acquisition', 'pdfsug_print', '', 'Quel script utiliser pour personnaliser l''impression des listes de suggestions ?', 'pdfsug', 0),
(409, 'acquisition', 'pdfdev_print', '', 'Quel script utiliser pour personnaliser l''impression des devis ?', 'pdfdev', 0),
(410, 'acquisition', 'pdfcde_print', '', 'Quel script utiliser pour personnaliser l''impression des commandes ?', 'pdfcde', 0),
(411, 'acquisition', 'pdfliv_print', '', 'Quel script utiliser pour personnaliser l''impression des bons de livraison ?', 'pdfliv', 0),
(412, 'acquisition', 'pdffac_print', '', 'Quel script utiliser pour personnaliser l''impression des factures ?', 'pdffac', 0),
(413, 'pmb', 'notice_reduit_format', '0', 'Format d''affichage des réduits des notices : \n 0 = titre+auteur principal\n 1 = titre+auteur principal+date édition\n', '', 0),
(414, 'pmb', 'resa_planning', '0', 'Utiliser un planning de réservation ? \n 0: Non \n 1: Oui', '', 0),
(415, 'pmb', 'antivol', '0', 'Système magnétique antivol à télécommander ? \n 1 Oui \n 0 Non', '', 0),
(416, 'acquisition', 'custom_calc_numero', '', 'Fonction personnalisée de numérotation des actes d''achats.', '', 0),
(417, 'pmb', 'numero_exemplaire_auto', '0', 'Autorise la numérotation automatique d''exemplaire ? \r\n1 Oui 0 Non', '', 0),
(418, 'pmb', 'numero_exemplaire_auto_script', 'gen_code/gen_code_exemplaire.php', 'Nom du fichier de Script php pour la génération des codes d''exemplaires en automatique', '', 0),
(419, 'empr', 'lecteur_controle_doublons', '0', 'Contrôle sur les doublons de lecteurs:\r\n0 : pas de controle sur les doublons, en saisie de fiche de lecteur. \r\n1,empr_nom,empr_prenom,... : recherche doublons sur les champs ''empr'', \r\n2,empr_nom,empr_prenom,... : recherche doublons sur les champs ''empr'', et champ personnalisables.\r\n3,empr_nom, empr_prenom ,... : idem, en rajoutant le test sur le groupe.', '', 0),
(420, 'pmb', 'pret_nombre_prolongation', '3', 'Nombre de prolongations autorisées', '', 0),
(421, 'pmb', 'pret_restriction_prolongation', '0', '0 : pas de restriction\r\n1 : prolongation limitée au paramètre pret_nombre_prolongation \r\n2 : prolongation gérée par les quotas ', '', 0),
(422, 'opac', 'pret_prolongation', '0', '0 : pas de prolongation\r\n1 : prolongation autorisée', 'a_general', 0),
(423, 'mailretard', '1after_list_group', 'Nous vous remercions de prendre rapidement contact par téléphone au $biblio_phone ou par mail à $biblio_email pour étudier la possibilité de prolonger les emprunts de votre groupe ou de rapporter les ouvrages concernés.', 'Texte apparaissant après la liste des ouvrages en retard dans le mail', '', 0),
(424, 'mailretard', '1before_list_group', 'Sauf erreur de notre part, les emprunteurs de votre groupe ont toujours en leur possession le ou les ouvrage(s) suivant(s) dont la durée de prêt est aujourd''hui dépassée :', 'Texte apparaissant avant la liste des ouvrages en retard dans le mail de relance de retard', '', 0),
(425, 'mailretard', '1fdp_group', 'Le responsable.', 'Signataire du mail de relance de retard', '', 0),
(426, 'mailretard', '1madame_monsieur_group', 'Madame, Monsieur', 'Entête du mail', '', 0),
(427, 'mailretard', '1objet_group', '$biblio_name : documents en retard', 'Objet du mail de relance de retard', '', 0),
(428, 'opac', 'pret_duree_prolongation', '15', 'Nombre de jours de prolongation autorisé', 'a_general', 0),
(429, 'opac', 'surlignage', '0', 'Surligner les mots recherchés :\n0 : pas de surlignage\n1 : surlignage obligatoire\n2 : surlignage activable\n3 : surlignage désactivable', 'd_aff_recherche', 0),
(430, 'pmb', 'first_week_day_format', '0', 'Format de la semaine: \n 0, la semaine commence le lundi \n 1 la semaine commence le dimanche', '', 0),
(431, 'opac', 'export_allow_expl', '0', 'Exporter les exemplaires avec les notices : \n 0 : Non \n 1 : Oui', 'a_general', 0),
(432, 'opac', 'nb_max_tri', '50', 'Nombre maximum de notices pour lesquelles le tri est autorisé.', 'c_recherche', 0),
(433, 'pmb', 'nb_max_tri', '50', 'Nombre maximum de notices pour lesquelles le tri est autorisé.', '', 0),
(434, 'opac', 'nb_max_criteres_tri', '3', 'Nombre maximum de critères de tri à afficher.', 'c_recherche', 0),
(435, 'empr', 'show_caddie', '0', 'Afficher le module de paniers de lecteurs: \n 0: Non \n 1: Oui', '', 0),
(436, 'empr', 'pics_url', '', 'URL des photos des emprunteurs, dans le chemin fourni, !!num_carte!! sera remplacé par le numéro de carte du lecteur. \n exemple : http://www.monsite/photos/lecteurs/!!num_carte!!.jpg', '', 0),
(437, 'empr', 'pics_max_size', '100', 'Taille maximale des photos des emprunteurs, en largeur ou en hauteur', '', 0),
(438, 'thesaurus', 'classement_mode_pmb', '0', 'Niveau d''utilisation des plans de classement des indexations. \n 0 : Un seul plan de classement. \n 1 : Choix du plan de classement possible.', 'classement', 0),
(439, 'thesaurus', 'classement_defaut', '1', 'Identifiant du plan de classement par défaut.', 'classement', 0),
(440, 'empr', 'electronic_loan_ticket', '0', 'Envoyer un ticket de prêt électronique ? \n 0: Non, \n 1: Oui', '', 0),
(441, 'empr', 'electronic_loan_ticket_obj', '!!biblio_name!! : emprunt(s) du !!date!!', 'Objet du mail de ticket électronique de prêt', '', 0),
(442, 'empr', 'electronic_loan_ticket_msg', 'Bonjour, <br />Voici la liste de vos emprunts et/ou réservations en date du !!date!! :<br /><br />!!all_loans!! !!all_reservations!!<br />Retrouvez toutes ces informations sur votre compte à l''adresse <a href=!!biblio_website!!>!!biblio_website!!</a>.', 'Corps du mail de ticket électronique de prêt', '', 0),
(443, 'pmb', 'droits_explr_localises', '0', 'Les droits de gestion des exemplaires sont-ils localisés ? \n 0: Non \n 1: Oui', '', 0),
(444, 'empr', 'fiche_depliee', '1', 'La fiche emprunteur sera automatiquement : \n 0 : pliée \n 1 : dépliée', '', 0),
(445, 'empr', 'statut_adhes_depassee', '2', 'id du statut pour lequel les emprunteurs dont la date d''adhesion est dépassée n''apparaissent pas en zone d''alerte', '', 0),
(446, 'opac', 'authorized_styles', 'bueil', 'Styles de l''OPAC autorisés, séparés par une virgule', 'a_general', 0),
(447, 'empr', 'relance_adhesion', '0', 'Les relances d''adhésion sont envoyées : \n 0 : exclusivement par lettre \n 1 : mail, à défaut par lettre', '', 0),
(448, 'empr', 'show_rows', 'b,n,a,v,y,s,1', 'Colonnes affichées en liste de lecteurs, saisir les colonnes séparées par des virgules. Les colonnes disponibles pour l''affichage de la liste des emprunteurs sont : \n n: nom+prénom \n a: adresse \n b: code-barre \n c: catégories \n g: groupes \n l: localisation \n s: statut \n cp: code postal \n v: ville \n y: année de naissance \n #n : id des champs personnalisés \n 1: icône panier', '', 0),
(449, 'empr', 'sort_rows', 'n,c,l,s', 'Colonnes qui seront disponibles pour le tri des emprunteurs. Les colonnes possibles sont : \n n: nom+prénom \n c: catégories \n g: groupes \n l: localisation \n s: statut \n cp: code postal \n v: ville \n y: année de naissance \n #n : id des champs personnalisés', '', 0),
(450, 'empr', 'filter_rows', 'cp,v,y,s', 'Colonnes qui seront disponibles en filtres de la liste des emprunteurs. Les colonnes possibles sont : \n cp: code postal \n c: catégories \n g: groupes \n l: localisation \n s: statut \n v: ville \n y: année de naissance \n #n : id des champs personnalisés', '', 0),
(451, 'empr', 'header_format', '', 'Champs personnalisés qui seront affichés dans l''entête de la fiche emprunteur. Saisir les ids séparés par des virgules', '', 0),
(452, 'empr', 'archivage_prets', '0', 'Archiver les prêts des emprunteurs ? \n 0: Non \n 1: Oui\nATTENTION pour la France: nous attirons votre attention sur l''obligation de déclarer votre traitement à la CNIL (www.cnil.fr) si vous activez cette fonctionnalité.', '', 0),
(453, 'empr', 'archivage_prets_purge', '0', 'Nombre de jours maximum pendant lesquels doivent être conservées les archives nominatives de prêts : \n0: illimité \nN: N jours', '', 0),
(454, 'opac', 'autres_lectures', '0', 'Afficher les emprunts des autres lecteurs du document courant ? \n 0: Non \n 1: Oui', 'f_modules', 0),
(455, 'opac', 'autres_lectures_tri', 'rand()', 'Tri des autres lectures proposées : \n rand(): aléatoire \n tit: par Titre', 'f_modules', 0),
(456, 'opac', 'autres_lectures_nb_mini_emprunts', '100', 'Nombre minimum d''emprunts pour être comptabilisés \n 1: un seul emprunt suffit pour proposer la notice comme lecture associée \n N: N emprunts minimum nécessaires ', 'f_modules', 0),
(457, 'opac', 'autres_lectures_nb_maxi', '0', 'Nombre maximum de lectures associées proposées', 'f_modules', 0),
(458, 'opac', 'autres_lectures_nb_jours_maxi', '1', 'Délai en jours au delà duquel les emprunts ne sont pas comptabilisés, 0 pour illimité', 'f_modules', 0),
(459, 'opac', 'empr_hist_nb_max', '0', 'Nombre maximum de prêts précédents à afficher, 0 pour illimité', 'a_general', 0),
(460, 'opac', 'empr_hist_nb_jour_max', '1', 'Délai en jours au delà duquel les prêts précédents ne sont pas affichés, 0 pour illimité', 'a_general', 0),
(461, 'opac', 'allow_tags_search_min_occ', '1', 'Nombre mini d''occurrences d''un tag pour être affiché, 1 pour tous', 'c_recherche', 0),
(462, 'pmb', 'etat_collections_localise', '0', 'L''état des collections est-il localisé ? \n 0 : non \n 1 : oui', '', 0),
(463, 'pmb', 'clean_nb_elements', '100', 'Nombre d''éléments traités par passe en nettoyage de base', '', 0),
(464, 'pmb', 'rfid_activate', '0', 'Enregistrements des prêts par platine RFID ? \n 0: Non \n 1: Oui', '', 0),
(465, 'opac', 'bull_results_per_page', '12', 'Nombre de bulletins affichés par page dans l''affichage d''un périodique', 'e_aff_notice', 0),
(466, 'pmb', 'rfid_serveur_url', '', 'URL du serveur de webservices RFID', '', 0),
(467, 'opac', 'authorized_information_pages', '1', 'Pages "includable" dans la page de l''opac ./index.php?lvl=information&askedpage= : \n Mettre les noms des fichiers séparés par une virgule', 'a_general', 0),
(468, 'pmb', 'notice_controle_doublons', '0', 'Contrôle sur les doublons en saisie de la notice \n 0: Pas de contrôle sur les doublons, \n 1,tit1,tit2, ... : Recherche par méthode _exacte_ de doublons sur des champs, défini dans le fichier notice.xml  \n 2,tit1,tit2, ... : Recherche par _similitude_ ', '', 0),
(469, 'opac', 'title_ponderation', '0.5', 'Majoration de la pondération des mots du titre \n   mettre 0 (zero) pour interdire la majoration \n ATTENTION utiliser le point décimal ', 'c_recherche', 0),
(470, 'pmb', 'title_ponderation', '0.5', 'Majoration de la pondération des mots du titre \n   mettre 0 (zero) pour interdire la majoration \n ATTENTION utiliser le point décimal ', '', 0),
(471, 'pmb', 'param_etiq_codes_barres', '', 'Paramètres de sauvegarde des paramètres d''édition d''étiquettes codes-barres', '', 1),
(472, 'pmb', 'javascript_office_editor', '', 'Code HTML à insérer pour remplacer les textarea par un éditeur Office javascript', '', 0),
(473, 'opac', 'biblio_post_adress', '', 'Bloc d''information après le bloc adresse, dans la feuille de style, voir id post_adress', 'b_aff_general', 0),
(474, 'opac', 'allow_external_search', '0', 'Autorisation ou non de la recherche par connecteurs externes dans l''OPAC \n 0 : Non \n 1 : Oui', 'c_recherche', 0),
(475, 'pmb', 'nb_noti_calc_empty_words', '50', 'Un mot sera considéré comme vide s''il apparaît dans un nombre de notices minimum. Saisir le pourcentage par rapport au nombre de notices total.', '', 1),
(476, 'opac', 'fonction_affichage_liste_bull', '', 'Fonction d''affichage des listes de bulletins', 'e_aff_notice', 0),
(477, 'pmb', 'allow_external_search', '0', 'Autorisation ou non de la recherche par connecteurs externes (masque également le menu Administration-Connecteurs) \n 0 : Non \n 1 : Oui', '', 0),
(517, 'transferts', 'statut_validation', '0', 'id du statut dans lequel seront placés les documents dont le transfert est validé', '', 1),
(516, 'pmb', 'transferts_actif', '0', 'Active le systeme de transferts d''exemplaires entre sites\n 0: Non \n 1: Oui', '', 0),
(480, 'dsi', 'bannette_notices_order', 'index_serie, tnvol, index_sew', 'Ordre des notices au sein de la bannette: \n index_serie, tnvol, index_sew : par titre \n create_date desc : par date de saisie décroissante \n rand() : aléatoire', '', 0),
(481, 'opac', 'websubscribe_show', '0', 'Afficher la possibilité de s''inscrire en ligne ? \n 0: Non \n 1: Oui', 'f_modules', 0),
(482, 'opac', 'websubscribe_empr_status', '2,1', 'Id des statuts des inscrits séparés par une virgule: en attente de validation, validés', 'f_modules', 0),
(483, 'opac', 'websubscribe_empr_categ', '0', 'Id de la catégorie des inscrits par le web non adhérents complets', 'f_modules', 0),
(484, 'opac', 'websubscribe_empr_stat', '0', 'Id du code statistique des inscrits par le web non adhérents complets', 'f_modules', 0),
(485, 'opac', 'websubscribe_valid_limit', '24', 'Durée maximum des inscriptions en attente de validation', 'f_modules', 0),
(486, 'pmb', 'mail_html_format', '1', 'Format d''envoi des mails : \n 0: Texte brut\n 1: HTML \nAttention, ne fonctionne qu''en mode d''envoi smtp !', '', 0),
(487, 'opac', 'mail_html_format', '1', 'Format d''envoi des mails à partir de l''opac: \n 0: Texte brut\n 1: HTML \nAttention, ne fonctionne qu''en mode d''envoi smtp !', 'a_general', 0),
(488, 'opac', 'websubscribe_empr_location', '0', 'Id de la localisation des inscrits par le web non adhérents complets', 'f_modules', 0),
(489, 'opac', 'allow_bannette_export', '0', 'Possibilité pour les lecteurs de recevoir les notices de leurs bannettes privées en pièce jointe au mail ?\n 0: Non \n 1: Oui', 'l_dsi', 0),
(490, 'opac', 'expl_data', 'expl_cb,expl_cote,tdoc_libelle,location_libelle,section_libelle', 'Colonne des exemplaires, dans l''ordre donné, séparé par des virgules : expl_cb,expl_cote,tdoc_libelle,location_libelle,section_libelle', 'e_aff_notice', 0),
(491, 'opac', 'expl_order', 'location_libelle,section_libelle,expl_cote,tdoc_libelle', 'Ordre d''affichage des exemplaires, dans l''ordre donné, séparé par des virgules : location_libelle,section_libelle,expl_cote,tdoc_libelle', 'e_aff_notice', 0),
(492, 'opac', 'curl_available', '1', 'La librairie cURL est-elle disponible pour les interrogations RSS notamment ? \n 0: Non \n 1: Oui', 'a_general', 0),
(493, 'pmb', 'curl_available', '1', 'La librairie cURL est-elle disponible pour les interrogations RSS notamment ? \n 0: Non \n 1: Oui', '', 0),
(494, 'opac', 'thesaurus_defaut', '1', 'Identifiant du thésaurus par défaut.', 'i_categories', 0),
(495, 'opac', 'recherches_pliables', '0', 'Les cases à cocher de la recherche simple sont-elles pliées ? \n 0: Non \n 1: Oui et pliée par défaut \n 2: Oui et dépliée par défaut \n 3: invisibles', 'c_recherche', 0),
(496, 'pmb', 'rfid_ip_port', '192.168.0.10,SerialPort=10;', 'Association ip du poste de prêt et Numéro du port utilisé par le serveur RFID. Ex: 192.168.0.10,SerialPort=10; IpPosteClient,SerialPort=NumPortPlatine; séparer par des points-virgules pour désigner tous les postes', '', 0),
(497, 'pmb', 'pret_timeout_temp', '15', 'Temps en minutes, après lequel un prêt temporaire est effacé', '', 0),
(498, 'opac', 'permalink', '0', 'Afficher l''Id de la notice avec un lien permanent ? \n 0: Non \n 1: Oui', 'e_aff_notice', 0),
(499, 'pdflettreretard', '3after_recouvrement', 'Sans nouvelles de votre part dans les sept jours, nous nous verrons contraints de déléguer au Trésor Public le recouvrement des ouvrages ci-dessus.', 'Texte apparaissant après la liste des ouvrages en recouvrement s''il n''y a pas d''autres ouvrages en niveau 1 et 2', '', 0),
(500, 'pdflettreretard', 'impression_tri', 'empr_cp,empr_ville,empr_nom,empr_prenom', 'Tri pour l''impression des lettres de relances ? Les champs sont ceux de la table empr séparés par des virgules. Exemple: empr_nom, empr_prenom', '', 0),
(501, 'pmb', 'pret_date_retour_adhesion_depassee', '0', 'La date de retour peut-elle dépasser la date de fin d''adhésion ? \n 0: Non: la date de retour sera calculée pour ne pas dépasser la date de fin d''adhésion. \n 1: Oui, la date de retour du prêt sera indépendante de la date de fin d''adhésion.', '', 0),
(502, 'opac', 'extended_search_auto', '1', 'En recherche multicritères, la sélection d''un champ ajoute celui-ci automatiquement sans avoir besoin de cliquer sur le bouton Ajouter ? \n 0: Non \n 1: Oui', 'c_recherche', 0),
(503, 'pmb', 'extended_search_auto', '1', 'En recherche multicritères, la sélection d''un champ ajoute celui-ci automatiquement sans avoir besoin de cliquer sur le bouton Ajouter ? \n 0: Non \n 1: Oui', '', 0),
(504, 'thesaurus', 'categories_affichage_ordre', '0', 'Paramétrage de l''ordre d''affichage des catégories d''une notice.\nPar ordre alphabétique: 0(par défaut)\nPar ordre de saisie: 1', 'categories', 0),
(505, 'opac', 'categories_affichage_ordre', '0', 'Paramétrage de l''ordre d''affichage des catégories d''une notice.\nPar ordre alphabétique: 0(par défaut)\nPar ordre de saisie: 1', 'i_categories', 0),
(506, 'pmb', 'rfid_driver', '', 'Driver du pilote RFID : le nom du répertoire contenant les javascripts propres au matériel en place.', '', 0),
(507, 'pmb', 'scan_pmbws_client_url', '', 'URL de l''interface de numérisation (client du webservice)', '', 0),
(508, 'pmb', 'scan_pmbws_url', '', 'URL du webservice de pilotage du scanner', '', 0),
(509, 'opac', 'biblio_main_header', '', 'Texte pouvant apparaitre dans le bloc principal, au dessus de tous les autres, nécessaire pour certaines mises en page particulières.', 'b_aff_general', 0),
(510, 'opac', 'sugg_localises', '0', 'Activer la localisation des suggestions des lecteurs ? \n 0: Pas de localisation possible.\n 1: Localisation au choix du lecteur.\n 2: Localisation restreinte à la localisation du lecteur.', 'a_general', 0),
(511, 'acquisition', 'sugg_localises', '0', 'Activer la localisation des suggestions ? \n 0: Pas de localisation possible. \n 1: Localisation activée.', '', 0),
(512, 'opac', 'categories_nav_max_display', '200', 'Limiter l''affichage des catégories en navigation dans les sous-catégories. 0: Pas de limitation. >0: Nombre max de catégories à afficher', 'i_categories', 0),
(513, 'pmb', 'pret_aff_limitation', '0', 'Activer la limitation de l''affichage de la liste des prêts dans la fiche lecteur ? \n 0: Inactif. \n 1: Limitation activée', '', 0),
(514, 'pmb', 'pret_aff_nombre', '10', 'Nombre de prêts à afficher si le paramètre pret_aff_limitation est actif. \n 0: tout voir, illimité. \n ## Nombre de prêts à afficher sur la première page', '', 0),
(515, 'pmb', 'printer_ticket_url', '', 'Permet d''utiliser une imprimante de ticket, connectée en local sur le poste de prêt client. Vide : pas d''imprimante. Url (http://localhost/printer/bixolon_srp350.php ) : imprimante active.', '', 0),
(518, 'transferts', 'statut_transferts', '0', 'id du statut dans lequel seront placés les documents en cours de transit', '', 1),
(519, 'transferts', 'validation_actif', '1', 'Active la validation des transferts\n 0: Non \n 1: Oui', '', 1),
(520, 'transferts', 'nb_jours_pret_defaut', '30', 'Nombre de jours de pret par defaut', '', 1),
(521, 'transferts', 'nb_jours_alerte', '7', 'Nombre de jours avant la fin du pret ou l''alerte s''affiche', '', 1),
(522, 'transferts', 'transfert_transfere_actif', '0', 'Autorise le transfert d''exemplaire deja transferer', '', 1),
(523, 'transferts', 'tableau_nb_lignes', '10', 'Nombre de transferts affichés dans les tableaux', '', 1),
(524, 'transferts', 'envoi_lot', '0', 'traitement par lot possible en envoi', '', 1),
(525, 'transferts', 'reception_lot', '0', 'traitement par lot possible en reception', '', 1),
(526, 'transferts', 'retour_lot', '0', 'traitement par lot possible en retour', '', 1),
(527, 'transferts', 'retour_origine', '0', 'Force le retour de l''exemplaire dans son lieu d''origine\n 0: Non \n 1: Oui', '', 1),
(528, 'transferts', 'retour_origine_force', '1', 'Permet de forcer le retour de l''exemplaire\n 0: Non \n 1: Oui', '', 1),
(529, 'transferts', 'retour_action_defaut', '1', 'Action par defaut lors du retour d''un emprunt\n 0: change localisation \n 1: genere transfert', '', 1),
(530, 'transferts', 'retour_action_autorise_autre', '1', 'Autorise une autre action lors du retour de l''exemplaire\n 0: Non\n 1: Oui', '', 1),
(531, 'transferts', 'retour_change_localisation', '1', 'Sauvegarde de la localisation lors du changement\n 0: Non \n 1: Oui', '', 1),
(532, 'transferts', 'retour_etat_transfert', '1', 'Etat du transfert lors de sa generation auto\n 0: creer \n 1: envoyer', '', 1),
(533, 'transferts', 'retour_motif_transfert', 'Transfert suite au retour de l''exemplaire sur notre site', 'Motif du transfert lors de sa generation auto', '', 1),
(534, 'transferts', 'choix_lieu_opac', '0', '0 pour pas de choix et obligatoirement dans la localisation ou est enregistré l''utilisateur, 1 pour n''importe quelle localisation au choix, 2 pour un lieu fixe précisé, 3 pour le lieu de l''exemplaire', '', 1),
(535, 'transferts', 'site_fixe', '1', 'id du site pour le retrait des livres si choix_lieu_opac=2', '', 1),
(536, 'transferts', 'resa_motif_transfert', 'Transfert suite à une réservation', 'Motif du transfert lors de sa generation auto pour une réservation', '', 1),
(537, 'transferts', 'resa_etat_transfert', '1', 'Etat du transfert lors de sa generation auto\n 0: creer \n 1: envoyer', '', 1),
(538, 'pmb', 'recherche_ajax_mode', '1', 'Affichage accéléré des résultats de recherche: "réduit" uniquement, la suite est chargée lors du click sur le "+". \n 0: Inactif \n 1: Actif', '', 0),
(539, 'pmb', 'expl_title_display_format', 'expl_location,expl_section,expl_cote,expl_cb', 'Format d''affichage du titre de l''exemplaire en recherche multi-critères d''exemplaires. Les libellés des champs correspondent aux champs de la table exemplaires, ou aux id de champs personnalisés. Séparés par une virgule. Les champs disposant d''un libellé seront remplacés par le libellé correspondant. Exemple: expl_location,expl_section,expl_cote,expl_cb', '', 0),
(540, 'opac', 'empr_code_info', '', 'Code HTML affiché au dessus des boutons dans la fiche emprunteur.', 'a_general', 0),
(541, 'opac', 'term_search_height_bottom', '120', 'Hauteur de la partie supérieure de la frame de recherche par termes (en px)', 'c_recherche', 0),
(542, 'pmb', 'rfid_library_code', '', 'Code numérique d''identification de la bibliothèque propriétaire des exemplaires (10 caractères)', '', 0),
(543, 'opac', 'show_infopages_id', '', 'Id des infopages à afficher sous la recherche simple, séparées par des virgules.', 'f_modules', 0),
(544, 'thesaurus', 'auto_postage_montant', '0', 'Activer la recherche des notices des catégories mères ? \n  0 non, \n 1 oui', 'i_categories', 0),
(545, 'thesaurus', 'auto_postage_descendant', '0', 'Activer la recherche des notices des catégories filles. \n 0 non, \n 1 oui', 'i_categories', 0),
(546, 'thesaurus', 'auto_postage_nb_descendant', '0', 'Nombre de niveaux de recherche de notices dans les catégories filles. \n *: illimité, \n n: nombre de niveaux', 'i_categories', 0),
(547, 'thesaurus', 'auto_postage_nb_montant', '0', 'Nombre de niveaux de recherche de notices dans les catégories mères. \n *: illimité, \n n: nombre de niveaux', 'i_categories', 0),
(548, 'thesaurus', 'auto_postage_etendre_recherche', '0', 'Proposer la possibilité d''étendre la recherche dans les catégories mères ou filles. \n 0: non, \n 1: Exclusivement dans les catégories filles, \n 2: Etendre dans les catégories mères et filles, \n 3: Exclusivement dans les catégories mères. ', 'i_categories', 0),
(549, 'opac', 'auto_postage_montant', '0', 'Activer la recherche des notices des catégories mères. \n 0 non, \n 1 oui', 'i_categories', 0),
(550, 'opac', 'auto_postage_descendant', '0', 'Activer la recherche des notices des catégories filles. \n 0 non, \n 1 oui', 'i_categories', 0),
(551, 'opac', 'auto_postage_nb_descendant', '0', 'Nombre de niveaux de recherche de notices dans les catégories filles. \n *: illimité, \n n: nombre de niveaux', 'i_categories', 0),
(552, 'opac', 'auto_postage_nb_montant', '0', 'Nombre de niveaux de recherche de notices dans les catégories mères. \n *: illimité, \n n: nombre de niveaux', 'i_categories', 0),
(553, 'opac', 'auto_postage_etendre_recherche', '0', 'Proposer la possibilité d''étendre la recherche dans les catégories mères ou filles. \n 0: non, \n 1: Exclusivement dans les catégories filles, \n 2: Etendre dans les catégories mères et filles, \n 3: Exclusivement dans les catégories mères. ', 'i_categories', 0),
(554, 'gestion_acces', 'active', '0', 'Module gestion des droits d''accès activé ?\n 0 : Non.\n 1 : Oui.', '', 0),
(555, 'gestion_acces', 'user_notice', '0', 'Gestion des droits d''accès des utilisateurs aux notices \n 0 : Non.\n 1 : Oui.', '', 0),
(556, 'pmb', 'abt_end_delay', '30', 'Délais d''alerte d''avertissement des abonnements arrivant à échéance (en jours)', '', 0),
(557, 'pmb', 'set_time_limit', '1200', 'max_execution_time de certaines opérations (export d''actions personnalisées, envoi DSI, export, etc.) \nAttention, peut être sans effet si l''hébergement ne l''autorise pas (free.fr par exemple)\n 0 : illimité (déconseillé) \n ###: ### secondes', '', 0),
(558, 'pmb', 'expl_list_display_comments', '0', 'Afficher les commentaires des exemplaires en liste d''exemplaires : \n 0 : non \n 1 : commentaire bloquant \n 2 : commentaire non bloquant \n 3 : les deux commentaires', '', 0),
(559, 'pmb', 'confirm_delete_from_caddie', '0', 'Action à réaliser lors de la suppression d''une notice située dans un panier. \r\n0 : Interdire \r\n1 : Supprimer sans confirmation \r\n2 : Demander une confirmation de suppression ', '', 0),
(560, 'opac', 'flux_rss_notices_order', ' index_serie, tnvol, index_sew ', 'Ordre d''affichage des notices dans les flux sortants dans l''opac \n  index_serie, tnvol, index_sew : tri par titre de série et titre \n rand()  : aléatoire \n notice_id desc par ordre décroissant de création de notice', 'l_dsi', 0),
(561, 'opac', 'modules_search_titre_uniforme', '1', 'Recherche simple dans les titres uniformes :\n 0 : interdite\n 1 : autorisée\n 2 : autorisée et validée par défaut\n -1 : également interdite en recherche multi-critères', 'c_recherche', 0),
(562, 'opac', 'congres_affichage_mode', '0', 'Mode d''affichage des congrès: \n 0 : Comme pour les auteurs, \n 1 : ajout d''un navigateur de congrès', 'd_aff_recherche', 0),
(563, 'opac', 'show_suggest_notice', '0', 'Afficher le lien de proposition de suggestion sur une notice existante.\n 0 : Non.\n 1 : Oui, avec authentification.\n 2 : Oui, sans authentification.', 'f_modules', 0),
(564, 'pmb', 'explnum_statut', '0', 'Utiliser un statut sur les documents numériques \n 0: non \n 1: oui', '', 0),
(565, 'opac', 'show_empty_items_block', '1', 'Afficher le bloc exemplaires même si aucun exemplaire sur la notice ? : \n 0 : Non, \n 1 : Oui', 'd_aff_recherche', 0),
(566, 'pmb', 'printer_ticket_script', '', 'Script permettant de personaliser l''impression du ticket de prêt. Le répertoire du script est à paramétrer à partir de la racine de PMB.\nSi vide PMB utilise ./circ/ticket-pret.inc.php', '', 0),
(567, 'opac', 'curl_proxy', '', 'Paramétrage de proxy de cURL, vide si aucun proxy, sinon\nhost,port,user,password;2nd_host et ainsi de suite', 'a_general', 0),
(568, 'pmb', 'curl_proxy', '', 'Paramétrage de proxy de cURL, vide si aucun proxy, sinon\nhost,port,user,password;2nd_host et ainsi de suite', '', 0),
(570, 'opac', 'password_forgotten_show', '1', 'Afficher le lien  "Mot de passe oublié ?" \n 0: Non \n 1: Oui', 'f_modules', 0),
(571, 'opac', 'aff_expl_localises', '0', 'Activer l''affichage des exemplaires localisés par onglet.\n 0 : désactivé \n 1: premier onglet affiche les exemplaires de la localisation du lecteur, le deuxieme affiche tous les exemplaires', 'e_aff_notice', 0),
(572, 'gestion_acces', 'empr_notice', '0', 'Gestion des droits d''accès des emprunteurs aux notices \n 0 : Non.\n 1 : Oui.', '', 0),
(573, 'opac', 'show_infopages_id_top', '', 'Id des infopages à afficher SUR la recherche simple, séparées par des virgules.', 'f_modules', 0),
(574, 'opac', 'show_search_title', '0', 'Afficher le titre du bloc de recherche : \n 0 : Non, \n 1 : Oui', 'f_modules', 0),
(575, 'opac', 'allow_personal_search', '0', 'Activer l''affichage de l''onglet des recherches personalisées \n 0 : Non.\n 1 : Oui.', 'c_recherche', 0),
(576, 'ldap', 'opac_only', '0', 'Ne pas utiliser l''authentification LDAP en gestion: \n 0: Non \n 1 : Oui, en OPAC uniquement', '', 0),
(577, 'pmb', 'multi_search_operator', 'or', 'Type d''opérateur de recherche pour les listes avec plusieurs valeurs: \n or : pour le OU \n and : pour le ET', '', 0),
(578, 'opac', 'multi_search_operator', 'or', 'Type d''opérateur de recherche pour les listes avec plusieurs valeurs: \n or : pour le OU \n and : pour le ET', 'c_recherche', 0),
(579, 'transferts', 'pret_statut_transfert', '0', 'Autoriser le prêt lorsque l''exemplaire est en transfert', '', 1),
(580, 'exportparam', 'generer_liens', '0', 'Générer les liens entre les notices pour l''export', '', 1),
(581, 'exportparam', 'export_mere', '0', 'Exporter les notices liées mères', '', 1),
(582, 'exportparam', 'export_fille', '0', 'Exporter les notices liées filles', '', 1),
(583, 'exportparam', 'export_bull_link', '1', 'Exporter les liens vers les bulletins pour les notices d''article', '', 1),
(584, 'exportparam', 'export_perio_link', '1', 'Exporter les liens vers les périodiques pour les notices d''article', '', 1),
(585, 'exportparam', 'export_art_link', '1', 'Exporter les liens vers les articles pour les notices de périodique', '', 1),
(586, 'exportparam', 'export_bulletinage', '0', 'Générer le bulletinage pour les notices de périodiques', '', 1),
(587, 'exportparam', 'export_notice_perio_link', '0', 'Exporter les notices liées de périodique', '', 1),
(588, 'exportparam', 'export_notice_art_link', '0', 'Exporter les notices liées d''article', '', 1),
(589, 'exportparam', 'export_notice_mere_link', '0', 'Exporter les notices mères liées', '', 1),
(590, 'exportparam', 'export_notice_fille_link', '0', 'Exporter les notices filles liées', '', 1),
(591, 'opac', 'exp_generer_liens', '0', 'Générer les liens entre les notices pour l''export', '', 1),
(592, 'opac', 'exp_export_mere', '0', 'Exporter les notices liées mères', '', 1),
(593, 'opac', 'exp_export_fille', '0', 'Exporter les notices liées filles', '', 1),
(594, 'opac', 'exp_export_bull_link', '1', 'Exporter les liens vers les bulletins pour les notices d''article', '', 1),
(595, 'opac', 'exp_export_perio_link', '1', 'Exporter les liens vers les périodiques pour les notices d''article', '', 1),
(596, 'opac', 'exp_export_art_link', '1', 'Exporter les liens vers les articles pour les notices de périodique', '', 1),
(597, 'opac', 'exp_export_bulletinage', '0', 'Générer le bulletinage pour les notices de périodiques', '', 1),
(598, 'opac', 'exp_export_notice_perio_link', '0', 'Exporter les notices liées de périodique', '', 1),
(599, 'opac', 'exp_export_notice_art_link', '0', 'Exporter les notices liées d''article', '', 1),
(600, 'opac', 'exp_export_notice_mere_link', '0', 'Exporter les notices mères liées', '', 1),
(601, 'opac', 'exp_export_notice_fille_link', '0', 'Exporter les notices filles liées', '', 1),
(602, 'pmb', 'perio_vidage_log', '1', 'Périodicité de vidage de la table de logs (en jours)', '', 0),
(603, 'pmb', 'perio_vidage_stat', '1,30', 'Périodicité de vidage de la table de logs (en jours) : mode,jours \n 1,x : vider tous les x jours \n 2,x : vider tout ce qui a plus de x jours \n 0 : ne rien faire', '', 0),
(604, 'pmb', 'logs_activate', '0', 'Activer les statistiques pour l''OPAC: \n 0 : non activé \n 1 : activé', '', 0),
(605, 'opac', 'shared_lists', '0', 'Activer les listes de lecture partagées \n 0 : non activées \n 1 : activées', 'a_general', 0),
(606, 'pmb', 'indexation_docnum', '0', 'Activer l''indexation des documents numériques \n 0 : non activée \n 1 : activée', '', 0),
(607, 'pmb', 'indexation_docnum_allfields', '0', 'Activer par défaut la recherche dans les documents numériques pour la recherche "Tous les champs" \n 0 : non activée \n 1 : activée', '', 0),
(608, 'opac', 'indexation_docnum_allfields', '0', 'Activer par défaut la recherche dans les documents numériques pour la recherche "Tous les champs" \n 0 : non activée \n 1 : activée', 'c_recherche', 0),
(609, 'opac', 'modules_search_docnum', '0', 'Recherche simple dans les documents numériques \n 0 : interdite \n 1 : autorisée \n 2 : autorisée et validée par défault', 'c_recherche', 0),
(610, 'pmb', 'location_reservation', '0', 'Utiliser la gestion de la réservation localisée?\n 0: Non\n 1: Oui', '', 0),
(611, 'pmb', 'extension_tab', '0', 'Afficher l''onglet Extension ? \n 0 : Non \n 1 : Oui', '', 0),
(612, 'pmb', 'indexation_docnum_default', '0', 'Indexer le document numérique par défaut ? \n 0 : Non \n 1 : Oui', '', 0),
(613, 'opac', 'shared_lists_readonly', '0', 'Listes de lecture partagées en lecture seule \n 0 : non activées \n 1 : activées', 'a_general', 0),
(614, 'opac', 'connexion_phrase', '', 'Phrase permettant l''encodage de la connexion automatique à partir d''un mail', 'a_general', 0),
(615, 'pmb', 'afficher_numero_lecteur_lettres', '1', 'Afficher le numéro du lecteur sous l''adresse dans les différentes lettres.\r\n0: non\r\n1: oui', '', 0),
(616, 'pmb', 'lettres_bloc_adresse_position_absolue', '0 100 40', 'Place le bloc d''adresse selon des coordonnées absolues.\nactivé x y\nactivé : activer cette fonction (valeurs: 0/1)\nx : Position horizontale\ny : Position verticale', '', 0),
(617, 'pmb', 'external_service_search_cache', '3600', 'Durée de vie des recherches dans le cache, pour les services externes, en secondes.', '', 0),
(618, 'pmb', 'external_service_session_duration', '600', 'Durée de vie des sessions pour les services externes, en secondes.', '', 0),
(619, 'opac', 'allow_multiple_sugg', '0', 'Autoriser les suggestions multiples.\r\n0: non\r\n1: oui', 'a_general', 0),
(620, 'opac', 'bannette_notices_template', '0', 'Id du template de notice utilisé par défaut en diffusion de bannettes. Si vide ou à 0, le template classique est utilisé.', 'l_dsi', 0),
(621, 'demandes', 'active', '0', 'Module demandes activé.\n 0 : Non.\n 1 : Oui.', '', 0),
(622, 'demandes', 'statut_notice', '0', 'Id du statut de notice pour la notice de demandes.', '', 0),
(623, 'opac', 'demandes_active', '0', 'Activer les demandes pour l''OPAC.\n 0 : Non.\n 1 : Oui.', 'a_general', 0),
(624, 'pmb', 'use_uniform_title', '0', 'Utiliser les titres uniformes ? \n 0 : Non.\n 1 : Oui.', '', 0),
(625, 'opac', 'print_expl_default', '0', 'En impression de panier, imprimer les exemplaires est coché par défaut \n 0 : Non \n 1 : Oui', 'a_general', 0),
(626, 'demandes', 'include_note', '0', 'Inclure automatiquement les notes dans le rapport documentaire.', '', 0),
(627, 'opac', 'ie_reload_on_resize', '0', 'Recharger la page si l''utilisateur redimensionne son navigateur (pb de CSS avec IE) ? \n 0: Non \n 1: Oui', 'a_general', 0),
(628, 'pmb', 'expl_show_dates', '0', 'Afficher les dates de création et de modification des exemplaires ? \n 0 : Non.\n 1 : Oui.', '', 0),
(629, 'gestion_acces', 'user_notice_def', '0', 'Valeur par défaut en modification de notice pour les droits d''accès utilisateurs - notices \n 0 : Recalculer.\n 1 : Choisir.', '', 0),
(630, 'gestion_acces', 'empr_notice_def', '0', 'Valeur par défaut en modification de notice pour les droits d''accès emprunteurs - notices \n 0 : Recalculer.\n 1 : Choisir.', '', 0),
(631, 'opac', 'show_exemplaires_analysis', '0', 'Afficher les exemplaires du bulletin sous l''article affiché ? \n 0: Non \n 1: Oui', 'e_aff_notice', 0),
(632, 'pmb', 'show_notice_id', '0', 'Afficher l''identifiant de la notice dans le descriptif ? \n 0 : Non.\n 1 : Oui. \n 1,X : Oui avec préfixe X', '', 0),
(633, 'opac', 'section_notices_order', ' index_serie, tnvol, index_sew ', 'Ordre d''affichage des notices dans les sections dans l''opac \n  index_serie, tnvol, index_sew : tri par titre de série et titre ', 'k_section', 0),
(634, 'opac', 'show_onglet_help', '0', 'Afficher l''onglet HELP avec les onglets de recherche affichant l''infopage et un lien vers l''infopage dans la barre de navigation \n 0 : Non.\n ## : id de l''infopage. \n', 'f_modules', 0),
(635, 'opac', 'navig_empr', '0', 'Afficher l''onglet "Votre compte" dans la barre de navigation de l''Opac ? \n 0 : Non \n 1 : Oui', 'a_general', 0),
(636, 'opac', 'confirm_resa', '0', 'Demander la confirmation sur la réservation d''un exemplaire en Opac ? \n 0 : Non \n 1 : Oui', 'a_general', 0),
(637, 'pmb', 'prefill_cote_ajax', '', 'Script personnalisé de construction de la cote de l''exemplaire en ajax', '', 0),
(638, 'pmb', 'hide_biblioinfo_letter', '0', 'Masquer les informations de localisation dans l''entête des lettres (pour les bibliothèques possédant du papier à entête)', '', 0),
(639, 'pmb', 'lettres_code_mail_position_absolue', '0 100 6', 'Placer le code lecteur et le mail selon des coordonnées absolues.\n activé x y \n activé : activer cette fonction (valeurs: 0/1) \n x : Position horizontale \n y : Position verticale', '', 0),
(640, 'opac', 'adhesion_expired_status', '0', 'Id du statut permettant de restreindre les droits des emprunteurs dont l''abonnement est dépassé. \n\rPMB fera un AND logique avec les droits d''origine.', 'a_general', 0),
(641, 'pmb', 'resa_retour_action_defaut', '0', 'Définit l''action par défaut à effectuer lors d''un retour si le document est réservé.\n0, A traiter plus tard.\n1, Valider la réservation.', '', 0),
(642, 'pmb', 'notice_fille_format', '0', 'Affichage des notices filles \n 0: avec leurs détails (notice dépliable avec un plus) \n 1: Juste l''entête', '', 0),
(643, 'pmb', 'hide_retdoc_loc_error', '0', 'Gestion du retour de prêt d''un document issu d''une autre localisation:\n 0 : Rendu, sans message d''erreur\n 1 : Non rendu, avec message d''erreur\n 2 : Rendu, avec message d''erreur', '', 0);
INSERT INTO `parametres` (`id_param`, `type_param`, `sstype_param`, `valeur_param`, `comment_param`, `section_param`, `gestion`) VALUES
(644, 'pmb', 'selfservice_allow', '0', 'Activer de la gestion de la borne de prêt?\n0 : Non. \n1 : Oui.', '', 0),
(645, 'selfservice', 'loc_autre_todo', '0', 'Action à effectuer si le document est issu d''une autre localisation', '', 1),
(646, 'selfservice', 'loc_autre_todo_msg', '', 'Message si le document est réservé sur une autre localisation', '', 1),
(647, 'selfservice', 'resa_ici_todo', '0', 'Action à effectuer si le document est réservé sur cette localisation', '', 1),
(648, 'selfservice', 'resa_ici_todo_msg', '', 'Message si le document est réservé sur cette localisation', '', 1),
(649, 'selfservice', 'resa_loc_todo', '0', 'Action à effectuer si le document est réservé sur une autre localisation', '', 1),
(650, 'selfservice', 'resa_loc_todo_msg', '', 'Message si le document est réservé sur une autre localisation', '', 1),
(651, 'selfservice', 'retour_retard_msg', '', 'Message si le document est rendu en retard', '', 1),
(652, 'selfservice', 'retour_blocage_msg', '', 'Message si le document est rendu en retard avec blocage', '', 1),
(653, 'selfservice', 'retour_amende_msg', '', 'Message si le document est rendu en retard avec amende', '', 1),
(654, 'selfservice', 'pret_carte_invalide_msg', 'Votre carte n''est pas valide !', 'Message borne de prêt: Votre carte n''est pas valide !', '', 1),
(655, 'selfservice', 'pret_pret_interdit_msg', 'Vous n''êtes pas autorisé à emprunter !', 'Message borne de prêt: Vous n''êtes pas autorisé à emprunter !', '', 1),
(656, 'selfservice', 'pret_deja_prete_msg', 'Document déjà prêté ! allez le signaler !', 'Message borne de prêt: Document déjà prêté ! allez le signaler !', '', 1),
(657, 'selfservice', 'pret_deja_reserve_msg', 'Vous ne pouvez pas emprunter ce document', 'Message borne de prêt: Vous ne pouvez pas emprunter ce document', '', 1),
(658, 'selfservice', 'pret_quota_bloc_msg', 'Vous ne pouvez pas emprunter ce document', 'Message borne de prêt: Vous ne pouvez pas emprunter ce document', '', 1),
(659, 'selfservice', 'pret_non_pretable_msg', 'Ce document n''est pas prêtable', 'Message borne de prêt: Ce document n''est pas prêtable', '', 1),
(660, 'selfservice', 'pret_expl_inconnu_msg', 'Ce document est inconnu', 'Message borne de prêt: Ce document est inconnu', '', 1),
(661, 'selfservice', 'pret_prolonge_non_msg', 'Le prêt ne peut être prolongé', 'Message borne de prêt: Le prêt ne peut être prolongé', '', 1),
(662, 'opac', 'photo_filtre_mimetype', '', 'Liste des mimetypes utilisés pour l''affichage des résultats en mode photothèque séparés par une virgule et entre cotes (ex:''application/pdf'',''image/png'')', 'm_photo', 0),
(663, 'empr', 'sms_activation', '0', 'Activation de l''envoi de sms. \n 0: Inactif \n 1: Actif', '', 0),
(664, 'empr', 'sms_config', '', 'Paramétrage de l''envoi de sms. \nUsage:\n class_name=nom_de_la_classe;param_connection;\nExemple:\n class_name=smstrend;login=xxxx@sigb.net;password=xxxx;tpoa=xxxx;', '', 0),
(665, 'empr', 'sms_msg_resa_dispo', 'Bonjour,\nUn document réservé est disponible.\nConsultez votre compte!', 'Texte du sms envoyé lors de la validation d''une réservation', '', 0),
(666, 'empr', 'sms_msg_resa_suppr', 'Bonjour,\nUne réservation est supprimée.\nConsultez votre compte!', 'Texte du sms envoyé lors de la suppression d''une réservation', '', 0),
(667, 'empr', 'sms_msg_retard', 'Bonjour,\nVous avez un ou plusieurs document(s) en retard.\nConsultez votre compte!', 'Texte du sms envoyé lors de la suppression d''une réservation', '', 0),
(668, 'pmb', 'procedure_server_address', '', 'Adresse du serveur de procédures distances.', '', 0),
(669, 'pmb', 'procedure_server_credentials', '', 'Autentification sur le serveur de procédures distantes.\n1ère ligne: email\n2ème ligne: mot de passe.', '', 0),
(670, 'pmb', 'rfid_pret_mode', '0', 'Mode de fonctionnement du prêt:\n 0: Un document retiré de la platine est retiré du prêt.\n 1: Un document retiré de la platine est conservé pour faciliter le prêt de nombreux documents. ', '', 0),
(671, 'fiches', 'active', '0', 'Module ''fiches'' activé.\n 0 : Non.\n 1 : Oui.', '', 0),
(672, 'opac', 'visionneuse_allow', '0', 'Visionneuse activée.\n 0 : Non.\n 1 : Oui.', 'm_photo', 0),
(673, 'opac', 'visionneuse_params', '', 'tableau de correspondance mimetype=>class', 'm_photo', 1),
(674, 'opac', 'allow_self_checkout', '0', 'Proposer de faire du prêt autonome dans l''OPAC.\n 0 : Non.\n 1 : Autorise le prêt de document.\n 2 : Autorise le retour de document.\n 3 : Autorise le prêt et le retour de document.\n', 'a_general', 0),
(675, 'opac', 'self_checkout_url_connector', '', 'URL du connecteur en gestion permettant d''effectuer le prêt autonome.', 'a_general', 0),
(676, 'finance', 'recouvrement_lecteur_statut', '0', 'Mémorise le statut que prennent les lecteurs lors du passage en recouvrememnt', '', 1),
(677, 'internal', 'emptylogstatopac', '0', 'Paramètre interne, ne pas modifier\r\n =1 si vidage des logs en cours', '', 0),
(678, 'thesaurus', 'auto_postage_search', '0', 'Activer l''indexation des catégories mères et filles pour la recherche de notices. \n 0 non, \n 1 oui', 'i_categories', 0),
(679, 'thesaurus', 'auto_postage_search_nb_descendant', '0', 'Nombre de niveaux de recherche de notices dans les catégories filles. \n *: illimité, \n n: nombre de niveaux', 'i_categories', 0),
(680, 'thesaurus', 'auto_postage_search_nb_montant', '0', 'Nombre de niveaux de recherche de notices dans les catégories mères. \n *: illimité, \n n: nombre de niveaux', 'i_categories', 0),
(681, 'opac', 'show_bulletin_nav', '0', 'Affichage d''un navigateur dans les bulletins d''un périodique. \n 0 non \n 1 oui', 'f_modules', 0),
(682, 'pmb', 'play_pret_sound', '1', 'Jouer l''alerte sonore si le prêt et le retour se passe sans erreur ? \n 0 : Non.\n 1 : Oui.', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pclassement`
--

CREATE TABLE IF NOT EXISTS `pclassement` (
  `id_pclass` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_pclass` varchar(255) NOT NULL DEFAULT '',
  `typedoc` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_pclass`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `pclassement`
--

INSERT INTO `pclassement` (`id_pclass`, `name_pclass`, `typedoc`) VALUES
(1, 'English light Dewey', 'abcdefgijklmr');

-- --------------------------------------------------------

--
-- Table structure for table `pret`
--

CREATE TABLE IF NOT EXISTS `pret` (
  `pret_idempr` int(10) unsigned NOT NULL DEFAULT '0',
  `pret_idexpl` int(10) unsigned NOT NULL DEFAULT '0',
  `pret_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pret_retour` date DEFAULT NULL,
  `pret_arc_id` int(10) unsigned NOT NULL DEFAULT '0',
  `niveau_relance` int(1) NOT NULL DEFAULT '0',
  `date_relance` date DEFAULT '0000-00-00',
  `printed` int(1) NOT NULL DEFAULT '0',
  `retour_initial` date DEFAULT '0000-00-00',
  `cpt_prolongation` int(1) NOT NULL DEFAULT '0',
  `pret_temp` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`pret_idexpl`),
  KEY `i_pret_idempr` (`pret_idempr`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pret`
--

INSERT INTO `pret` (`pret_idempr`, `pret_idexpl`, `pret_date`, `pret_retour`, `pret_arc_id`, `niveau_relance`, `date_relance`, `printed`, `retour_initial`, `cpt_prolongation`, `pret_temp`) VALUES
(1, 2, '2011-01-24 13:35:22', '2011-02-07', 1, 0, '0000-00-00', 0, '2011-02-07', 0, ''),
(2, 5, '2011-07-13 12:36:54', '2011-07-27', 2, 0, '0000-00-00', 0, '2011-07-27', 0, ''),
(2, 7, '2011-07-13 12:37:29', '2011-07-27', 3, 0, '0000-00-00', 0, '2011-07-27', 0, ''),
(2, 8, '2011-07-13 12:37:43', '2011-07-27', 4, 0, '0000-00-00', 0, '2011-07-27', 0, ''),
(2, 9, '2011-07-13 12:38:29', '2011-07-27', 5, 0, '0000-00-00', 0, '2011-07-27', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `pret_archive`
--

CREATE TABLE IF NOT EXISTS `pret_archive` (
  `arc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `arc_debut` datetime DEFAULT '0000-00-00 00:00:00',
  `arc_fin` datetime DEFAULT NULL,
  `arc_id_empr` int(10) unsigned NOT NULL DEFAULT '0',
  `arc_empr_cp` varchar(10) NOT NULL DEFAULT '',
  `arc_empr_ville` varchar(255) NOT NULL DEFAULT '',
  `arc_empr_prof` varchar(255) NOT NULL DEFAULT '',
  `arc_empr_year` int(4) unsigned DEFAULT '0',
  `arc_empr_categ` smallint(5) unsigned DEFAULT '0',
  `arc_empr_codestat` smallint(5) unsigned DEFAULT '0',
  `arc_empr_sexe` tinyint(3) unsigned DEFAULT '0',
  `arc_empr_statut` int(10) unsigned NOT NULL DEFAULT '1',
  `arc_expl_typdoc` int(5) unsigned DEFAULT '0',
  `arc_expl_cote` varchar(255) NOT NULL DEFAULT '',
  `arc_expl_statut` smallint(5) unsigned DEFAULT '0',
  `arc_expl_location` smallint(5) unsigned DEFAULT '0',
  `arc_expl_codestat` smallint(5) unsigned DEFAULT '0',
  `arc_expl_owner` mediumint(8) unsigned DEFAULT '0',
  `arc_expl_section` int(5) unsigned NOT NULL DEFAULT '0',
  `arc_expl_id` int(10) unsigned NOT NULL DEFAULT '0',
  `arc_expl_notice` int(10) unsigned NOT NULL DEFAULT '0',
  `arc_expl_bulletin` int(10) unsigned NOT NULL DEFAULT '0',
  `arc_groupe` varchar(255) NOT NULL DEFAULT '',
  `arc_niveau_relance` int(1) unsigned DEFAULT '0',
  `arc_date_relance` date NOT NULL DEFAULT '0000-00-00',
  `arc_printed` int(1) unsigned DEFAULT '0',
  `arc_cpt_prolongation` int(1) unsigned DEFAULT '0',
  PRIMARY KEY (`arc_id`),
  KEY `i_pa_expl_id` (`arc_expl_id`),
  KEY `i_pa_idempr` (`arc_id_empr`),
  KEY `i_pa_expl_notice` (`arc_expl_notice`),
  KEY `i_pa_expl_bulletin` (`arc_expl_bulletin`),
  KEY `i_pa_arc_fin` (`arc_fin`),
  KEY `i_pa_arc_empr_categ` (`arc_empr_categ`),
  KEY `i_pa_arc_expl_location` (`arc_expl_location`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `pret_archive`
--

INSERT INTO `pret_archive` (`arc_id`, `arc_debut`, `arc_fin`, `arc_id_empr`, `arc_empr_cp`, `arc_empr_ville`, `arc_empr_prof`, `arc_empr_year`, `arc_empr_categ`, `arc_empr_codestat`, `arc_empr_sexe`, `arc_empr_statut`, `arc_expl_typdoc`, `arc_expl_cote`, `arc_expl_statut`, `arc_expl_location`, `arc_expl_codestat`, `arc_expl_owner`, `arc_expl_section`, `arc_expl_id`, `arc_expl_notice`, `arc_expl_bulletin`, `arc_groupe`, `arc_niveau_relance`, `arc_date_relance`, `arc_printed`, `arc_cpt_prolongation`) VALUES
(1, '2011-01-24 13:35:22', '2011-02-07 00:00:00', 0, '4001', '', '', 1981, 5, 7, 1, 1, 1, '', 1, 0, 12, 2, 0, 2, 2, 0, '', 0, '0000-00-00', 0, 0),
(2, '2011-07-13 12:36:54', '2011-07-27 00:00:00', 0, '4001', 'Shkoder', 'bibliotekar', 1980, 3, 7, 1, 1, 1, 'UMB', 1, 0, 12, 1, 0, 5, 5, 0, '', 0, '0000-00-00', 0, 0),
(3, '2011-07-13 12:37:29', '2011-07-27 00:00:00', 0, '4001', 'Shkoder', 'bibliotekar', 1980, 3, 7, 1, 1, 1, '', 1, 0, 12, 1, 0, 7, 7, 0, '', 0, '0000-00-00', 0, 0),
(4, '2011-07-13 12:37:43', '2011-07-27 00:00:00', 0, '4001', 'Shkoder', 'bibliotekar', 1980, 3, 7, 1, 1, 1, '', 1, 0, 12, 1, 0, 8, 8, 0, '', 0, '0000-00-00', 0, 0),
(5, '2011-07-13 12:38:29', '2011-07-27 00:00:00', 0, '4001', 'Shkoder', 'bibliotekar', 1980, 3, 7, 1, 1, 1, '', 1, 0, 12, 1, 0, 9, 9, 0, '', 0, '0000-00-00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `procs`
--

CREATE TABLE IF NOT EXISTS `procs` (
  `idproc` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `requete` blob NOT NULL,
  `comment` tinytext NOT NULL,
  `autorisations` mediumtext,
  `parameters` text,
  `num_classement` int(5) unsigned NOT NULL DEFAULT '0',
  `proc_notice_tpl` int(2) unsigned NOT NULL DEFAULT '0',
  `proc_notice_tpl_field` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`idproc`),
  KEY `idproc` (`idproc`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `procs`
--

INSERT INTO `procs` (`idproc`, `name`, `requete`, `comment`, `autorisations`, `parameters`, `num_classement`, `proc_notice_tpl`, `proc_notice_tpl_field`) VALUES
(1, 'Liste expl/statut', 0x73656c656374206578706c5f636f74652c206578706c5f63622c20746974312066726f6d206578656d706c61697265732c206e6f7469636573207768657265206578706c5f7374617475743d2121706172616d31212120616e64206578706c5f6e6f746963653d6e6f746963655f6964206f72646572206279206578706c5f636f7465, 'Liste paramétrée d''exemplaires par statut ', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="param1" MANDATORY="yes">\n  <ALIAS><![CDATA[Statut]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY><![CDATA[select idstatut,statut_libelle from docs_statut]]></QUERY>\r\n <MULTIPLE>no</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""><![CDATA[Choisissez un statut]]></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n</FIELDS>', 0, 0, ''),
(2, 'Comptage expl /statut', 0x73656c656374207374617475745f6c6962656c6c652066726f6d206578656d706c61697265732c20646f63735f7374617475742c20636f756e74282a29206173204e6272652077686572652069647374617475743d6578706c5f7374617475742067726f7570206279207374617475745f6c6962656c6c65206f72646572206279206964737461747574, 'Nombre d''exemplaires par statut d''exmplaire', '1 2', NULL, 0, 0, ''),
(3, 'Comptage expl /prêteur', 0x73656c656374206c656e6465725f6c6962656c6c652c20636f756e74282a29206173204e6272652066726f6d206578656d706c61697265732c206c656e64657273207768657265206578706c5f6f776e65723d69646c656e6465722067726f7570206279206c656e6465725f6c6962656c6c65206f72646572206279206c656e6465725f6c6962656c6c6520, 'Nombre d''exemplaires par prêteur', '1 2', NULL, 0, 0, ''),
(4, 'Comptage  expl /prêteur /statut', 0x73656c656374206c656e6465725f6c6962656c6c652c2069647374617475742c207374617475745f6c6962656c6c65202c20636f756e74282a29206173204e6272652066726f6d206578656d706c61697265732c206c656e646572732c20646f63735f737461747574207768657265206578706c5f6f776e65723d69646c656e64657220616e64206578706c5f7374617475743d69647374617475742067726f7570206279206c656e6465725f6c6962656c6c652c7374617475745f6c6962656c6c65206f72646572206279206c656e6465725f6c6962656c6c652c7374617475745f6c6962656c6c6520, 'Nombre d''exemplaires par prêteur et par statut d''exmplaire', '1 2', NULL, 0, 0, ''),
(5, 'Liste expl d''un prêteur /statut', 0x73656c656374206c656e6465725f6c6962656c6c652c207374617475745f6c6962656c6c652c206578706c5f636f74652c206578706c5f63622c20746974312066726f6d206578656d706c61697265732c206e6f74696365732c20646f63735f7374617475742c206c656e64657273207768657265206578706c5f7374617475743d2121737461747574212120616e64206578706c5f6f776e65723d212150726f707269657461697265212120616e64206578706c5f6e6f746963653d6e6f746963655f696420616e64206578706c5f7374617475743d696473746174757420616e64206578706c5f6f776e65723d69646c656e646572206f72646572206279206c656e6465725f6c6962656c6c652c207374617475745f6c6962656c6c652c206578706c5f636f74652c206578706c5f636220, 'Liste d''exemplaires d''un propriétaire par statut, cote, code-barre, titre (pratique pour lister les documents non pointés après l''import)', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="statut" MANDATORY="yes">\n  <ALIAS><![CDATA[Statut]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY>select idstatut, statut_libelle from docs_statut</QUERY>\r\n <MULTIPLE>no</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n <FIELD NAME="Proprietaire" MANDATORY="yes">\n  <ALIAS><![CDATA[Proprietaire]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY>select idlender, lender_libelle from lenders</QUERY>\r\n <MULTIPLE>no</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n</FIELDS>', 0, 0, ''),
(6, 'Comptage expl /section', 0x73656c65637420696473656374696f6e2c2073656374696f6e5f6c6962656c6c652c20636f756e74282a29206173204e6272652066726f6d206578656d706c61697265732c20646f63735f73656374696f6e20776865726520696473656374696f6e3d6578706c5f73656374696f6e2067726f757020627920696473656374696f6e2c2073656374696f6e5f6c6962656c6c65206f7264657220627920696473656374696f6e, 'Nombre d''exemplaires par section', '1 2', NULL, 0, 0, ''),
(7, 'Liste expl pour une ou plusieurs sections par prêteur', 0x73656c6563742073656374696f6e5f6c6962656c6c652c206578706c5f636f74652c206578706c5f63622c20746974312066726f6d206578656d706c61697265732c206e6f74696365732c20646f63735f73656374696f6e2c206c656e6465727320776865726520696473656374696f6e20696e2028212173656374696f6e7321212920616e64206578706c5f6f776e65723d212170726574657572212120616e64206578706c5f6e6f746963653d6e6f746963655f696420616e64206578706c5f73656374696f6e3d696473656374696f6e20616e64206578706c5f6f776e65723d69646c656e646572206f726465722062792073656374696f6e5f6c6962656c6c652c206578706c5f636f74652c206578706c5f636220, 'Liste des exemplaires ayant une ou plusieurs sections particulières pour un prêteur', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="sections" MANDATORY="yes">\n  <ALIAS><![CDATA[Section(s)]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY><![CDATA[select idsection, section_libelle from docs_section]]></QUERY>\r\n <MULTIPLE>yes</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""><![CDATA[]]></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n <FIELD NAME="preteur" MANDATORY="yes">\n  <ALIAS><![CDATA[Prêteur]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY><![CDATA[select idlender, lender_libelle from lenders order by idlender]]></QUERY>\r\n <MULTIPLE>no</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""><![CDATA[Choisissez un prêteur]]></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n</FIELDS>', 0, 0, ''),
(8, 'Stat : Compte expl /propriétaire', 0x73656c656374206c656e6465725f6c6962656c6c652061732050726f7072696f2c20636f756e74282a29206173204e6272652066726f6d206578656d706c61697265732c206c656e646572732077686572652069646c656e6465723d6578706c5f6f776e65722067726f7570206279206578706c5f6f776e65722c206c656e6465725f6c6962656c6c65, 'Nbre d''exemplaires par propriétaire d''exemplaire', '1 2', NULL, 0, 0, ''),
(9, 'Liste expl du fonds propre', 0x73656c656374207374617475745f6c6962656c6c652c206578706c5f636f74652c206578706c5f63622c20746974312066726f6d206578656d706c61697265732c206e6f74696365732c20646f63735f737461747574207768657265206578706c5f6f776e65723d3020616e64206578706c5f6e6f746963653d6e6f746963655f696420616e64206578706c5f7374617475743d6964737461747574206f72646572206279207374617475745f6c6962656c6c652c206578706c5f636f74652c206578706c5f636220, 'Liste des exemplaires du fonds propre par statut, cote, code-barre, titre', '1 2', NULL, 0, 0, ''),
(10, 'Liste expl pour un prêteur', 0x73656c656374206578706c5f636f74652c206578706c5f63622c20746974312066726f6d206578656d706c61697265732c206e6f74696365732c20646f63735f7374617475742c206c656e64657273207768657265206578706c5f6f776e65723d212170726f707269657461697265212120616e64206578706c5f6e6f746963653d6e6f746963655f696420616e64206578706c5f7374617475743d696473746174757420616e64206578706c5f6f776e65723d69646c656e646572206f7264657220627920206578706c5f636f74652c206578706c5f636220, 'Liste des exemplaires pour 1 propriétaire trié par cote et code-barre', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="proprietaire" MANDATORY="yes">\n  <ALIAS><![CDATA[Propriétaire]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY>select idlender, lender_libelle from lenders order by idlender</QUERY>\r\n <MULTIPLE>no</MULTIPLE>\r\n <UNSELECT_ITEM VALUE="">Choisissez un prêteur</UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n</FIELDS>', 0, 0, ''),
(11, 'Comptage lecteurs /categ', 0x73656c656374206c6962656c6c652c20636f756e74282a2920617320274e627265206c65637465757273272066726f6d20656d70722c20656d70725f63617465672077686572652069645f63617465675f656d70723d656d70725f63617465672067726f7570206279206c6962656c6c65206f72646572206279206c6962656c6c65, 'Nombre de lecteurs par catégorie', '1 2', NULL, 0, 0, ''),
(13, 'Liste lecteurs /catégories', 0x73656c656374206c6962656c6c6520617320436174e9676f7269652c20656d70725f6e6f6d206173204e6f6d2c20656d70725f7072656e6f6d206173205072e96e6f6d2c20656d70725f7965617220617320446174654e61697373616e63652066726f6d20656d70722c20656d70725f63617465672077686572652069645f63617465675f656d70723d656d70725f6361746567206f72646572206279206c6962656c6c652c20656d70725f6e6f6d2c20656d70725f7072656e6f6d, 'Liste des lecteurs par catégorie de lecteur, lecteur', '1 2', NULL, 0, 0, ''),
(14, 'Prêts par catégories', 0x53454c45435420656d70725f63617465672e6c6962656c6c6520617320436174e9676f7269652c20656d70722e656d70725f6e6f6d206173204e6f6d2c20656d70722e656d70725f7072656e6f6d206173205072e96e6f6d2c20656d70722e656d70725f6362206173204e756de9726f2c206578656d706c61697265732e6578706c5f636220617320436f646542617272652c206e6f74696365732e746974312061732054697472652046524f4d20707265742c656d70722c656d70725f63617465672c6578656d706c61697265732c6e6f746963657320574845524520656d70725f63617465672e69645f63617465675f656d707220696e2028212163617465676f72696521212920616e6420656d70722e656d70725f6361746567203d20656d70725f63617465672e69645f63617465675f656d707220616e6420707265742e707265745f6964656d7072203d20656d70722e69645f656d707220616e6420707265742e707265745f69646578706c203d206578656d706c61697265732e6578706c5f696420616e64206578656d706c61697265732e6578706c5f6e6f74696365203d206e6f74696365732e6e6f746963655f6964206f7264657220627920312c322c332c36, 'Liste des exemplaires en prêt pour une ou plusieurs catégories de lecteurs', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="categorie" MANDATORY="yes">\n  <ALIAS><![CDATA[categorie]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY><![CDATA[select id_categ_empr, libelle from empr_categ order by libelle]]></QUERY>\r\n <MULTIPLE>yes</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""><![CDATA[]]></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n</FIELDS>', 0, 0, ''),
(20, 'Liste fonds propre / statut', 0x73656c656374207374617475745f6c6962656c6c652c206578706c5f636f74652c206578706c5f63622c20746974312066726f6d206578656d706c61697265732c206e6f74696365732c20646f63735f737461747574207768657265206578706c5f6f776e65723d3020616e64206578706c5f6e6f746963653d6e6f746963655f696420616e64206578706c5f7374617475743d6964737461747574206f72646572206279207374617475745f6c6962656c6c652c206578706c5f636f74652c206578706c5f636220, 'Pointage fonds propre', '1 2', NULL, 0, 0, ''),
(21, 'Stat : Compte lecteurs /age', 0x53454c45435420636f756e74282a292c2043415345205748454e2020282121706172616d312121202d20656d70725f7965617229203c3d203133205448454e20274a757371756520313320616e7327205748454e20282121706172616d312121202d20656d70725f7965617229203e313320616e6420282121706172616d312121202d20656d70725f79656172293c3d3234205448454e2027313420e020323420616e7327205748454e20282121706172616d312121202d20656d70725f79656172293e323420616e6420282121706172616d312121202d20656d70725f79656172293c3d3539205448454e2027323520e020323920616e7327205748454e20282121706172616d312121202d20656d70725f79656172293e3539205448454e2027363020616e7320657420706c7573272020454c5345202765727265757220737572206167652720454e442061732063617465675f6167652066726f6d20656d707220776865726520656d70725f636174656720696e2028212163617465676f72696521212920616e6420287965617228656d70725f646174655f65787069726174696f6e293d2121706172616d312121206f72207965617228656d70725f646174655f6164686573696f6e293d2121706172616d312121292067726f75702062792063617465675f616765, 'Nbre de lecteurs par tranche d''age pour une année', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="param1" MANDATORY="yes">\n  <ALIAS><![CDATA[Année de calcul]]></ALIAS>\n  <TYPE>text</TYPE>\n<OPTIONS FOR="text">\r\n <SIZE>5</SIZE>\r\n <MAXSIZE>4</MAXSIZE>\r\n</OPTIONS> \n </FIELD>\n <FIELD NAME="categorie" MANDATORY="yes">\n  <ALIAS><![CDATA[Catégorie]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY>select id_categ_empr, libelle from empr_categ order by libelle</QUERY>\r\n <MULTIPLE>yes</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n</FIELDS>', 0, 0, ''),
(22, 'Stat : Compte lecteurs /sexe /age', 0x53454c45435420636f756e74282a292c2063617365207768656e20656d70725f736578653d273127207468656e2027486f6d6d657327207768656e20656d70725f736578653d273227207468656e202746656d6d65732720656c736520276572726575722073757220736578652720656e6420617320536578652c2043415345205748454e2020282121706172616d312121202d20656d70725f7965617229203c3d203133205448454e20274a757371756520313320616e7327205748454e20282121706172616d312121202d20656d70725f7965617229203e313320616e6420282121706172616d312121202d20656d70725f7965617229203c3d203234205448454e2027313420e020323420616e7327205748454e20282121706172616d312121202d20656d70725f7965617229203e323420616e6420282121706172616d312121202d20656d70725f7965617229203c3d203539205448454e2027323520e020353920616e7327205748454e20282121706172616d312121202d20656d70725f7965617229203e3539205448454e2027363020616e7320657420706c7573272020454c5345202765727265757220737572206167652720454e442061732063617465675f6167652066726f6d20656d707220776865726520656d70725f636174656720696e2028212163617465676f72696521212920616e6420287965617228656d70725f646174655f65787069726174696f6e293d2121706172616d312121206f72207965617228656d70725f646174655f6164686573696f6e293d2121706172616d312121292067726f757020627920736578652c2063617465675f616765, 'Nbre de lecteurs par sexe et tranche d''age pour une année', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="param1" MANDATORY="yes">\n  <ALIAS><![CDATA[Année de calcul]]></ALIAS>\n  <TYPE>text</TYPE>\n<OPTIONS FOR="text">\r\n <SIZE>5</SIZE>\r\n <MAXSIZE>4</MAXSIZE>\r\n</OPTIONS> \n </FIELD>\n <FIELD NAME="categorie" MANDATORY="yes">\n  <ALIAS><![CDATA[Catégorie]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY>select id_categ_empr, libelle from empr_categ order by libelle</QUERY>\r\n <MULTIPLE>no</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n</FIELDS>', 0, 0, ''),
(23, 'Stat : Compte lecteurs /ville /catégorie', 0x73656c65637420656d70725f76696c6c652061732056696c6c652c20636f756e74282a29206173204e6272652066726f6d20656d707220776865726520656d70725f636174656720696e2028212163617465676f72696521212920616e6420287965617228656d70725f646174655f65787069726174696f6e293d2121616e6e65652121206f72207965617228656d70725f646174655f6164686573696f6e293d2121616e6e65652121292067726f757020627920656d70725f76696c6c65206f7264657220627920656d70725f76696c6c65, 'Nbre de lecteurs par ville de résidence pour une ou plusieurs catégorie', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="categorie" MANDATORY="yes">\n  <ALIAS><![CDATA[Catégorie]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY>select id_categ_empr, libelle from empr_categ order by libelle</QUERY>\r\n <MULTIPLE>yes</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n <FIELD NAME="annee" MANDATORY="yes">\n  <ALIAS><![CDATA[Année de calcul]]></ALIAS>\n  <TYPE>text</TYPE>\n<OPTIONS FOR="text">\r\n <SIZE>5</SIZE>\r\n <MAXSIZE>4</MAXSIZE>\r\n</OPTIONS>\n </FIELD>\n</FIELDS>', 0, 0, ''),
(24, 'Stat : Compte élèves', 0x53454c45435420636f756e74282a29206173206e6272655f656c6576652066726f6d20656d707220776865726520656d70725f636174656720696e2028212163617465676f72696521212920616e6420616e6420287965617228656d70725f646174655f65787069726174696f6e293d2121616e6e65652121206f72207965617228656d70725f646174655f6164686573696f6e293d2121616e6e6565212129, 'Nbre de lecteurs ''Elève'' = catégorie à sélectionner ', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="categorie" MANDATORY="yes">\n  <ALIAS><![CDATA[Catégorie de lecteurs]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY><![CDATA[select id_categ_empr, libelle from empr_categ order by libelle]]></QUERY>\r\n <MULTIPLE>yes</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""><![CDATA[]]></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n <FIELD NAME="annee" MANDATORY="yes">\n  <ALIAS><![CDATA[Année de calcul]]></ALIAS>\n  <TYPE>text</TYPE>\n<OPTIONS FOR="text">\r\n <SIZE>5</SIZE>\r\n <MAXSIZE>4</MAXSIZE>\r\n</OPTIONS>\n </FIELD>\n</FIELDS>', 0, 0, ''),
(25, 'Stat : Compte prêts pour élève ou profs', 0x53454c45435420636f756e74282a29206173206e6272655f707265745f656c6576652066726f6d20707265745f61726368697665207768657265206172635f656d70725f636174656720696e2028212163617465676f72696521212920616e642079656172286172635f646562757429203d20272121706172616d312121270d0a, 'Nbre de prêts pour les élèves de l''école ou pour les profs (prêts pour la classe) pour une année', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="categorie" MANDATORY="yes">\n  <ALIAS><![CDATA[Catégorie]]></ALIAS>\n  <TYPE>query_list</TYPE>\n<OPTIONS FOR="query_list">\r\n <QUERY><![CDATA[select id_categ_empr, libelle from empr_categ order by libelle]]></QUERY>\r\n <MULTIPLE>yes</MULTIPLE>\r\n <UNSELECT_ITEM VALUE=""><![CDATA[]]></UNSELECT_ITEM>\r\n</OPTIONS>\n </FIELD>\n <FIELD NAME="param1" MANDATORY="yes">\n  <ALIAS><![CDATA[Année de calcul]]></ALIAS>\n  <TYPE>text</TYPE>\n<OPTIONS FOR="text">\r\n <SIZE>5</SIZE>\r\n <MAXSIZE>4</MAXSIZE>\r\n</OPTIONS>\n </FIELD>\n</FIELDS>', 0, 0, ''),
(26, 'Stat : Compte prêts Documentaires E', 0x53454c4543542079656172286172635f64656275742920617320616e6e65652c206d6f6e746820286172635f646562757429206173206d6f69732c20636f756e74282a29206e625f707265745f446f63755f452046524f4d20707265745f6172636869766520776865726520286c65667420286172635f6578706c5f636f74652c32293d27452027206f72206c65667420286172635f6578706c5f636f74652c33293d2745422027206f72206c65667420286172635f6578706c5f636f74652c32293d27452e2729616e642079656172286172635f646562757429203d20272121706172616d312121272067726f757020627920616e6e65652c206d6f6973206f7264657220627920616e6e65652c206d6f6973, 'Nbre de prêts de documentaires Enfants pour une année', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="param1" MANDATORY="yes">\n  <ALIAS><![CDATA[Année de calcul]]></ALIAS>\n  <TYPE>text</TYPE>\n<OPTIONS FOR="text">\r\n <SIZE>5</SIZE>\r\n <MAXSIZE>4</MAXSIZE>\r\n</OPTIONS> \n </FIELD>\n</FIELDS>', 0, 0, ''),
(27, 'Stat : Compte prêts Fictions E', 0x53454c4543542079656172286172635f64656275742920617320616e6e65652c206d6f6e746820286172635f646562757429206173206d6f69732c20636f756e74282a29206e625f70726574735f66696374696f6e5f452046524f4d20707265745f6172636869766520776865726520286c65667420286172635f6578706c5f636f74652c33293d2745412027206f72206c65667420286172635f6578706c5f636f74652c33293d2745424427206f72206c65667420286172635f6578706c5f636f74652c33293d2745432027206f72206c65667420286172635f6578706c5f636f74652c33293d27455220272920616e642079656172286172635f646562757429203d20272121706172616d312121272067726f757020627920616e6e65652c206d6f6973206f7264657220627920616e6e65652c206d6f6973, 'Nbre de prêts de fictions Enfants pour une année', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="param1" MANDATORY="yes">\n  <ALIAS><![CDATA[Année de calcul]]></ALIAS>\n  <TYPE>text</TYPE>\n<OPTIONS FOR="text">\r\n <SIZE>5</SIZE>\r\n <MAXSIZE>4</MAXSIZE>\r\n</OPTIONS> \n </FIELD>\n</FIELDS>', 0, 0, ''),
(28, 'Stat : Compte prêts Fictions A', 0x53454c4543542079656172286172635f64656275742920617320616e6e65652c206d6f6e746820286172635f646562757429206173206d6f69732c20636f756e74282a29206e625f70726574735f66696374696f6e5f412046524f4d20707265745f6172636869766520776865726520286c65667420286172635f6578706c5f636f74652c31293d275227206f72206c65667420286172635f6578706c5f636f74652c33293d2742442027206f72206c65667420286172635f6578706c5f636f74652c32293d274a5227206f72206c65667420286172635f6578706c5f636f74652c33293d274a4244272920616e64206c65667420286172635f6578706c5f636f74652c33293c3e275245202720616e642079656172286172635f646562757429203d20272121706172616d312121272067726f757020627920616e6e65652c206d6f6973206f7264657220627920616e6e65652c206d6f6973, 'Nbre de prêts de fictions Jeunes ou Adultes pour une année', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="param1" MANDATORY="yes">\n  <ALIAS><![CDATA[Année de calcul]]></ALIAS>\n  <TYPE>text</TYPE>\n<OPTIONS FOR="text">\r\n <SIZE>5</SIZE>\r\n <MAXSIZE>4</MAXSIZE>\r\n</OPTIONS> \n </FIELD>\n</FIELDS>', 0, 0, ''),
(29, 'Stat : Compte prêts Documentaires A & J', 0x53454c4543542079656172286172635f64656275742920617320616e6e65652c206d6f6e746820286172635f646562757429206173206d6f69732c20636f756e74282a29206e625f70726574735f446f63755f412046524f4d20707265745f6172636869766520776865726520286c65667420286172635f6578706c5f636f74652c32293d27482027206f72206c65667420286172635f6578706c5f636f74652c32293d27422027206f72206c65667420286172635f6578706c5f636f74652c33293d2746522027206f72206c65667420286172635f6578706c5f636f74652c32293d274a2027206f72206c65667420286172635f6578706c5f636f74652c32293d274a2e27206f72206c656674286172635f6578706c5f636f74652c3129206265747765656e2027302720616e64202739272920616e642079656172286172635f646562757429203d20272121706172616d312121272067726f757020627920616e6e65652c206d6f6973206f7264657220627920616e6e65652c206d6f6973, 'Nbre de prêts de documentaires Jeunes ou Adultes pour une année', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="param1" MANDATORY="yes">\n  <ALIAS><![CDATA[Année de calcul]]></ALIAS>\n  <TYPE>text</TYPE>\n<OPTIONS FOR="text">\r\n <SIZE>5</SIZE>\r\n <MAXSIZE>4</MAXSIZE>\r\n</OPTIONS> \n </FIELD>\n</FIELDS>', 0, 0, ''),
(30, 'Stat : Compte prêts TOTAL (hors Pério)', 0x53454c4543542079656172286172635f64656275742920617320616e6e65652c206d6f6e746820286172635f646562757429206173206d6f69732c20636f756e74282a29206e625f70726574735f544f54414c2046524f4d20707265745f61726368697665207768657265206172635f6578706c5f636f7465206e6f74206c696b6520275020252720616e642079656172286172635f646562757429203d20272121706172616d312121272067726f757020627920616e6e65652c206d6f6973206f7264657220627920616e6e65652c206d6f6973, 'Nbre total de prêts hors périodiques pour une année', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="param1" MANDATORY="yes">\n  <ALIAS><![CDATA[Année de calcul]]></ALIAS>\n  <TYPE>text</TYPE>\n<OPTIONS FOR="text">\r\n <SIZE>5</SIZE>\r\n <MAXSIZE>4</MAXSIZE>\r\n</OPTIONS> \n </FIELD>\n</FIELDS>', 0, 0, ''),
(31, 'Stat : Compte prêts Périodiques', 0x53454c4543542079656172286172635f64656275742920617320616e6e65652c206d6f6e746820286172635f646562757429206173206d6f69732c20636f756e74282a29206e625f70726574735f544f54414c2046524f4d20707265745f61726368697665207768657265206172635f6578706c5f636f7465206c696b6520275020252720616e642079656172286172635f646562757429203d20272121706172616d312121272067726f757020627920616e6e65652c206d6f6973206f7264657220627920616e6e65652c206d6f6973, 'Nbre de prêts de périodiques pour une année', '1 2', '<?xml version="1.0" encoding="utf-8"?>\n<FIELDS>\n <FIELD NAME="param1" MANDATORY="yes">\n  <ALIAS><![CDATA[Année de calcul]]></ALIAS>\n  <TYPE>text</TYPE>\n<OPTIONS FOR="text">\r\n <SIZE>5</SIZE>\r\n <MAXSIZE>4</MAXSIZE>\r\n</OPTIONS> \n </FIELD>\n</FIELDS>', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `procs_classements`
--

CREATE TABLE IF NOT EXISTS `procs_classements` (
  `idproc_classement` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `libproc_classement` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`idproc_classement`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `procs_classements`
--


-- --------------------------------------------------------

--
-- Table structure for table `publishers`
--

CREATE TABLE IF NOT EXISTS `publishers` (
  `ed_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ed_name` varchar(255) NOT NULL DEFAULT '',
  `ed_adr1` varchar(255) NOT NULL DEFAULT '',
  `ed_adr2` varchar(255) NOT NULL DEFAULT '',
  `ed_cp` varchar(10) NOT NULL DEFAULT '',
  `ed_ville` varchar(96) NOT NULL DEFAULT '',
  `ed_pays` varchar(96) NOT NULL DEFAULT '',
  `ed_web` varchar(255) NOT NULL DEFAULT '',
  `index_publisher` text,
  `ed_comment` text,
  PRIMARY KEY (`ed_id`),
  KEY `ed_name` (`ed_name`),
  KEY `ed_ville` (`ed_ville`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `publishers`
--


-- --------------------------------------------------------

--
-- Table structure for table `quotas`
--

CREATE TABLE IF NOT EXISTS `quotas` (
  `quota_type` int(10) unsigned NOT NULL DEFAULT '0',
  `constraint_type` varchar(255) NOT NULL DEFAULT '',
  `elements` int(10) unsigned NOT NULL DEFAULT '0',
  `value` float DEFAULT NULL,
  PRIMARY KEY (`quota_type`,`constraint_type`,`elements`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quotas`
--


-- --------------------------------------------------------

--
-- Table structure for table `quotas_finance`
--

CREATE TABLE IF NOT EXISTS `quotas_finance` (
  `quota_type` int(10) unsigned NOT NULL DEFAULT '0',
  `constraint_type` varchar(255) NOT NULL DEFAULT '',
  `elements` int(10) unsigned NOT NULL DEFAULT '0',
  `value` float DEFAULT NULL,
  PRIMARY KEY (`quota_type`,`constraint_type`,`elements`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quotas_finance`
--


-- --------------------------------------------------------

--
-- Table structure for table `rapport_demandes`
--

CREATE TABLE IF NOT EXISTS `rapport_demandes` (
  `id_item` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contenu` text NOT NULL,
  `num_note` int(10) NOT NULL DEFAULT '0',
  `num_demande` int(10) NOT NULL DEFAULT '0',
  `ordre` mediumint(3) NOT NULL DEFAULT '0',
  `type` mediumint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_item`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `rapport_demandes`
--


-- --------------------------------------------------------

--
-- Table structure for table `recouvrements`
--

CREATE TABLE IF NOT EXISTS `recouvrements` (
  `recouvr_id` int(16) unsigned NOT NULL AUTO_INCREMENT,
  `empr_id` int(10) unsigned NOT NULL DEFAULT '0',
  `id_expl` int(10) unsigned NOT NULL DEFAULT '0',
  `date_rec` date NOT NULL DEFAULT '0000-00-00',
  `libelle` varchar(255) DEFAULT NULL,
  `montant` decimal(16,2) DEFAULT '0.00',
  `recouvr_type` int(2) unsigned NOT NULL DEFAULT '0',
  `date_pret` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_relance1` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_relance2` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_relance3` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`recouvr_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `recouvrements`
--


-- --------------------------------------------------------

--
-- Table structure for table `resa`
--

CREATE TABLE IF NOT EXISTS `resa` (
  `id_resa` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `resa_idempr` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `resa_idnotice` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `resa_idbulletin` int(8) unsigned NOT NULL DEFAULT '0',
  `resa_date` datetime DEFAULT NULL,
  `resa_date_debut` date NOT NULL DEFAULT '0000-00-00',
  `resa_date_fin` date NOT NULL DEFAULT '0000-00-00',
  `resa_cb` varchar(255) NOT NULL,
  `resa_confirmee` int(1) unsigned NOT NULL DEFAULT '0',
  `resa_loc_retrait` smallint(5) unsigned NOT NULL DEFAULT '0',
  `resa_arc` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_resa`),
  KEY `resa_date_fin` (`resa_date_fin`),
  KEY `resa_date` (`resa_date`),
  KEY `resa_cb` (`resa_cb`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `resa`
--


-- --------------------------------------------------------

--
-- Table structure for table `resa_archive`
--

CREATE TABLE IF NOT EXISTS `resa_archive` (
  `resarc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `resarc_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `resarc_debut` date NOT NULL DEFAULT '0000-00-00',
  `resarc_fin` date NOT NULL DEFAULT '0000-00-00',
  `resarc_idnotice` int(10) unsigned NOT NULL DEFAULT '0',
  `resarc_idbulletin` int(10) unsigned NOT NULL DEFAULT '0',
  `resarc_confirmee` int(1) unsigned DEFAULT '0',
  `resarc_cb` varchar(14) NOT NULL DEFAULT '',
  `resarc_loc_retrait` smallint(5) unsigned DEFAULT '0',
  `resarc_from_opac` int(1) unsigned DEFAULT '0',
  `resarc_anulee` int(1) unsigned DEFAULT '0',
  `resarc_pretee` int(1) unsigned DEFAULT '0',
  `resarc_arcpretid` int(10) unsigned NOT NULL DEFAULT '0',
  `resarc_id_empr` int(10) unsigned NOT NULL DEFAULT '0',
  `resarc_empr_cp` varchar(10) NOT NULL DEFAULT '',
  `resarc_empr_ville` varchar(255) NOT NULL DEFAULT '',
  `resarc_empr_prof` varchar(255) NOT NULL DEFAULT '',
  `resarc_empr_year` int(4) unsigned DEFAULT '0',
  `resarc_empr_categ` smallint(5) unsigned DEFAULT '0',
  `resarc_empr_codestat` smallint(5) unsigned DEFAULT '0',
  `resarc_empr_sexe` tinyint(3) unsigned DEFAULT '0',
  `resarc_empr_location` int(6) unsigned NOT NULL DEFAULT '1',
  `resarc_expl_nb` int(5) unsigned DEFAULT '0',
  `resarc_expl_typdoc` int(5) unsigned DEFAULT '0',
  `resarc_expl_cote` varchar(255) NOT NULL DEFAULT '',
  `resarc_expl_statut` smallint(5) unsigned DEFAULT '0',
  `resarc_expl_location` smallint(5) unsigned DEFAULT '0',
  `resarc_expl_codestat` smallint(5) unsigned DEFAULT '0',
  `resarc_expl_owner` mediumint(8) unsigned DEFAULT '0',
  `resarc_expl_section` int(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`resarc_id`),
  KEY `i_pa_idempr` (`resarc_id_empr`),
  KEY `i_pa_notice` (`resarc_idnotice`),
  KEY `i_pa_bulletin` (`resarc_idbulletin`),
  KEY `i_pa_resarc_date` (`resarc_date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `resa_archive`
--


-- --------------------------------------------------------

--
-- Table structure for table `resa_loc`
--

CREATE TABLE IF NOT EXISTS `resa_loc` (
  `resa_loc` int(8) unsigned NOT NULL DEFAULT '0',
  `resa_emprloc` int(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`resa_loc`,`resa_emprloc`),
  KEY `i_resa_emprloc` (`resa_emprloc`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `resa_loc`
--


-- --------------------------------------------------------

--
-- Table structure for table `resa_planning`
--

CREATE TABLE IF NOT EXISTS `resa_planning` (
  `id_resa` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `resa_idempr` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `resa_idnotice` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `resa_date` datetime DEFAULT NULL,
  `resa_date_debut` date NOT NULL DEFAULT '0000-00-00',
  `resa_date_fin` date NOT NULL DEFAULT '0000-00-00',
  `resa_validee` int(1) unsigned NOT NULL DEFAULT '0',
  `resa_confirmee` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_resa`),
  KEY `resa_date_fin` (`resa_date_fin`),
  KEY `resa_date` (`resa_date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `resa_planning`
--


-- --------------------------------------------------------

--
-- Table structure for table `resa_ranger`
--

CREATE TABLE IF NOT EXISTS `resa_ranger` (
  `resa_cb` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`resa_cb`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `resa_ranger`
--


-- --------------------------------------------------------

--
-- Table structure for table `responsability`
--

CREATE TABLE IF NOT EXISTS `responsability` (
  `responsability_author` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `responsability_notice` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `responsability_fonction` varchar(4) NOT NULL DEFAULT '',
  `responsability_type` mediumint(1) unsigned NOT NULL DEFAULT '0',
  `responsability_ordre` smallint(2) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`responsability_author`,`responsability_notice`,`responsability_fonction`),
  KEY `responsability_notice` (`responsability_notice`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `responsability`
--


-- --------------------------------------------------------

--
-- Table structure for table `rss_content`
--

CREATE TABLE IF NOT EXISTS `rss_content` (
  `rss_id` int(10) unsigned NOT NULL DEFAULT '0',
  `rss_content` longblob NOT NULL,
  `rss_content_parse` longblob NOT NULL,
  `rss_last` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`rss_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rss_content`
--


-- --------------------------------------------------------

--
-- Table structure for table `rss_flux`
--

CREATE TABLE IF NOT EXISTS `rss_flux` (
  `id_rss_flux` int(9) unsigned NOT NULL AUTO_INCREMENT,
  `nom_rss_flux` varchar(255) NOT NULL DEFAULT '',
  `link_rss_flux` blob NOT NULL,
  `descr_rss_flux` blob NOT NULL,
  `lang_rss_flux` varchar(255) NOT NULL DEFAULT 'sq',
  `copy_rss_flux` blob NOT NULL,
  `editor_rss_flux` varchar(255) NOT NULL DEFAULT '',
  `webmaster_rss_flux` varchar(255) NOT NULL DEFAULT '',
  `ttl_rss_flux` int(9) unsigned NOT NULL DEFAULT '60',
  `img_url_rss_flux` blob NOT NULL,
  `img_title_rss_flux` blob NOT NULL,
  `img_link_rss_flux` blob NOT NULL,
  `format_flux` blob NOT NULL,
  `rss_flux_content` longblob NOT NULL,
  `rss_flux_last` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `export_court_flux` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_rss_flux`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `rss_flux`
--


-- --------------------------------------------------------

--
-- Table structure for table `rss_flux_content`
--

CREATE TABLE IF NOT EXISTS `rss_flux_content` (
  `num_rss_flux` int(9) unsigned NOT NULL DEFAULT '0',
  `type_contenant` char(3) NOT NULL DEFAULT 'BAN',
  `num_contenant` int(9) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`num_rss_flux`,`type_contenant`,`num_contenant`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rss_flux_content`
--


-- --------------------------------------------------------

--
-- Table structure for table `rubriques`
--

CREATE TABLE IF NOT EXISTS `rubriques` (
  `id_rubrique` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `num_budget` int(8) unsigned NOT NULL DEFAULT '0',
  `num_parent` int(8) unsigned NOT NULL DEFAULT '0',
  `libelle` varchar(255) NOT NULL DEFAULT '',
  `commentaires` text NOT NULL,
  `montant` float(8,2) unsigned NOT NULL DEFAULT '0.00',
  `num_cp_compta` varchar(255) NOT NULL,
  `autorisations` mediumtext NOT NULL,
  PRIMARY KEY (`id_rubrique`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `rubriques`
--


-- --------------------------------------------------------

--
-- Table structure for table `sauv_lieux`
--

CREATE TABLE IF NOT EXISTS `sauv_lieux` (
  `sauv_lieu_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sauv_lieu_nom` varchar(50) DEFAULT NULL,
  `sauv_lieu_url` varchar(255) DEFAULT NULL,
  `sauv_lieu_protocol` varchar(10) DEFAULT 'file',
  `sauv_lieu_host` varchar(255) DEFAULT NULL,
  `sauv_lieu_login` varchar(255) DEFAULT NULL,
  `sauv_lieu_password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sauv_lieu_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sauv_lieux`
--


-- --------------------------------------------------------

--
-- Table structure for table `sauv_log`
--

CREATE TABLE IF NOT EXISTS `sauv_log` (
  `sauv_log_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sauv_log_start_date` date DEFAULT NULL,
  `sauv_log_file` varchar(255) DEFAULT NULL,
  `sauv_log_succeed` int(11) DEFAULT '0',
  `sauv_log_messages` mediumtext,
  `sauv_log_userid` int(11) DEFAULT NULL,
  PRIMARY KEY (`sauv_log_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sauv_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `sauv_sauvegardes`
--

CREATE TABLE IF NOT EXISTS `sauv_sauvegardes` (
  `sauv_sauvegarde_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sauv_sauvegarde_nom` varchar(50) DEFAULT NULL,
  `sauv_sauvegarde_file_prefix` varchar(20) DEFAULT NULL,
  `sauv_sauvegarde_tables` mediumtext,
  `sauv_sauvegarde_lieux` mediumtext,
  `sauv_sauvegarde_users` mediumtext,
  `sauv_sauvegarde_compress` int(11) DEFAULT '0',
  `sauv_sauvegarde_compress_command` mediumtext,
  `sauv_sauvegarde_crypt` int(11) DEFAULT '0',
  `sauv_sauvegarde_key1` varchar(32) DEFAULT NULL,
  `sauv_sauvegarde_key2` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`sauv_sauvegarde_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `sauv_sauvegardes`
--

INSERT INTO `sauv_sauvegardes` (`sauv_sauvegarde_id`, `sauv_sauvegarde_nom`, `sauv_sauvegarde_file_prefix`, `sauv_sauvegarde_tables`, `sauv_sauvegarde_lieux`, `sauv_sauvegarde_users`, `sauv_sauvegarde_compress`, `sauv_sauvegarde_compress_command`, `sauv_sauvegarde_crypt`, `sauv_sauvegarde_key1`, `sauv_sauvegarde_key2`) VALUES
(1, 'tout', 'bibli', '7', '', '1,3', 0, 'internal::', 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `sauv_tables`
--

CREATE TABLE IF NOT EXISTS `sauv_tables` (
  `sauv_table_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sauv_table_nom` varchar(50) DEFAULT NULL,
  `sauv_table_tables` text,
  PRIMARY KEY (`sauv_table_id`),
  UNIQUE KEY `sauv_table_nom` (`sauv_table_nom`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `sauv_tables`
--

INSERT INTO `sauv_tables` (`sauv_table_id`, `sauv_table_nom`, `sauv_table_tables`) VALUES
(1, 'Biblio', 'analysis,bulletins,docs_codestat,docs_location,docs_section,docs_statut,docs_type,exemplaires,notices,etagere_caddie,notices_custom,notices_custom_lists,notices_custom_values'),
(2, 'Autorités', 'authors,collections,publishers,series,sub_collections,responsability'),
(3, 'Aucune utilité', 'error_log,import_marc,sessions'),
(4, 'Z3950', 'z_attr,z_bib,z_notices,z_query'),
(5, 'Emprunteurs', 'empr,empr_categ,empr_codestat,empr_groupe,groupe,pret,pret_archive,resa,empr_custom,empr_custom_lists,empr_custom_values,expl_custom,expl_custom_lists,expl_custom_values'),
(6, 'Application', 'categories,lenders,parametres,procs,sauv_lieux,sauv_log,sauv_sauvegardes,sauv_tables,users,explnum,indexint,notices_categories,origine_notice,quotas,etagere,resa_ranger,admin_session,opac_sessions,audit,notice_statut,ouvertures'),
(7, 'TOUT', 'admin_session,analysis,audit,authors,bannette_abon,bannette_contenu,bannette_equation,bannettes,bulletins,caddie,caddie_content,caddie_procs,categories,classements,collections,comptes,docs_codestat,docs_location,docs_section,docs_statut,docs_type,empr,empr_categ,empr_codestat,empr_custom,empr_custom_lists,empr_custom_values,empr_groupe,equations,error_log,etagere,etagere_caddie,exemplaires,expl_custom,expl_custom_lists,expl_custom_values,explnum,groupe,import_marc,indexint,lenders,notice_statut,notices,notices_categories,notices_custom,notices_custom_lists,notices_custom_values,opac_sessions,origine_notice,ouvertures,parametres,pret,pret_archive,procs,publishers,quotas,quotas_finance,recouvrements,resa,resa_ranger,responsability,sauv_lieux,sauv_log,sauv_sauvegardes,sauv_tables,series,sessions,sub_collections,transactions,type_abts,type_comptes,users,z_attr,z_bib,z_notices,z_query'),
(9, 'Caddies', 'caddie_procs,caddie,caddie_content'),
(10, 'DSI', 'bannette_abon,bannette_contenu,bannette_equation,bannettes,classements,equations'),
(11, 'Finance', 'comptes,quotas_finance,recouvrements,transactions,type_abts,type_comptes');

-- --------------------------------------------------------

--
-- Table structure for table `search_perso`
--

CREATE TABLE IF NOT EXISTS `search_perso` (
  `search_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `num_user` int(8) unsigned NOT NULL DEFAULT '0',
  `search_name` varchar(255) NOT NULL DEFAULT '',
  `search_shortname` varchar(50) NOT NULL DEFAULT '',
  `search_query` text NOT NULL,
  `search_human` text NOT NULL,
  `search_directlink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`search_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `search_perso`
--


-- --------------------------------------------------------

--
-- Table structure for table `search_persopac`
--

CREATE TABLE IF NOT EXISTS `search_persopac` (
  `search_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `num_empr` int(8) unsigned NOT NULL DEFAULT '0',
  `search_name` varchar(255) NOT NULL DEFAULT '',
  `search_shortname` varchar(50) NOT NULL DEFAULT '',
  `search_query` text NOT NULL,
  `search_human` text NOT NULL,
  `search_directlink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `search_limitsearch` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`search_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `search_persopac`
--


-- --------------------------------------------------------

--
-- Table structure for table `series`
--

CREATE TABLE IF NOT EXISTS `series` (
  `serie_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `serie_name` varchar(255) NOT NULL DEFAULT '',
  `serie_index` text,
  PRIMARY KEY (`serie_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `series`
--


-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE IF NOT EXISTS `sessions` (
  `SESSID` varchar(12) NOT NULL DEFAULT '',
  `login` varchar(20) NOT NULL DEFAULT '',
  `IP` varchar(20) NOT NULL DEFAULT '',
  `SESSstart` varchar(12) NOT NULL DEFAULT '',
  `LastOn` varchar(12) NOT NULL DEFAULT '',
  `SESSNAME` varchar(25) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`SESSID`, `login`, `IP`, `SESSstart`, `LastOn`, `SESSNAME`) VALUES
('1734318364', 'admin', '127.0.0.1', '1317205332', '1317211862', 'PhpMyBibli');

-- --------------------------------------------------------

--
-- Table structure for table `source_sync`
--

CREATE TABLE IF NOT EXISTS `source_sync` (
  `source_id` int(10) unsigned NOT NULL DEFAULT '0',
  `nrecu` varchar(255) NOT NULL DEFAULT '',
  `ntotal` varchar(255) NOT NULL DEFAULT '',
  `message` varchar(255) NOT NULL DEFAULT '',
  `date_sync` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `percent` int(10) unsigned NOT NULL DEFAULT '0',
  `env` text NOT NULL,
  `cancel` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`source_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `source_sync`
--


-- --------------------------------------------------------

--
-- Table structure for table `statopac`
--

CREATE TABLE IF NOT EXISTS `statopac` (
  `id_log` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `date_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `url_demandee` varchar(255) NOT NULL DEFAULT '',
  `url_referente` varchar(255) NOT NULL DEFAULT '',
  `get_log` blob NOT NULL,
  `post_log` blob NOT NULL,
  `num_session` varchar(255) NOT NULL DEFAULT '0',
  `server_log` blob NOT NULL,
  `empr_carac` blob NOT NULL,
  `empr_doc` blob NOT NULL,
  `empr_expl` blob NOT NULL,
  `nb_result` blob NOT NULL,
  `gen_stat` blob NOT NULL,
  PRIMARY KEY (`id_log`),
  KEY `sopac_date_log` (`date_log`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `statopac`
--


-- --------------------------------------------------------

--
-- Table structure for table `statopac_request`
--

CREATE TABLE IF NOT EXISTS `statopac_request` (
  `idproc` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `requete` blob NOT NULL,
  `comment` tinytext NOT NULL,
  `parameters` text NOT NULL,
  `num_vue` mediumint(8) NOT NULL DEFAULT '0',
  `autorisations` mediumtext NOT NULL,
  PRIMARY KEY (`idproc`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `statopac_request`
--


-- --------------------------------------------------------

--
-- Table structure for table `statopac_vues`
--

CREATE TABLE IF NOT EXISTS `statopac_vues` (
  `id_vue` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `date_consolidation` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `nom_vue` varchar(255) NOT NULL DEFAULT '',
  `comment` tinytext NOT NULL,
  PRIMARY KEY (`id_vue`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `statopac_vues`
--


-- --------------------------------------------------------

--
-- Table structure for table `statopac_vues_col`
--

CREATE TABLE IF NOT EXISTS `statopac_vues_col` (
  `id_col` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `nom_col` varchar(255) NOT NULL DEFAULT '',
  `expression` varchar(255) NOT NULL DEFAULT '',
  `num_vue` mediumint(8) NOT NULL DEFAULT '0',
  `ordre` mediumint(8) NOT NULL DEFAULT '0',
  `filtre` varchar(255) NOT NULL DEFAULT '',
  `datatype` varchar(10) NOT NULL DEFAULT '',
  `maj_flag` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_col`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `statopac_vues_col`
--


-- --------------------------------------------------------

--
-- Table structure for table `sub_collections`
--

CREATE TABLE IF NOT EXISTS `sub_collections` (
  `sub_coll_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sub_coll_name` varchar(255) NOT NULL DEFAULT '',
  `sub_coll_parent` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `sub_coll_issn` varchar(12) NOT NULL DEFAULT '',
  `index_sub_coll` text,
  `subcollection_web` text NOT NULL,
  `subcollection_comment` text NOT NULL,
  PRIMARY KEY (`sub_coll_id`),
  KEY `sub_coll_name` (`sub_coll_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sub_collections`
--


-- --------------------------------------------------------

--
-- Table structure for table `suggestions`
--

CREATE TABLE IF NOT EXISTS `suggestions` (
  `id_suggestion` int(12) unsigned NOT NULL AUTO_INCREMENT,
  `titre` tinytext NOT NULL,
  `editeur` varchar(255) NOT NULL DEFAULT '',
  `auteur` varchar(255) NOT NULL DEFAULT '',
  `code` varchar(255) NOT NULL DEFAULT '',
  `prix` float(8,2) unsigned NOT NULL DEFAULT '0.00',
  `commentaires` text,
  `statut` int(3) unsigned NOT NULL DEFAULT '0',
  `num_produit` int(8) NOT NULL DEFAULT '0',
  `num_entite` int(5) NOT NULL DEFAULT '0',
  `index_suggestion` text NOT NULL,
  `nb` int(5) unsigned NOT NULL DEFAULT '1',
  `date_creation` date NOT NULL DEFAULT '0000-00-00',
  `date_decision` date NOT NULL DEFAULT '0000-00-00',
  `num_rubrique` int(8) unsigned NOT NULL DEFAULT '0',
  `num_fournisseur` int(5) unsigned NOT NULL DEFAULT '0',
  `num_notice` int(8) unsigned NOT NULL DEFAULT '0',
  `url_suggestion` varchar(255) NOT NULL DEFAULT '',
  `num_categ` int(12) NOT NULL DEFAULT '1',
  `sugg_location` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sugg_source` int(8) NOT NULL DEFAULT '0',
  `date_publication` varchar(255) NOT NULL DEFAULT '',
  `notice_unimarc` blob NOT NULL,
  PRIMARY KEY (`id_suggestion`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `suggestions`
--


-- --------------------------------------------------------

--
-- Table structure for table `suggestions_categ`
--

CREATE TABLE IF NOT EXISTS `suggestions_categ` (
  `id_categ` int(12) NOT NULL AUTO_INCREMENT,
  `libelle_categ` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_categ`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `suggestions_categ`
--

INSERT INTO `suggestions_categ` (`id_categ`, `libelle_categ`) VALUES
(1, 'kategori standart');

-- --------------------------------------------------------

--
-- Table structure for table `suggestions_origine`
--

CREATE TABLE IF NOT EXISTS `suggestions_origine` (
  `origine` varchar(100) NOT NULL DEFAULT '',
  `num_suggestion` int(12) unsigned NOT NULL DEFAULT '0',
  `type_origine` int(3) unsigned NOT NULL DEFAULT '0',
  `date_suggestion` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`origine`,`num_suggestion`,`type_origine`),
  KEY `i_origine` (`origine`,`type_origine`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suggestions_origine`
--


-- --------------------------------------------------------

--
-- Table structure for table `suggestions_source`
--

CREATE TABLE IF NOT EXISTS `suggestions_source` (
  `id_source` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `libelle_source` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_source`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `suggestions_source`
--


-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `id_tag` mediumint(8) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(200) NOT NULL DEFAULT '',
  `num_notice` mediumint(8) NOT NULL DEFAULT '0',
  `user_code` varchar(50) NOT NULL DEFAULT '',
  `dateajout` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tag`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tags`
--


-- --------------------------------------------------------

--
-- Table structure for table `thesaurus`
--

CREATE TABLE IF NOT EXISTS `thesaurus` (
  `id_thesaurus` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `libelle_thesaurus` varchar(255) NOT NULL DEFAULT '',
  `langue_defaut` varchar(5) NOT NULL DEFAULT 'fr_FR',
  `active` char(1) NOT NULL DEFAULT '1',
  `opac_active` char(1) NOT NULL DEFAULT '1',
  `num_noeud_racine` int(9) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_thesaurus`),
  UNIQUE KEY `libelle_thesaurus` (`libelle_thesaurus`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `thesaurus`
--

INSERT INTO `thesaurus` (`id_thesaurus`, `libelle_thesaurus`, `langue_defaut`, `active`, `opac_active`, `num_noeud_racine`) VALUES
(1, 'Thesaurus n°1', 'fr_FR', '1', '1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `titres_uniformes`
--

CREATE TABLE IF NOT EXISTS `titres_uniformes` (
  `tu_id` int(9) unsigned NOT NULL AUTO_INCREMENT,
  `tu_name` varchar(255) NOT NULL DEFAULT '',
  `tu_tonalite` varchar(255) NOT NULL DEFAULT '',
  `tu_comment` text NOT NULL,
  `index_tu` text NOT NULL,
  PRIMARY KEY (`tu_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `titres_uniformes`
--


-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE IF NOT EXISTS `transactions` (
  `id_transaction` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `compte_id` int(8) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_name` varchar(255) NOT NULL DEFAULT '',
  `machine` varchar(255) NOT NULL DEFAULT '',
  `date_enrgt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_prevue` date DEFAULT NULL,
  `date_effective` date DEFAULT NULL,
  `montant` decimal(16,2) NOT NULL DEFAULT '0.00',
  `sens` int(1) NOT NULL DEFAULT '0',
  `realisee` int(1) NOT NULL DEFAULT '0',
  `commentaire` text,
  `encaissement` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_transaction`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `transactions`
--


-- --------------------------------------------------------

--
-- Table structure for table `transferts`
--

CREATE TABLE IF NOT EXISTS `transferts` (
  `id_transfert` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `num_notice` int(10) unsigned NOT NULL DEFAULT '0',
  `num_bulletin` int(10) unsigned NOT NULL DEFAULT '0',
  `date_creation` date NOT NULL,
  `type_transfert` int(5) unsigned NOT NULL DEFAULT '0',
  `etat_transfert` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `origine` int(5) unsigned NOT NULL DEFAULT '0',
  `origine_comp` varchar(255) NOT NULL DEFAULT '',
  `source` smallint(5) unsigned DEFAULT NULL,
  `destinations` varchar(255) DEFAULT NULL,
  `date_retour` date DEFAULT NULL,
  `motif` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_transfert`),
  KEY `etat_transfert` (`etat_transfert`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `transferts`
--


-- --------------------------------------------------------

--
-- Table structure for table `transferts_demande`
--

CREATE TABLE IF NOT EXISTS `transferts_demande` (
  `id_transfert_demande` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `num_transfert` int(10) unsigned NOT NULL DEFAULT '0',
  `date_creation` date NOT NULL,
  `sens_transfert` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `num_location_source` smallint(5) unsigned NOT NULL DEFAULT '0',
  `num_location_dest` smallint(5) unsigned NOT NULL DEFAULT '0',
  `num_expl` int(10) unsigned NOT NULL DEFAULT '0',
  `etat_demande` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date_visualisee` date DEFAULT NULL,
  `date_envoyee` date DEFAULT NULL,
  `date_reception` date DEFAULT NULL,
  `motif_refus` varchar(255) NOT NULL DEFAULT '',
  `statut_origine` int(10) unsigned NOT NULL DEFAULT '0',
  `section_origine` int(10) unsigned NOT NULL DEFAULT '0',
  `resa_trans` int(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_transfert_demande`),
  KEY `num_transfert` (`num_transfert`),
  KEY `num_location_source` (`num_location_source`),
  KEY `num_location_dest` (`num_location_dest`),
  KEY `num_expl` (`num_expl`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `transferts_demande`
--


-- --------------------------------------------------------

--
-- Table structure for table `translation`
--

CREATE TABLE IF NOT EXISTS `translation` (
  `trans_table` varchar(100) NOT NULL DEFAULT '',
  `trans_field` varchar(100) NOT NULL DEFAULT '',
  `trans_lang` varchar(5) NOT NULL DEFAULT '',
  `trans_num` int(8) unsigned NOT NULL DEFAULT '0',
  `trans_text` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`trans_table`,`trans_field`,`trans_lang`,`trans_num`),
  KEY `i_lang` (`trans_lang`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `translation`
--


-- --------------------------------------------------------

--
-- Table structure for table `tris`
--

CREATE TABLE IF NOT EXISTS `tris` (
  `id_tri` int(4) NOT NULL AUTO_INCREMENT,
  `tri_par` varchar(100) NOT NULL DEFAULT '',
  `nom_tri` varchar(100) NOT NULL DEFAULT '',
  `tri_reference` varchar(40) NOT NULL DEFAULT 'notices',
  PRIMARY KEY (`id_tri`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tris`
--


-- --------------------------------------------------------

--
-- Table structure for table `tu_distrib`
--

CREATE TABLE IF NOT EXISTS `tu_distrib` (
  `distrib_num_tu` int(9) unsigned NOT NULL DEFAULT '0',
  `distrib_name` varchar(255) NOT NULL DEFAULT '',
  `distrib_ordre` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`distrib_num_tu`,`distrib_ordre`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tu_distrib`
--


-- --------------------------------------------------------

--
-- Table structure for table `tu_ref`
--

CREATE TABLE IF NOT EXISTS `tu_ref` (
  `ref_num_tu` int(9) unsigned NOT NULL DEFAULT '0',
  `ref_name` varchar(255) NOT NULL DEFAULT '',
  `ref_ordre` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ref_num_tu`,`ref_ordre`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tu_ref`
--


-- --------------------------------------------------------

--
-- Table structure for table `tu_subdiv`
--

CREATE TABLE IF NOT EXISTS `tu_subdiv` (
  `subdiv_num_tu` int(9) unsigned NOT NULL DEFAULT '0',
  `subdiv_name` varchar(255) NOT NULL DEFAULT '',
  `subdiv_ordre` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`subdiv_num_tu`,`subdiv_ordre`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tu_subdiv`
--


-- --------------------------------------------------------

--
-- Table structure for table `tva_achats`
--

CREATE TABLE IF NOT EXISTS `tva_achats` (
  `id_tva` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL DEFAULT '',
  `taux_tva` float(4,2) unsigned NOT NULL DEFAULT '0.00',
  `num_cp_compta` varchar(25) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_tva`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tva_achats`
--


-- --------------------------------------------------------

--
-- Table structure for table `types_produits`
--

CREATE TABLE IF NOT EXISTS `types_produits` (
  `id_produit` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL DEFAULT '',
  `num_cp_compta` varchar(25) NOT NULL DEFAULT '0',
  `num_tva_achat` varchar(25) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_produit`),
  KEY `libelle` (`libelle`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `types_produits`
--


-- --------------------------------------------------------

--
-- Table structure for table `type_abts`
--

CREATE TABLE IF NOT EXISTS `type_abts` (
  `id_type_abt` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `type_abt_libelle` varchar(255) DEFAULT NULL,
  `prepay` int(1) unsigned NOT NULL DEFAULT '0',
  `prepay_deflt_mnt` decimal(16,2) NOT NULL DEFAULT '0.00',
  `tarif` decimal(16,2) NOT NULL DEFAULT '0.00',
  `commentaire` text NOT NULL,
  `caution` decimal(16,2) NOT NULL DEFAULT '0.00',
  `localisations` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_type_abt`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `type_abts`
--


-- --------------------------------------------------------

--
-- Table structure for table `type_comptes`
--

CREATE TABLE IF NOT EXISTS `type_comptes` (
  `id_type_compte` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL DEFAULT '',
  `type_acces` int(8) unsigned NOT NULL DEFAULT '0',
  `acces_id` text NOT NULL,
  PRIMARY KEY (`id_type_compte`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `type_comptes`
--


-- --------------------------------------------------------

--
-- Table structure for table `upload_repertoire`
--

CREATE TABLE IF NOT EXISTS `upload_repertoire` (
  `repertoire_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `repertoire_nom` varchar(255) NOT NULL DEFAULT '',
  `repertoire_url` text NOT NULL,
  `repertoire_path` text NOT NULL,
  `repertoire_navigation` int(1) NOT NULL DEFAULT '0',
  `repertoire_hachage` int(1) NOT NULL DEFAULT '0',
  `repertoire_subfolder` int(8) NOT NULL DEFAULT '0',
  `repertoire_utf8` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`repertoire_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `upload_repertoire`
--


-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `userid` int(5) NOT NULL AUTO_INCREMENT,
  `create_dt` date NOT NULL DEFAULT '0000-00-00',
  `last_updated_dt` date NOT NULL DEFAULT '0000-00-00',
  `username` varchar(100) NOT NULL DEFAULT '',
  `pwd` varchar(50) NOT NULL DEFAULT '',
  `nom` varchar(30) NOT NULL DEFAULT '',
  `prenom` varchar(30) DEFAULT NULL,
  `rights` int(8) unsigned NOT NULL DEFAULT '0',
  `user_lang` varchar(5) NOT NULL DEFAULT 'fr_FR',
  `nb_per_page_search` int(10) unsigned NOT NULL DEFAULT '4',
  `nb_per_page_select` int(10) unsigned NOT NULL DEFAULT '10',
  `nb_per_page_gestion` int(10) unsigned NOT NULL DEFAULT '20',
  `param_popup_ticket` smallint(1) unsigned NOT NULL DEFAULT '0',
  `param_sounds` smallint(1) unsigned NOT NULL DEFAULT '1',
  `param_rfid_activate` int(1) NOT NULL DEFAULT '1',
  `param_licence` int(1) unsigned NOT NULL DEFAULT '0',
  `deflt_notice_statut` int(6) unsigned NOT NULL DEFAULT '1',
  `deflt_docs_type` int(6) unsigned NOT NULL DEFAULT '1',
  `deflt_lenders` int(6) unsigned NOT NULL DEFAULT '0',
  `deflt_styles` varchar(20) NOT NULL DEFAULT 'default',
  `deflt_docs_statut` int(6) unsigned DEFAULT '0',
  `deflt_docs_codestat` int(6) unsigned DEFAULT '0',
  `value_deflt_lang` varchar(20) DEFAULT 'fre',
  `value_deflt_fonction` varchar(20) DEFAULT '070',
  `value_deflt_relation` varchar(20) NOT NULL DEFAULT 'a',
  `deflt_docs_location` int(6) unsigned DEFAULT '0',
  `deflt_docs_section` int(6) unsigned DEFAULT '0',
  `value_deflt_module` varchar(30) DEFAULT 'circu',
  `user_email` varchar(255) DEFAULT '',
  `user_alert_resamail` int(1) unsigned NOT NULL DEFAULT '0',
  `deflt2docs_location` int(6) unsigned NOT NULL DEFAULT '0',
  `deflt_empr_statut` bigint(20) unsigned NOT NULL DEFAULT '1',
  `deflt_thesaurus` int(3) unsigned NOT NULL DEFAULT '1',
  `value_prefix_cote` tinyblob NOT NULL,
  `xmlta_doctype` char(2) NOT NULL DEFAULT 'a',
  `speci_coordonnees_etab` mediumtext NOT NULL,
  `value_email_bcc` varchar(255) NOT NULL DEFAULT '',
  `value_deflt_antivol` varchar(50) NOT NULL DEFAULT '0',
  `explr_invisible` varchar(255) DEFAULT '0',
  `explr_visible_mod` varchar(255) DEFAULT '0',
  `explr_visible_unmod` varchar(255) DEFAULT '0',
  `deflt3bibli` int(5) unsigned NOT NULL DEFAULT '0',
  `deflt3exercice` int(8) unsigned NOT NULL DEFAULT '0',
  `deflt3rubrique` int(8) unsigned NOT NULL DEFAULT '0',
  `deflt3dev_statut` int(3) NOT NULL DEFAULT '-1',
  `deflt3cde_statut` int(3) NOT NULL DEFAULT '-1',
  `deflt3liv_statut` int(3) NOT NULL DEFAULT '-1',
  `deflt3fac_statut` int(3) NOT NULL DEFAULT '-1',
  `deflt3sug_statut` int(3) NOT NULL DEFAULT '-1',
  `environnement` mediumblob NOT NULL,
  `param_allloc` int(1) unsigned NOT NULL DEFAULT '0',
  `grp_num` int(10) unsigned DEFAULT '0',
  `deflt_arch_statut` int(6) unsigned NOT NULL DEFAULT '0',
  `deflt_arch_emplacement` int(6) unsigned NOT NULL DEFAULT '0',
  `deflt_arch_type` int(6) unsigned NOT NULL DEFAULT '0',
  `deflt_upload_repertoire` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `create_dt`, `last_updated_dt`, `username`, `pwd`, `nom`, `prenom`, `rights`, `user_lang`, `nb_per_page_search`, `nb_per_page_select`, `nb_per_page_gestion`, `param_popup_ticket`, `param_sounds`, `param_rfid_activate`, `param_licence`, `deflt_notice_statut`, `deflt_docs_type`, `deflt_lenders`, `deflt_styles`, `deflt_docs_statut`, `deflt_docs_codestat`, `value_deflt_lang`, `value_deflt_fonction`, `value_deflt_relation`, `deflt_docs_location`, `deflt_docs_section`, `value_deflt_module`, `user_email`, `user_alert_resamail`, `deflt2docs_location`, `deflt_empr_statut`, `deflt_thesaurus`, `value_prefix_cote`, `xmlta_doctype`, `speci_coordonnees_etab`, `value_email_bcc`, `value_deflt_antivol`, `explr_invisible`, `explr_visible_mod`, `explr_visible_unmod`, `deflt3bibli`, `deflt3exercice`, `deflt3rubrique`, `deflt3dev_statut`, `deflt3cde_statut`, `deflt3liv_statut`, `deflt3fac_statut`, `deflt3sug_statut`, `environnement`, `param_allloc`, `grp_num`, `deflt_arch_statut`, `deflt_arch_emplacement`, `deflt_arch_type`, `deflt_upload_repertoire`) VALUES
(1, '2002-07-28', '2011-01-25', 'admin', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', 'Super User', '', 2303, 'sq_AL', 20, 10, 20, 1, 1, 0, 1, 2, 1, 1, 'nova', 1, 12, 'alb', '070', 'a', 0, 0, 'admin', 'pmb@sigb.net', 1, 1, 1, 1, '', 'a', '', '', '0', '0', '0', '0', 0, 0, 0, -1, -1, -1, -1, -1, '', 0, 0, 0, 0, 0, 0),
(2, '2011-01-24', '2011-01-24', 'qarkullim', '*29437264A9C970C4E5199EA194DFF645B92A2EBC', '', '', 131, 'sq_AL', 10, 10, 10, 0, 1, 0, 1, 1, 1, 1, 'nova', 11, 10, 'fre', '070', 'a', 0, 0, 'circu', '', 0, 1, 1, 1, '', 'a', '', '', '0', '0', '0', '0', 0, 0, 0, -1, -1, -1, -1, -1, '', 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE IF NOT EXISTS `users_groups` (
  `grp_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `grp_name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`grp_id`),
  KEY `i_users_groups_grp_name` (`grp_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `users_groups`
--


-- --------------------------------------------------------

--
-- Table structure for table `visionneuse_params`
--

CREATE TABLE IF NOT EXISTS `visionneuse_params` (
  `visionneuse_params_id` int(11) NOT NULL AUTO_INCREMENT,
  `visionneuse_params_class` varchar(255) NOT NULL DEFAULT '',
  `visionneuse_params_parameters` text NOT NULL,
  PRIMARY KEY (`visionneuse_params_id`),
  UNIQUE KEY `visionneuse_params_class` (`visionneuse_params_class`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `visionneuse_params`
--


-- --------------------------------------------------------

--
-- Table structure for table `voir_aussi`
--

CREATE TABLE IF NOT EXISTS `voir_aussi` (
  `num_noeud_orig` int(9) unsigned NOT NULL DEFAULT '0',
  `num_noeud_dest` int(9) unsigned NOT NULL DEFAULT '0',
  `langue` varchar(5) NOT NULL DEFAULT '',
  `comment_voir_aussi` text NOT NULL,
  PRIMARY KEY (`num_noeud_orig`,`num_noeud_dest`,`langue`),
  KEY `num_noeud_dest` (`num_noeud_dest`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voir_aussi`
--


-- --------------------------------------------------------

--
-- Table structure for table `z_attr`
--

CREATE TABLE IF NOT EXISTS `z_attr` (
  `attr_bib_id` int(6) unsigned NOT NULL DEFAULT '0',
  `attr_libelle` varchar(250) NOT NULL DEFAULT '',
  `attr_attr` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`attr_bib_id`,`attr_libelle`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `z_attr`
--

INSERT INTO `z_attr` (`attr_bib_id`, `attr_libelle`, `attr_attr`) VALUES
(2, 'sujet', '21'),
(2, 'titre', '4'),
(2, 'auteur', '1003'),
(2, 'isbn', '7'),
(3, 'sujet', '21'),
(3, 'titre', '4'),
(3, 'isbn', '7'),
(3, 'auteur', '1003'),
(5, 'auteur', '1004'),
(5, 'titre', '4'),
(5, 'isbn', '7'),
(5, 'sujet', '21'),
(7, 'isbn', '7'),
(7, 'auteur', '1003'),
(7, 'titre', '4'),
(7, 'sujet', '21'),
(8, 'auteur', '1'),
(8, 'titre', '4'),
(8, 'isbn', '7'),
(8, 'sujet', '21'),
(8, 'mots', '1016'),
(10, 'auteur', '1003'),
(10, 'titre', '4'),
(10, 'isbn', '7'),
(10, 'sujet', '21'),
(12, 'sujet', '21'),
(12, 'auteur', '1003'),
(12, 'titre', '4'),
(12, 'isbn', '7'),
(11, 'sujet', '21'),
(11, 'auteur', '1003'),
(11, 'isbn', '7'),
(11, 'titre', '4'),
(15, 'auteur', '1003'),
(15, 'titre', '4'),
(15, 'isbn', '7'),
(15, 'sujet', '21'),
(17, 'sujet', '21'),
(17, 'auteur', '1003'),
(17, 'isbn', '7'),
(17, 'titre', '4'),
(21, 'sujet', '21'),
(21, 'auteur', '1003'),
(21, 'isbn', '7'),
(21, 'titre', '4');

-- --------------------------------------------------------

--
-- Table structure for table `z_bib`
--

CREATE TABLE IF NOT EXISTS `z_bib` (
  `bib_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `bib_nom` varchar(250) DEFAULT NULL,
  `search_type` varchar(20) DEFAULT NULL,
  `url` varchar(250) DEFAULT NULL,
  `port` varchar(6) DEFAULT NULL,
  `base` varchar(250) DEFAULT NULL,
  `format` varchar(250) DEFAULT NULL,
  `auth_user` varchar(250) NOT NULL DEFAULT '',
  `auth_pass` varchar(250) NOT NULL DEFAULT '',
  `sutrs_lang` varchar(10) NOT NULL DEFAULT '',
  `fichier_func` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`bib_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `z_bib`
--

INSERT INTO `z_bib` (`bib_id`, `bib_nom`, `search_type`, `url`, `port`, `base`, `format`, `auth_user`, `auth_pass`, `sutrs_lang`, `fichier_func`) VALUES
(2, 'ENS Cachan', 'CATALOG', '138.231.48.2', '21210', 'ADVANCE', 'unimarc', '', '', '', ''),
(3, 'BN France', 'CATALOG', 'z3950.bnf.fr', '2211', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1456', 'UNIMARC', 'Z3950', 'Z3950_BNF', '', ''),
(5, 'Univ Lyon 2 SCD', 'CATALOG', 'scdinf.univ-lyon2.fr', '21210', 'ouvrages', 'unimarc', '', '', '', ''),
(7, 'Univ Oxford', 'CATALOG', 'library.ox.ac.uk', '210', 'ADVANCE', 'usmarc', '', '', '', ''),
(10, 'Univ Laval (QC)', 'CATALOG', 'ariane2.ulaval.ca', '2200', 'UNICORN', 'USMARC', '', '', '', ''),
(11, 'Univ Lib Edinburgh', 'CATALOG', 'catalogue.lib.ed.ac.uk', '7090', 'voyager', 'USMARC', '', '', '', ''),
(12, 'Library Of Congress', 'CATALOG', 'z3950.loc.gov', '7090', 'Voyager', 'USMARC', '', '', '', ''),
(15, 'ENS Paris', 'CATALOG', 'halley.ens.fr', '210', 'INNOPAC', 'UNIMARC', '', '', '', ''),
(17, 'Polytechnique Montréal', 'CATALOG', 'advance.biblio.polymtl.ca', '210', 'ADVANCE', 'USMARC', '', '', '', ''),
(21, 'SUDOC', 'CATALOG', 'carmin.sudoc.abes.fr', '210', 'ABES-Z39-PUBLIC', 'UNIMARC', '', '', '', ''),
(8, 'Univ Valenciennes', 'CATALOG', '195.221.187.151', '210', 'INNOPAC', 'UNIMARC', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `z_notices`
--

CREATE TABLE IF NOT EXISTS `z_notices` (
  `znotices_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `znotices_query_id` int(11) DEFAULT NULL,
  `znotices_bib_id` int(6) unsigned DEFAULT '0',
  `isbd` text,
  `isbn` varchar(250) DEFAULT NULL,
  `titre` varchar(250) DEFAULT NULL,
  `auteur` varchar(250) DEFAULT NULL,
  `z_marc` longblob NOT NULL,
  PRIMARY KEY (`znotices_id`),
  KEY `idx_z_notices_idq` (`znotices_query_id`),
  KEY `idx_z_notices_isbn` (`isbn`),
  KEY `idx_z_notices_titre` (`titre`),
  KEY `idx_z_notices_auteur` (`auteur`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `z_notices`
--


-- --------------------------------------------------------

--
-- Table structure for table `z_query`
--

CREATE TABLE IF NOT EXISTS `z_query` (
  `zquery_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `search_attr` varchar(255) DEFAULT NULL,
  `zquery_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`zquery_id`),
  KEY `zquery_date` (`zquery_date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `z_query`
--

